#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "$0")"
prefix="${MINGW_PREFIX:-x86_64-w64-mingw32-}"
mkdir -p build
"${prefix}windres" -I. resources.rc -O coff -o build/resources.o
"${prefix}gcc" -std=c11 -O2 -Wall -Wextra -Wno-misleading-indentation -municode -mwindows -static \
 -Isrc -Ithird_party/cjson src/main.c src/engine.c src/devices.c src/platform.c src/core.c \
 third_party/cjson/cJSON.c build/resources.o -o build/Specreation_VUV_Scan_C.exe \
 -Wl,--nxcompat,--dynamicbase -lcomctl32 -lgdi32 -lcomdlg32 -lshell32 -lole32 -luuid
