@echo off
setlocal
cd /d "%~dp0"
where gcc >nul 2>nul
if errorlevel 1 (
 echo Install an x64 UCRT MinGW/LLVM-MinGW C compiler and add its bin folder to PATH.
 exit /b 1
)
if not exist build mkdir build
windres -I. resources.rc -O coff -o build\resources.o
if errorlevel 1 exit /b 1
gcc -std=c11 -O2 -Wall -Wextra -Wno-misleading-indentation -municode -mwindows -static -Isrc -Ithird_party/cjson src/main.c src/engine.c src/devices.c src/platform.c src/core.c third_party/cjson/cJSON.c build/resources.o -o build/Specreation_VUV_Scan_C.exe -Wl,--nxcompat,--dynamicbase -lcomctl32 -lgdi32 -lcomdlg32 -lshell32 -lole32 -luuid
if errorlevel 1 exit /b 1
echo Built: build\Specreation_VUV_Scan_C.exe
endlocal
