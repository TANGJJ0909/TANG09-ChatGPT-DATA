#include "core.h"
#include "cJSON.h"
#include <math.h>
#include <stdio.h>
#include <string.h>
#include <stdarg.h>
#include <stdlib.h>
#include <float.h>
static int bad(char *e, size_t n, const char *fmt, ...) {
    va_list a;
    va_start(a, fmt);
    if (e && n)
        vsnprintf(e, n, fmt, a);
    va_end(a);
    return 0;
}
static int finite4(const double *a) {
    int i;
    for (i = 0; i < 4; i++)
        if (!isfinite(a[i]))
            return 0;
    return 1;
}
VuvCameraConfig vuv_camera_defaults(void) {
    VuvCameraConfig c;
    memset(&c, 0, sizeof c);
    c.exposure_ms = 100;
    c.timeout_s = 120;
    c.frames = 1;
    c.hbin = c.vbin = c.x0 = c.y0 = 1;
    c.track_height = 16;
    c.vs = -1;
    c.shutter = -1;
    c.shutter_ttl = 1;
    c.temperature = -70;
    return c;
}
VuvPlan vuv_plan_defaults(void) {
    VuvPlan p;
    memset(&p, 0, sizeof p);
    p.points = 21;
    p.step = .1;
    p.settle_s = .2;
    p.velocity = .1;
    p.period_s = .5;
    p.lead_s = .25;
    p.signal_last = -1;
    return p;
}
double vuv_cal_eval(const VuvCalibration *c, double x) {
    double y = 0;
    int i;
    for (i = c->degree; i >= 0; i--)
        y = y * x + c->a[i];
    return y;
}
int vuv_cal_validate(const VuvCalibration *c, char *e, size_t n) {
    double x[3], d[3], a2 = 0, a3 = 0;
    int count = 2, i, pos = 1, neg = 1;
    if (!c || !c->enabled)
        return bad(e, n, "Calibration is not enabled");
    if (c->degree < 1 || c->degree > 3 || !finite4(c->a) || !isfinite(c->lo) || !isfinite(c->hi) ||
        c->lo >= c->hi)
        return bad(e, n, "Invalid calibration coefficients or angle range");
    if (c->degree >= 2)
        a2 = c->a[2];
    if (c->degree == 3)
        a3 = c->a[3];
    x[0] = c->lo;
    x[1] = c->hi;
    if (a3 != 0) {
        double v = -a2 / (3 * a3);
        if (v >= c->lo && v <= c->hi)
            x[count++] = v;
    }
    for (i = 0; i < count; i++) {
        d[i] = c->a[1] + 2 * a2 * x[i] + 3 * a3 * x[i] * x[i];
        if (!isfinite(d[i]) || d[i] <= 1e-12)
            pos = 0;
        if (!isfinite(d[i]) || d[i] >= -1e-12)
            neg = 0;
    }
    if (!pos && !neg)
        return bad(e, n, "Calibration must be strictly monotonic over its whole range");
    if (!isfinite(vuv_cal_eval(c, c->lo)) || !isfinite(vuv_cal_eval(c, c->hi)) ||
        vuv_cal_eval(c, c->lo) <= 0 || vuv_cal_eval(c, c->hi) <= 0)
        return bad(e, n, "Wavelength must be finite and positive");
    return 1;
}
int vuv_cal_inverse(const VuvCalibration *c, double wave, double *angle, char *e, size_t n) {
    double lo, hi, left, right, mid, y;
    int i, increasing;
    if (!vuv_cal_validate(c, e, n) || !isfinite(wave))
        return 0;
    lo = c->lo;
    hi = c->hi;
    left = vuv_cal_eval(c, lo);
    right = vuv_cal_eval(c, hi);
    increasing = right > left;
    if (wave < fmin(left, right) || wave > fmax(left, right))
        return bad(e, n, "Wavelength outside calibration; extrapolation is prohibited");
    for (i = 0; i < 80; i++) {
        mid = (lo + hi) / 2;
        y = vuv_cal_eval(c, mid);
        if ((y < wave) == increasing)
            lo = mid;
        else
            hi = mid;
    }
    *angle = (lo + hi) / 2;
    return 1;
}
int vuv_cal_json(const char *text, VuvCalibration *out, char *e, size_t n) {
    cJSON *j = cJSON_Parse(text), *a, *v;
    VuvCalibration c;
    int i, k;
    memset(&c, 0, sizeof c);
    c.reference_pixel = NAN;
    if (!j || !cJSON_IsObject(j)) {
        cJSON_Delete(j);
        return bad(e, n, "Calibration JSON must be an object");
    }
    a = cJSON_GetObjectItemCaseSensitive(j, "coefficients");
    k = cJSON_GetArraySize(a);
    if (!cJSON_IsArray(a) || k < 2 || k > 4) {
        cJSON_Delete(j);
        return bad(e, n, "Expected 2 to 4 coefficients");
    }
    for (i = 0; i < k; i++) {
        v = cJSON_GetArrayItem(a, i);
        if (!cJSON_IsNumber(v) || !isfinite(v->valuedouble)) {
            cJSON_Delete(j);
            return bad(e, n, "Invalid coefficient");
        }
        c.a[i] = v->valuedouble;
    }
    c.degree = k - 1;
    c.enabled = 1;
    v = cJSON_GetObjectItemCaseSensitive(j, "angle_min");
    if (!cJSON_IsNumber(v)) {
        cJSON_Delete(j);
        return bad(e, n, "Missing angle_min");
    }
    c.lo = v->valuedouble;
    v = cJSON_GetObjectItemCaseSensitive(j, "angle_max");
    if (!cJSON_IsNumber(v)) {
        cJSON_Delete(j);
        return bad(e, n, "Missing angle_max");
    }
    c.hi = v->valuedouble;
    v = cJSON_GetObjectItemCaseSensitive(j, "simulation_only");
    if (v && !cJSON_IsBool(v)) {
        cJSON_Delete(j);
        return bad(e, n, "simulation_only must be boolean");
    }
    c.simulation_only = cJSON_IsTrue(v);
    v = cJSON_GetObjectItemCaseSensitive(j, "wavelength_unit");
    if (v && (!cJSON_IsString(v) || strcmp(v->valuestring, "nm"))) {
        cJSON_Delete(j);
        return bad(e, n, "Wavelength unit must be nm");
    }
    v = cJSON_GetObjectItemCaseSensitive(j, "angle_unit");
    if (v && (!cJSON_IsString(v) || strcmp(v->valuestring, "deg"))) {
        cJSON_Delete(j);
        return bad(e, n, "Angle unit must be deg");
    }
    v = cJSON_GetObjectItemCaseSensitive(j, "reference_pixel");
    if (cJSON_IsNumber(v))
        c.reference_pixel = v->valuedouble;
    cJSON_Delete(j);
    if (!vuv_cal_validate(&c, e, n))
        return 0;
    *out = c;
    return 1;
}
int vuv_shape(const VuvCameraConfig *c, int width, int height, VuvShape *s, char *e, size_t n) {
    int x1 = c->x1 ? c->x1 : width, y1 = c->y1 ? c->y1 : height,
        center = c->track_center ? c->track_center : (height + 1) / 2;
    memset(s, 0, sizeof *s);
    if (width < 1 || height < 1 || width > 32768 || height > 32768)
        return bad(e, n, "Invalid detector dimensions");
    if (!isfinite(c->exposure_ms) || c->exposure_ms < .01 || c->exposure_ms > 3600000 ||
        !isfinite(c->timeout_s) || c->timeout_s <= c->exposure_ms / 1000 || c->timeout_s > 7200)
        return bad(e, n, "Invalid exposure or acquisition timeout");
    if (c->frames < 1 || c->frames > 100 || c->hbin < 1 || c->vbin < 1 || c->hbin > 32768 ||
        c->vbin > 32768)
        return bad(e, n, "Invalid bin or frame count");
    if (c->read_mode != 0 && c->read_mode != 3 && c->read_mode != 4)
        return bad(e, n, "Read mode must be FVB, Single Track or Image");
    if (c->ad < 0 || c->amp < 0 || c->hs < 0 || c->vs < -1 || c->preamp < 0 || c->shutter < -1 ||
        c->shutter > 2 || c->shutter_ttl < 0 || c->shutter_ttl > 1 || c->shutter_open_ms < 0 ||
        c->shutter_close_ms < 0 || c->temperature < -150 || c->temperature > 30)
        return bad(e, n, "Invalid camera parameter index");
    if (c->read_mode == 4) {
        if (c->x0 < 1 || c->x0 > x1 || x1 > width || c->y0 < 1 || c->y0 > y1 || y1 > height)
            return bad(e, n, "ROI must lie inside detector (1-based inclusive)");
        if ((x1 - c->x0 + 1) % c->hbin || (y1 - c->y0 + 1) % c->vbin)
            return bad(e, n, "ROI dimensions must divide by bin");
        s->rows = (y1 - c->y0 + 1) / c->vbin;
        s->cols = (x1 - c->x0 + 1) / c->hbin;
        s->first_pixel = c->x0 - 1 + (c->hbin - 1) / 2.;
    } else {
        if (width % c->hbin)
            return bad(e, n, "Detector width must divide by horizontal bin");
        if (c->read_mode == 3 && (c->track_height < 1 || center - c->track_height / 2 < 1 ||
                                  center - c->track_height / 2 + c->track_height - 1 > height))
            return bad(e, n, "Single Track lies outside detector");
        s->rows = 1;
        s->cols = width / c->hbin;
        s->first_pixel = (c->hbin - 1) / 2.;
    }
    s->pixels = (size_t)s->rows * s->cols;
    if (s->pixels > VUV_MAX_PIXELS)
        return bad(e, n, "Frame exceeds software memory limit");
    s->x0 = c->x0;
    s->x1 = x1;
    s->y0 = c->y0;
    s->y1 = y1;
    s->track_center = center;
    return 1;
}
int vuv_target_allowed(double x, const VuvLimits *l, char *e, size_t n) {
    double lo = fmax(l->local_min, l->controller_min), hi = fmin(l->local_max, l->controller_max);
    if (!isfinite(x) || !isfinite(lo) || !isfinite(hi) || lo > hi || x < lo || x > hi)
        return bad(e, n, "Target %.9g deg outside allowed software range [%.9g, %.9g]", x, lo, hi);
    return 1;
}
int vuv_signal_range(const VuvPlan *p, int cols, int *lo, int *hi, char *e, size_t n) {
    *lo = p->signal_first;
    *hi = p->signal_last < 0 ? cols - 1 : p->signal_last;
    if (p->signal_last < -1 || *lo < 0 || *lo > *hi || *hi >= cols)
        return bad(e, n, "Signal column range is outside output spectrum");
    return 1;
}
int vuv_point_target(const VuvPlan *p, const VuvCalibration *c, int index, double *out, char *e,
                     size_t n) {
    double value = p->start + index * p->step;
    if (!isfinite(value))
        return bad(e, n, "Target overflow");
    if (p->coordinate == VUV_WAVELENGTH)
        return vuv_cal_inverse(c, value, out, e, n);
    *out = value;
    return 1;
}
int vuv_plan_resolve(const VuvPlan *p, const VuvCameraConfig *cam, const VuvCalibration *cal,
                     const VuvLimits *limits, int simulated_motor, double cycle, double query_s,
                     size_t bytes, VuvResolved *r, char *e, size_t n) {
    double end;
    memset(r, 0, sizeof *r);
    if (p->points < 1 || p->points > VUV_MAX_POINTS || p->mode < 0 || p->mode > 1 ||
        p->coordinate < 0 || p->coordinate > 1 || !isfinite(p->start) || !isfinite(p->step) ||
        !isfinite(p->settle_s) || p->settle_s < 0 || p->settle_s > 60)
        return bad(e, n, "Invalid scan type, points, coordinates or settle time");
    if (cal->enabled && cal->simulation_only && !simulated_motor)
        return bad(e, n, "Simulation calibration cannot be used with a real motor");
    if (p->coordinate == VUV_WAVELENGTH) {
        if (!vuv_cal_inverse(cal, p->start, &r->start_angle, e, n))
            return 0;
    } else
        r->start_angle = p->start;
    if (p->mode == VUV_POINT) {
        if (p->points > 1 && p->step == 0)
            return bad(e, n, "Point scan step cannot be zero");
        if (!vuv_point_target(p, cal, p->points - 1, &end, e, n))
            return 0;
        r->last_angle = end;
        r->guard_angle = end;
    } else {
        if (!isfinite(p->velocity) || fabs(p->velocity) < 1e-6 || fabs(p->velocity) > 360 ||
            !isfinite(p->period_s) || p->period_s < .05 || p->period_s > 3600 ||
            !isfinite(p->lead_s) || p->lead_s < .1 || p->lead_s > 30 ||
            p->points * p->period_s > 86400)
            return bad(e, n, "Invalid continuous speed, period or duration");
        if (!isfinite(cycle) || cycle <= 0 || !isfinite(query_s) || query_s < 0)
            return bad(e, n, "Invalid acquisition or serial timing");
        r->min_period_s = cam->frames * cycle + 4 * query_s + .035 +
                          cam->frames * (double)bytes / (50 * 1024 * 1024);
        if (p->period_s < r->min_period_s)
            return bad(e, n, "Sampling period too short: at least %.4f s required",
                       r->min_period_s);
        r->duration_s =
            p->lead_s + (p->points - 1) * p->period_s + r->min_period_s + fmax(1, 2 * p->period_s);
        r->guard_angle = r->start_angle + p->velocity * r->duration_s;
        r->last_angle = r->guard_angle;
        r->frame_motion_deg = fabs(p->velocity) * cam->exposure_ms / 1000;
        if (p->coordinate == VUV_WAVELENGTH &&
            (r->guard_angle < cal->lo || r->guard_angle > cal->hi))
            return bad(e, n, "Continuous guard target exceeds calibration domain");
    }
    return vuv_target_allowed(r->start_angle, limits, e, n) &&
           vuv_target_allowed(r->last_angle, limits, e, n);
}
double vuv_position_estimate(double p0, double t0, double p1, double t1, double mid) {
    double f;
    if (!isfinite(p0) || !isfinite(p1) || !isfinite(mid) || t1 <= t0)
        return NAN;
    f = (mid - t0) / (t1 - t0);
    f = fmax(0, fmin(1, f));
    return p0 + (p1 - p0) * f;
}
void vuv_reduce_frame(const int32_t *raw, int rows, int cols, int row_mean, double *scratch,
                      double *average, int frame) {
    int x, y;
    memset(scratch, 0, (size_t)cols * sizeof *scratch);
    for (y = 0; y < rows; y++)
        for (x = 0; x < cols; x++)
            scratch[x] += (double)raw[(size_t)y * cols + x];
    for (x = 0; x < cols; x++) {
        double value = row_mean ? scratch[x] / rows : scratch[x];
        if (frame == 1)
            average[x] = value;
        else
            average[x] += (value - average[x]) / frame;
    }
}
double vuv_integrate(const double *s, int lo, int hi) {
    double sum = 0;
    int i;
    for (i = lo; i <= hi; i++)
        sum += s[i];
    return sum;
}
int vuv_npy_frame(void *file, const int32_t *raw, int rows, int cols) {
    FILE *f = (FILE *)file;
    char header[256];
    unsigned char length[2];
    size_t count, base, padding, i;
    uint32_t endian = 1;
    if (rows < 1 || cols < 1 || *(unsigned char *)&endian != 1)
        return 0;
    count = (size_t)rows * cols;
    if (count > VUV_MAX_PIXELS)
        return 0;
    base = (size_t)snprintf(header, sizeof header,
                            "{'descr': '<i4', 'fortran_order': False, 'shape': (%d, %d), }", rows,
                            cols);
    padding = (16 - (10 + base + 1) % 16) % 16;
    for (i = 0; i < padding; i++)
        header[base++] = ' ';
    header[base++] = '\n';
    length[0] = (unsigned char)(base & 255);
    length[1] = (unsigned char)(base >> 8);
    return fwrite("\x93NUMPY\x01\x00", 1, 8, f) == 8 && fwrite(length, 1, 2, f) == 2 &&
           fwrite(header, 1, base, f) == base && fwrite(raw, sizeof *raw, count, f) == count;
}
