#ifndef VUV_CORE_H
#define VUV_CORE_H
#include <stddef.h>
#include <stdint.h>
#define VUV_VERSION "3.0.0"
#define VUV_MAX_POINTS 50000
#define VUV_MAX_PIXELS 64000000u
enum { VUV_POINT = 0, VUV_CONTINUOUS = 1, VUV_CAMERA = 2 };
enum { VUV_ANGLE = 0, VUV_WAVELENGTH = 1 };
typedef struct {
    int enabled, degree, simulation_only;
    double a[4], lo, hi, reference_pixel;
} VuvCalibration;
typedef struct {
    double exposure_ms, timeout_s;
    int frames, read_mode, hbin, vbin, x0, x1, y0, y1, track_center, track_height;
    int ad, amp, hs, vs, preamp, shutter, shutter_ttl, shutter_open_ms, shutter_close_ms;
    int temperature, require_stable, row_mean;
} VuvCameraConfig;
typedef struct {
    int mode, coordinate, points, signal_first, signal_last;
    double start, step, settle_s, velocity, period_s, lead_s;
} VuvPlan;
typedef struct {
    double local_min, local_max, controller_min, controller_max, tolerance;
} VuvLimits;
typedef struct {
    int rows, cols, x0, x1, y0, y1, track_center;
    double first_pixel;
    size_t pixels;
} VuvShape;
typedef struct {
    double start_angle, last_angle, guard_angle, min_period_s, duration_s, frame_motion_deg;
} VuvResolved;
typedef struct {
    int point, mode, frames;
    double target, position, before, after, span, wavelength, intensity, peak, temperature;
    double exposure_s, scheduled_s, actual_s, delay_s;
    char begin_utc[40], end_utc[40];
} VuvSample;
VuvCameraConfig vuv_camera_defaults(void);
VuvPlan vuv_plan_defaults(void);
int vuv_cal_validate(const VuvCalibration *, char *, size_t);
double vuv_cal_eval(const VuvCalibration *, double);
int vuv_cal_inverse(const VuvCalibration *, double, double *, char *, size_t);
int vuv_cal_json(const char *, VuvCalibration *, char *, size_t);
int vuv_shape(const VuvCameraConfig *, int, int, VuvShape *, char *, size_t);
int vuv_plan_resolve(const VuvPlan *, const VuvCameraConfig *, const VuvCalibration *,
                     const VuvLimits *, int, double, double, size_t, VuvResolved *, char *, size_t);
int vuv_point_target(const VuvPlan *, const VuvCalibration *, int, double *, char *, size_t);
int vuv_signal_range(const VuvPlan *, int, int *, int *, char *, size_t);
int vuv_target_allowed(double, const VuvLimits *, char *, size_t);
double vuv_position_estimate(double, double, double, double, double);
void vuv_reduce_frame(const int32_t *, int, int, int, double *, double *, int);
double vuv_integrate(const double *, int, int);
/* Writes portable NPY v1.0: little-endian signed 32-bit frames. */
int vuv_npy_frame(void *file, const int32_t *, int, int);
#endif
