#include "native.h"
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <wchar.h>
_Static_assert(sizeof(LONG) == 4, "SDK2 Windows long must be 32-bit");
enum { SDK_OK = 20002, SDK_ACQUIRING = 20072, SDK_IDLE = 20073 };
static int cancelled(HANDLE e) {
    return e && WaitForSingleObject(e, 0) == WAIT_OBJECT_0;
}
int motor_ready(int s) {
    return s >= 0x32 && s <= 0x35;
}
void motor_create(Motor *m) {
    memset(m, 0, sizeof *m);
    InitializeCriticalSection(&m->io);
    m->port = INVALID_HANDLE_VALUE;
    m->velocity = 2;
}
static void motor_sim_update(Motor *m) {
    if (m->moving) {
        double delta = m->target - m->origin, travel = m->velocity * (native_now() - m->started);
        if (travel >= fabs(delta)) {
            m->position = m->target;
            m->moving = 0;
            m->state = 0x33;
        } else
            m->position = m->origin + copysign(travel, delta);
    }
}
static int motor_write(Motor *m, const char *cmd, const char *arg, wchar_t *e) {
    char data[128];
    DWORD n = 0;
    int len = snprintf(data, sizeof data, "%d%s%s\r\n", m->config.address, cmd, arg ? arg : "");
    if (m->port == INVALID_HANDLE_VALUE || !WriteFile(m->port, data, (DWORD)len, &n, NULL) ||
        n != (DWORD)len)
        return native_error(e, L"SMC100 %hs 写入失败 (Win32 %lu)", cmd, GetLastError());
    return 1;
}
static int motor_query_raw(Motor *m, const char *cmd, const char *suffix, char *out, size_t cap,
                           wchar_t *e) {
    char line[512], sent[128], prefix[32], ch;
    size_t used = 0;
    DWORD got;
    double until = native_now() + m->config.timeout_s;
    PurgeComm(m->port, PURGE_RXCLEAR);
    snprintf(sent, sizeof sent, "%d%s%s", m->config.address, cmd, suffix);
    snprintf(prefix, sizeof prefix, "%d%s", m->config.address, cmd);
    if (!motor_write(m, cmd, suffix, e))
        return 0;
    while (native_now() < until) {
        got = 0;
        if (!ReadFile(m->port, &ch, 1, &got, NULL))
            return native_error(e, L"SMC100 串口读取失败 (%lu)", GetLastError());
        if (!got)
            continue;
        if (ch == '\r' || ch == '\n') {
            line[used] = 0;
            used = 0;
            if (!line[0] || !strcmp(line, sent))
                continue;
            if (!strncmp(line, prefix, strlen(prefix))) {
                const char *value = line + strlen(prefix);
                while (*value == ' ' || *value == '=')
                    value++;
                if (strlen(value) >= cap)
                    return native_error(e, L"SMC100 返回值过长");
                strcpy(out, value);
                return 1;
            }
        } else {
            if (used >= sizeof line - 1)
                return native_error(e, L"SMC100 返回行过长");
            line[used++] = ch;
        }
    }
    return native_error(e, L"SMC100 %hs 查询超时，请核对串口、地址和流控", cmd);
}
static int motor_query(Motor *m, const char *cmd, char *out, size_t n, wchar_t *e) {
    return motor_query_raw(m, cmd, m->suffix ? "?" : "", out, n, e);
}
static int parse_double(const char *s, double *out) {
    char *end;
    double v = strtod(s, &end);
    while (isspace((unsigned char)*end))
        end++;
    if (end == s || *end || !isfinite(v))
        return 0;
    *out = v;
    return 1;
}
static int command_error(Motor *m, wchar_t *e) {
    char value[64];
    if (!motor_query(m, "TE", value, sizeof value, e) &&
        !motor_query_raw(m, "TE", "", value, sizeof value, e))
        return 0;
    if (strcmp(value, "@") && strcmp(value, "0") && value[0])
        return native_error(e, L"SMC100 命令被拒绝，TE=%hs", value);
    return 1;
}
int motor_status(Motor *m, int *state, wchar_t *e) {
    char value[128];
    unsigned bits, s;
    int i, ok = 0;
    EnterCriticalSection(&m->io);
    if (!m->connected) {
        native_error(e, L"电机未连接");
        goto end;
    }
    if (m->simulated) {
        motor_sim_update(m);
        *state = m->state;
        ok = 1;
        goto end;
    }
    if (!motor_query(m, "TS", value, sizeof value, e))
        goto end;
    if (strlen(value) != 6) {
        native_error(e, L"SMC100 TS 格式错误");
        goto end;
    }
    for (i = 0; i < 6; i++)
        if (!isxdigit((unsigned char)value[i])) {
            native_error(e, L"SMC100 TS 非十六进制");
            goto end;
        }
    if (sscanf(value, "%4x%2x", &bits, &s) != 2) {
        native_error(e, L"无效TS返回");
        goto end;
    }
    m->state = (int)s;
    if (bits) {
        native_error(e, L"SMC100 错误位 0x%04X，状态 0x%02X", bits, s);
        goto end;
    }
    *state = (int)s;
    ok = 1;
end:
    LeaveCriticalSection(&m->io);
    return ok;
}
int motor_position(Motor *m, double *position, wchar_t *e) {
    char value[128];
    int ok = 0;
    EnterCriticalSection(&m->io);
    if (!m->connected) {
        native_error(e, L"电机未连接");
        goto end;
    }
    if (m->simulated) {
        motor_sim_update(m);
        *position = m->position;
        ok = 1;
        goto end;
    }
    if (!motor_query(m, "TP", value, sizeof value, e))
        goto end;
    if (!parse_double(value, position)) {
        native_error(e, L"SMC100 TP 不是有效位置");
        goto end;
    }
    m->position = *position;
    ok = 1;
end:
    LeaveCriticalSection(&m->io);
    return ok;
}
int motor_velocity(Motor *m, double *value, wchar_t *e) {
    char s[128];
    int ok = 0;
    EnterCriticalSection(&m->io);
    if (!m->connected) {
        native_error(e, L"电机未连接");
        goto end;
    }
    if (m->simulated) {
        *value = m->velocity;
        ok = 1;
        goto end;
    }
    if (!motor_query_raw(m, "VA", "?", s, sizeof s, e) || !parse_double(s, value) || *value <= 0) {
        native_error(e, L"无法读取有效 VA 速度");
        goto end;
    }
    m->velocity = *value;
    ok = 1;
end:
    LeaveCriticalSection(&m->io);
    return ok;
}
int motor_set_velocity(Motor *m, double value, wchar_t *e) {
    int state, ok = 0;
    double actual;
    char arg[64];
    EnterCriticalSection(&m->io);
    if (!isfinite(value) || value < 1e-6 || value > 360) {
        native_error(e, L"速度应在 0.000001～360 °/s");
        goto end;
    }
    if (!motor_status(m, &state, e) || !motor_ready(state)) {
        native_error(e, L"设置速度前电机须 READY");
        goto end;
    }
    if (m->simulated) {
        m->velocity = value;
        ok = 1;
        goto end;
    }
    snprintf(arg, sizeof arg, "%.10f", value);
    if (!motor_write(m, "VA", arg, e) || !command_error(m, e) || !motor_velocity(m, &actual, e))
        goto end;
    if (fabs(actual - value) > fmax(1e-7, value * .005)) {
        native_error(e, L"VA 速度回读与设定不符");
        goto end;
    }
    ok = 1;
end:
    LeaveCriticalSection(&m->io);
    return ok;
}
int motor_stop(Motor *m, wchar_t *e) {
    int ok = 1;
    EnterCriticalSection(&m->io);
    if (m->connected) {
        if (m->simulated) {
            motor_sim_update(m);
            m->moving = 0;
            m->state = 0x33;
            m->stops++;
        } else
            ok = motor_write(m, "ST", "", e);
    }
    LeaveCriticalSection(&m->io);
    return ok;
}
void motor_close(Motor *m) {
    wchar_t e[VUV_ERR];
    EnterCriticalSection(&m->io);
    if (m->connected)
        motor_stop(m, e);
    if (m->port != INVALID_HANDLE_VALUE) {
        CloseHandle(m->port);
        m->port = INVALID_HANDLE_VALUE;
    }
    m->connected = 0;
    m->moving = 0;
    LeaveCriticalSection(&m->io);
}
int motor_connect(Motor *m, const MotorConfig *cfg, wchar_t *e) {
    wchar_t port[96];
    DCB dcb;
    COMMTIMEOUTS timeouts;
    char s[128];
    int state, ok = 0;
    double position;
    EnterCriticalSection(&m->io);
    motor_close(m);
    m->config = *cfg;
    m->simulated = cfg->simulated;
    m->suffix = 1;
    if (cfg->limits.local_min >= cfg->limits.local_max || cfg->limits.tolerance <= 0 ||
        cfg->address < 1 || cfg->address > 31) {
        native_error(e, L"无效串口地址或本机角度保护");
        goto done;
    }
    if (m->simulated) {
        m->connected = 1;
        m->position = 0;
        m->velocity = 2;
        m->lower = -180;
        m->upper = 180;
        m->state = 0x32;
        strcpy(m->version, "SIM-3.0");
        strcpy(m->positioner, "SIMULATED ROTARY MOTOR");
        ok = 1;
        goto done;
    }
    if (!wcsncmp(cfg->port, L"\\\\.\\", 4))
        swprintf(port, 96, L"%ls", cfg->port);
    else
        swprintf(port, 96, L"\\\\.\\%ls", cfg->port);
    m->port = CreateFileW(port, GENERIC_READ | GENERIC_WRITE, 0, NULL, OPEN_EXISTING,
                          FILE_ATTRIBUTE_NORMAL, NULL);
    if (m->port == INVALID_HANDLE_VALUE) {
        native_error(e, L"无法打开 %ls (Win32 %lu)", cfg->port, GetLastError());
        goto done;
    }
    memset(&dcb, 0, sizeof dcb);
    dcb.DCBlength = sizeof dcb;
    if (!GetCommState(m->port, &dcb)) {
        native_error(e, L"读取串口配置失败");
        goto done;
    }
    dcb.BaudRate = (DWORD)cfg->baud;
    dcb.ByteSize = 8;
    dcb.Parity = NOPARITY;
    dcb.StopBits = ONESTOPBIT;
    dcb.fBinary = TRUE;
    dcb.fParity = FALSE;
    dcb.fOutxCtsFlow = FALSE;
    dcb.fOutxDsrFlow = FALSE;
    dcb.fDtrControl = DTR_CONTROL_ENABLE;
    dcb.fRtsControl = RTS_CONTROL_ENABLE;
    dcb.fDsrSensitivity = FALSE;
    dcb.fOutX = dcb.fInX = (DWORD)cfg->xonxoff;
    dcb.XonChar = 0x11;
    dcb.XoffChar = 0x13;
    dcb.fAbortOnError = FALSE;
    if (!SetCommState(m->port, &dcb)) {
        native_error(e, L"设置串口参数失败");
        goto done;
    }
    memset(&timeouts, 0, sizeof timeouts);
    timeouts.ReadIntervalTimeout = MAXDWORD;
    timeouts.ReadTotalTimeoutConstant = 35;
    timeouts.WriteTotalTimeoutConstant = (DWORD)(cfg->timeout_s * 1000);
    if (!SetCommTimeouts(m->port, &timeouts)) {
        native_error(e, L"设置串口超时失败");
        goto done;
    }
    SetupComm(m->port, 4096, 4096);
    PurgeComm(m->port, PURGE_RXCLEAR | PURGE_TXCLEAR);
    if (!motor_query_raw(m, "TS", "?", s, sizeof s, e)) {
        if (!motor_query_raw(m, "TS", "", s, sizeof s, e))
            goto done;
        m->suffix = 0;
    }
    m->connected = 1;
    if (!motor_status(m, &state, e))
        goto done;
    if (!motor_query(m, "VE", m->version, sizeof m->version, e) &&
        !motor_query_raw(m, "VE", "", m->version, sizeof m->version, e))
        goto done;
    if ((strstr(m->version, "SMC100PP") && !cfg->pp) ||
        (strstr(m->version, "SMC100CC") && cfg->pp)) {
        native_error(e, L"返回的控制器型号与所选 CC/PP 不一致");
        goto done;
    }
    if (!motor_query_raw(m, "ID", "?", m->positioner, sizeof m->positioner, e))
        strcpy(m->positioner, "ID not returned");
    if (!motor_query_raw(m, "SL", "?", s, sizeof s, e) || !parse_double(s, &m->lower) ||
        !motor_query_raw(m, "SR", "?", s, sizeof s, e) || !parse_double(s, &m->upper) ||
        m->lower >= m->upper) {
        native_error(e, L"读取 SL/SR 控制器软件限位失败");
        goto done;
    }
    if (!motor_position(m, &position, e))
        goto done;
    /* Clear the old command-error register once, without changing configuration. */
    if (!motor_query(m, "TE", s, sizeof s, e) && !motor_query_raw(m, "TE", "", s, sizeof s, e))
        goto done;
    ok = 1;
done:
    if (!ok) {
        if (m->port != INVALID_HANDLE_VALUE) {
            CloseHandle(m->port);
            m->port = INVALID_HANDLE_VALUE;
        }
        m->connected = 0;
    }
    LeaveCriticalSection(&m->io);
    return ok;
}
int motor_start(Motor *m, double target, HANDLE cancel, wchar_t *e) {
    int state, ok = 0;
    char arg[64], why[256];
    VuvLimits l;
    EnterCriticalSection(&m->io);
    l = m->config.limits;
    l.controller_min = m->lower;
    l.controller_max = m->upper;
    if (!vuv_target_allowed(target, &l, why, sizeof why)) {
        native_core_error(e, why);
        goto end;
    }
    if (!motor_status(m, &state, e) || !motor_ready(state)) {
        native_error(e, L"电机未 READY，请先处理状态或显式归零");
        goto end;
    }
    if (cancelled(cancel)) {
        native_error(e, L"运动发送前已停止");
        goto end;
    }
    if (m->simulated) {
        motor_sim_update(m);
        m->origin = m->position;
        m->target = target;
        m->started = native_now();
        m->moving = 1;
        m->state = 0x28;
        m->commands++;
        ok = 1;
        goto end;
    }
    snprintf(arg, sizeof arg, "%.10f", target);
    if (!motor_write(m, "PA", arg, e) || !command_error(m, e))
        goto end;
    m->commands++;
    ok = 1;
end:
    LeaveCriticalSection(&m->io);
    return ok;
}
int motor_wait_ready(Motor *m, double target, int check_target, HANDLE cancel, double timeout,
                     wchar_t *e) {
    double until = native_now() + timeout, position;
    int state, count = 0;
    wchar_t ignored[VUV_ERR];
    while (native_now() < until) {
        if (cancelled(cancel)) {
            motor_stop(m, ignored);
            return native_error(e, L"运动已停止");
        }
        if (!motor_status(m, &state, e) || !motor_position(m, &position, e))
            return 0;
        if (motor_ready(state) &&
            (!check_target || fabs(position - target) <= m->config.limits.tolerance)) {
            if (++count >= 3)
                return 1;
        } else
            count = 0;
        if (!motor_ready(state) && state != 0x28 && state != 0x1e && state != 0x1f) {
            motor_stop(m, ignored);
            return native_error(e, L"电机退出允许状态 0x%02X", state);
        }
        if (!native_wait(cancel, .02)) {
            motor_stop(m, ignored);
            return native_error(e, L"运动已停止");
        }
    }
    motor_stop(m, ignored);
    return native_error(e, L"运动/停止确认超时，未继续采集");
}
int motor_move(Motor *m, double target, HANDLE cancel, wchar_t *e) {
    return motor_start(m, target, cancel, e) &&
           motor_wait_ready(m, target, 1, cancel, m->config.move_timeout_s, e);
}
int motor_home(Motor *m, HANDLE cancel, wchar_t *e) {
    int state, ok = 0;
    EnterCriticalSection(&m->io);
    if (!motor_status(m, &state, e))
        goto end;
    if (motor_ready(state)) {
        LeaveCriticalSection(&m->io);
        return motor_move(m, 0, cancel, e);
    }
    if (state < 0x0a || state > 0x11) {
        native_error(e, L"当前状态不允许归零");
        goto end;
    }
    if (cancelled(cancel)) {
        native_error(e, L"归零发送前已停止");
        goto end;
    }
    if (m->simulated) {
        m->origin = m->position;
        m->target = 0;
        m->started = native_now();
        m->moving = 1;
        m->state = 0x1e;
        ok = 1;
    } else
        ok = motor_write(m, "OR", "", e) && command_error(m, e);
end:
    LeaveCriticalSection(&m->io);
    if (ok)
        ok = motor_wait_ready(m, 0, 0, cancel, m->config.move_timeout_s, e);
    return ok;
}

void camera_create(Camera *c) {
    memset(c, 0, sizeof *c);
    InitializeCriticalSection(&c->io);
    c->temperature = NAN;
    c->target = -70;
    c->rng = 940;
}
static int sdk_ok(unsigned code, const char *api, wchar_t *e) {
    if (code != SDK_OK)
        return native_error(e, L"Andor %hs 返回 %u；请查 SDK2 错误码", api, code);
    return 1;
}
static int sdk_bind(Camera *c, wchar_t *e) {
    FARPROC p;
#define BIND(name)                                                                                 \
    do {                                                                                           \
        p = GetProcAddress(c->dll, #name);                                                         \
        if (!p)                                                                                    \
            return native_error(e, L"SDK2 缺少 %hs", #name);                                       \
        memcpy(&c->sdk.name, &p, sizeof p);                                                        \
    } while (0)
    BIND(GetAvailableCameras);
    BIND(GetCameraHandle);
    BIND(SetCurrentCamera);
    BIND(Initialize);
    BIND(ShutDown);
    BIND(GetDetector);
    BIND(GetHeadModel);
    BIND(GetCameraSerialNumber);
    BIND(GetTemperatureRange);
    BIND(GetTemperatureF);
    BIND(IsCoolerOn);
    BIND(SetTemperature);
    BIND(CoolerON);
    BIND(CoolerOFF);
    BIND(GetStatus);
    BIND(SetAcquisitionMode);
    BIND(SetTriggerMode);
    BIND(SetReadMode);
    BIND(SetExposureTime);
    BIND(GetAcquisitionTimings);
    BIND(SetImage);
    BIND(SetFVBHBin);
    BIND(SetSingleTrack);
    BIND(SetSingleTrackHBin);
    BIND(GetNumberADChannels);
    BIND(GetNumberAmp);
    BIND(SetADChannel);
    BIND(SetOutputAmplifier);
    BIND(GetNumberHSSpeeds);
    BIND(GetHSSpeed);
    BIND(SetHSSpeed);
    BIND(GetNumberPreAmpGains);
    BIND(GetPreAmpGain);
    BIND(IsPreAmpGainAvailable);
    BIND(SetPreAmpGain);
    BIND(GetNumberVSSpeeds);
    BIND(GetVSSpeed);
    BIND(SetVSSpeed);
    BIND(GetFastestRecommendedVSSpeed);
    BIND(SetShutter);
    BIND(PrepareAcquisition);
    BIND(StartAcquisition);
    BIND(AbortAcquisition);
    BIND(GetAcquiredData);
#undef BIND
    return 1;
}
int camera_temperature(Camera *c, wchar_t *e) {
    int ok = 0;
    unsigned code;
    float f;
    EnterCriticalSection(&c->io);
    if (!c->initialized) {
        native_error(e, L"相机未初始化");
        goto done;
    }
    if (c->simulated) {
        double now = native_now(), dt = now - c->temperature_at,
               target = c->cooler_on ? c->target : 20;
        c->temperature_at = now;
        c->temperature += fmax(-dt * 20, fmin(dt * 20, target - c->temperature));
        c->temp_stable = c->cooler_on && fabs(c->temperature - target) < .2;
        ok = 1;
        goto done;
    }
    code = c->sdk.GetTemperatureF(&f);
    if (code == 20039) {
        c->temperature = NAN;
        c->temp_stable = 0;
        ok = 1;
        goto done;
    }
    if (code != SDK_OK && (code < 20034 || code > 20040)) {
        sdk_ok(code, "GetTemperatureF", e);
        goto done;
    }
    c->temperature = f;
    c->temp_stable = code == 20036;
    ok = 1;
done:
    LeaveCriticalSection(&c->io);
    return ok;
}
int camera_cooler(Camera *c, int on, int target, wchar_t *e) {
    int ok = 0;
    EnterCriticalSection(&c->io);
    if (!c->initialized) {
        native_error(e, L"相机未初始化");
        goto end;
    }
    if (on && (target < c->temp_min || target > c->temp_max)) {
        native_error(e, L"目标温度超出相机范围");
        goto end;
    }
    if (!c->simulated) {
        if (on) {
            if (!sdk_ok(c->sdk.SetTemperature(target), "SetTemperature", e) ||
                !sdk_ok(c->sdk.CoolerON(), "CoolerON", e))
                goto end;
        } else if (!sdk_ok(c->sdk.CoolerOFF(), "CoolerOFF", e))
            goto end;
    }
    c->cooler_on = on;
    if (on)
        c->target = target;
    ok = camera_temperature(c, e);
end:
    LeaveCriticalSection(&c->io);
    return ok;
}
int camera_abort(Camera *c, wchar_t *e) {
    int ok = 1;
    unsigned code;
    EnterCriticalSection(&c->io);
    if (c->initialized && !c->simulated) {
        code = c->sdk.AbortAcquisition();
        if (code != SDK_OK && code != SDK_IDLE)
            ok = sdk_ok(code, "AbortAcquisition", e);
    }
    LeaveCriticalSection(&c->io);
    return ok;
}
int camera_close(Camera *c, wchar_t *e) {
    int ok = 0;
    EnterCriticalSection(&c->io);
    if (c->initialized) {
        if (!camera_temperature(c, e))
            goto end;
        if (!c->simulated && (!isfinite(c->temperature) || c->temperature < 0)) {
            if (!camera_cooler(c, 0, 0, e))
                goto end;
            native_error(e, L"相机回温中；达到0℃并确认后再断开，请保持供电和连接");
            goto end;
        }
        if (!camera_abort(c, e))
            goto end;
        if (!c->simulated && !sdk_ok(c->sdk.ShutDown(), "ShutDown", e))
            goto end;
    }
    c->initialized = c->connected = c->configured = 0;
    if (c->dll) {
        FreeLibrary(c->dll);
        c->dll = NULL;
    }
    ok = 1;
end:
    LeaveCriticalSection(&c->io);
    return ok;
}
int camera_connect(Camera *c, int simulated, const wchar_t *path, int index, wchar_t *e) {
    int ok = 0, on = 0;
    LONG total = 0, handle = 0;
    char dir_a[VUV_PATH], model[256];
    wchar_t dir[VUV_PATH], *slash;
    BOOL replacement = FALSE;
    EnterCriticalSection(&c->io);
    if (c->initialized && !camera_close(c, e))
        goto end;
    c->simulated = simulated;
    c->connected = 0;
    c->configured = 0;
    if (simulated) {
        c->initialized = c->connected = 1;
        c->cooler_on = c->temp_stable = 0;
        c->width = 2048;
        c->height = 512;
        c->serial = 940;
        c->temperature = 20;
        c->temperature_at = native_now();
        c->temp_min = -100;
        c->temp_max = 20;
        c->ad_count = c->amp_count = c->hs_count = c->vs_count = c->gain_count = 2;
        strcpy(c->model, "SIM CCD (not actual Newton dimensions)");
        ok = 1;
        goto end;
    }
    if (!path || !path[0] || wcslen(path) >= VUV_PATH || index < 0 || index > 31) {
        native_error(e, L"请输入有效的64位 SDK2 DLL 路径和相机索引");
        goto end;
    }
    wcscpy(c->dll_path, path);
    wcscpy(dir, path);
    slash = wcsrchr(dir, L'\\');
    if (!slash)
        slash = wcsrchr(dir, L'/');
    if (slash)
        *slash = 0;
    else
        wcscpy(dir, L".");
    UINT ansi_page = GetACP();
    DWORD conversion_flags = ansi_page == CP_UTF8 ? WC_ERR_INVALID_CHARS : WC_NO_BEST_FIT_CHARS;
    BOOL *used_default = ansi_page == CP_UTF8 ? NULL : &replacement;
    if (!WideCharToMultiByte(ansi_page, conversion_flags, dir, -1, dir_a, sizeof dir_a, NULL,
                             used_default) ||
        replacement) {
        native_error(e, L"SDK 初始化目录无法使用当前 ANSI 编码，请使用兼容路径");
        goto end;
    }
    c->dll = LoadLibraryExW(path, NULL,
                            LOAD_LIBRARY_SEARCH_DLL_LOAD_DIR | LOAD_LIBRARY_SEARCH_DEFAULT_DIRS);
    if (!c->dll) {
        native_error(e, L"无法加载64位SDK2 DLL (Win32 %lu)，请检查驱动与依赖", GetLastError());
        goto end;
    }
    if (!sdk_bind(c, e))
        goto end;
#define SC(name, ...)                                                                              \
    do {                                                                                           \
        if (!sdk_ok(c->sdk.name(__VA_ARGS__), #name, e))                                           \
            goto end;                                                                              \
    } while (0)
    SC(GetAvailableCameras, &total);
    if (index >= total) {
        native_error(e, L"SDK仅检测到 %ld 台相机", total);
        goto end;
    }
    SC(GetCameraHandle, (LONG)index, &handle);
    SC(SetCurrentCamera, handle);
    SC(Initialize, dir_a);
    c->initialized = 1;
    SC(GetDetector, &c->width, &c->height);
    if (c->width < 1 || c->height < 1 || c->width > 32768 || c->height > 32768) {
        native_error(e, L"SDK 探测器尺寸无效");
        goto end;
    }
    memset(model, 0, sizeof model);
    SC(GetHeadModel, model);
    snprintf(c->model, sizeof c->model, "%.127s", model);
    SC(GetCameraSerialNumber, &c->serial);
    SC(GetTemperatureRange, &c->temp_min, &c->temp_max);
    SC(IsCoolerOn, &on);
    c->cooler_on = on;
    SC(GetNumberADChannels, &c->ad_count);
    SC(GetNumberAmp, &c->amp_count);
    SC(GetNumberHSSpeeds, 0, 0, &c->hs_count);
    SC(GetNumberVSSpeeds, &c->vs_count);
    SC(GetNumberPreAmpGains, &c->gain_count);
    if (!camera_temperature(c, e))
        goto end;
    c->connected = 1;
    ok = 1;
#undef SC
end:
    if (!ok && !c->initialized && c->dll) {
        FreeLibrary(c->dll);
        c->dll = NULL;
    }
    LeaveCriticalSection(&c->io);
    return ok;
}
int camera_configure(Camera *c, const VuvCameraConfig *cfg, wchar_t *e) {
    VuvShape shape;
    char why[256];
    int ok = 0, state = SDK_IDLE, n, yes = 0, vs = cfg->vs;
    float exposure, accum, cycle, speed;
    EnterCriticalSection(&c->io);
    if (!c->connected) {
        native_error(e, L"相机未完整连接");
        goto done;
    }
    if (!vuv_shape(cfg, c->width, c->height, &shape, why, sizeof why)) {
        native_core_error(e, why);
        goto done;
    }
    if (!camera_temperature(c, e))
        goto done;
    if (cfg->require_stable && !c->temp_stable) {
        native_error(e, L"CCD温度尚未稳定");
        goto done;
    }
    if (cfg->ad >= c->ad_count || cfg->amp >= c->amp_count) {
        native_error(e, L"ADC/放大器索引超出相机范围");
        goto done;
    }
    if (c->simulated) {
        if (cfg->hs >= 2 || cfg->preamp >= 2 || cfg->vs >= 2) {
            native_error(e, L"模拟读出索引无效");
            goto done;
        }
        c->actual_exposure = cfg->exposure_ms / 1000;
        c->actual_cycle = c->actual_exposure + .01;
        c->hs_mhz = cfg->hs ? 3 : 1;
        c->vs_us = cfg->vs == 1 ? 16.5 : 8.25;
        c->gain = cfg->preamp ? 2 : 1;
        ok = 1;
        goto applied;
    }
#define SC(name, ...)                                                                              \
    do {                                                                                           \
        if (!sdk_ok(c->sdk.name(__VA_ARGS__), #name, e))                                           \
            goto done;                                                                             \
    } while (0)
    SC(GetStatus, &state);
    if (state != SDK_IDLE) {
        native_error(e, L"相机不是IDLE状态");
        goto done;
    }
    SC(GetNumberHSSpeeds, cfg->ad, cfg->amp, &n);
    c->hs_count = n;
    if (cfg->hs >= n) {
        native_error(e, L"水平速度索引不可用");
        goto done;
    }
    SC(IsPreAmpGainAvailable, cfg->ad, cfg->amp, cfg->hs, cfg->preamp, &yes);
    if (!yes || cfg->preamp >= c->gain_count) {
        native_error(e, L"当前组合的前置增益不可用");
        goto done;
    }
    if (vs == -1) {
        SC(GetFastestRecommendedVSSpeed, &vs, &speed);
    }
    if (vs < 0 || vs >= c->vs_count) {
        native_error(e, L"垂直读出速度不可用");
        goto done;
    }
    SC(GetHSSpeed, cfg->ad, cfg->amp, cfg->hs, &speed);
    c->hs_mhz = speed;
    SC(GetVSSpeed, vs, &speed);
    c->vs_us = speed;
    SC(GetPreAmpGain, cfg->preamp, &speed);
    c->gain = speed;
    SC(SetAcquisitionMode, 1);
    SC(SetTriggerMode, 0);
    SC(SetADChannel, cfg->ad);
    SC(SetOutputAmplifier, cfg->amp);
    SC(SetHSSpeed, cfg->amp, cfg->hs);
    SC(SetPreAmpGain, cfg->preamp);
    SC(SetVSSpeed, vs);
    SC(SetReadMode, cfg->read_mode);
    if (cfg->read_mode == 0) {
        SC(SetFVBHBin, cfg->hbin);
    } else if (cfg->read_mode == 3) {
        SC(SetSingleTrack, shape.track_center, cfg->track_height);
        SC(SetSingleTrackHBin, cfg->hbin);
    } else {
        SC(SetImage, cfg->hbin, cfg->vbin, shape.x0, shape.x1, shape.y0, shape.y1);
    }
    SC(SetExposureTime, (float)(cfg->exposure_ms / 1000));
    if (cfg->shutter >= 0) {
        SC(SetShutter, cfg->shutter_ttl, cfg->shutter, cfg->shutter_close_ms, cfg->shutter_open_ms);
    }
    SC(GetAcquisitionTimings, &exposure, &accum, &cycle);
    c->actual_exposure = exposure;
    c->actual_cycle = fmax(exposure, cycle);
    if (c->actual_exposure <= 0 || !isfinite(c->actual_cycle) ||
        cfg->timeout_s <= c->actual_cycle) {
        native_error(e, L"实际曝光/周期与超时不匹配");
        goto done;
    }
    SC(PrepareAcquisition);
    ok = 1;
#undef SC
applied:
    if (ok) {
        c->config = *cfg;
        c->shape = shape;
        c->configured = 1;
    }
done:
    LeaveCriticalSection(&c->io);
    return ok;
}
static double noise(Camera *c) {
    c->rng = 1664525u * c->rng + 1013904223u;
    return ((c->rng >> 8) / 16777216.0 - .5) * 6;
}
int camera_acquire(Camera *c, Motor *m, HANDLE cancel, int32_t *raw, wchar_t *e) {
    int state = SDK_ACQUIRING;
    double until, angle = 0;
    unsigned code;
    size_t y, x;
    wchar_t ignored[VUV_ERR];
    if (!c->configured)
        return native_error(e, L"相机参数尚未应用");
    if (cancelled(cancel))
        return native_error(e, L"采集已停止");
    c->frame_start = native_now();
    c->frame_mid = c->frame_start + c->actual_exposure / 2;
    if (c->simulated) {
        if (!native_wait(cancel, c->actual_exposure / 2))
            return native_error(e, L"模拟采集已停止");
        if (m && m->connected && !motor_position(m, &angle, e))
            return 0;
        if (!native_wait(cancel, c->actual_exposure / 2 + .01))
            return native_error(e, L"模拟采集已停止");
        for (y = 0; y < (size_t)c->shape.rows; y++)
            for (x = 0; x < (size_t)c->shape.cols; x++) {
                double p = c->shape.first_pixel + x * c->config.hbin,
                       envelope = .35 + 2.5 * exp(-pow((angle - 1.1) / .5, 2)) +
                                  1.5 * exp(-pow((angle + .7) / .35, 2));
                double s = 80 + 7000 * c->actual_exposure * envelope *
                                    (exp(-.5 * pow((p - (420 + 35 * angle)) / 18, 2)) +
                                     .65 * exp(-.5 * pow((p - (1000 - 20 * angle)) / 32, 2)) +
                                     .35 * exp(-.5 * pow((p - (1650 + 12 * angle)) / 22, 2)));
                if (c->config.shutter == 2)
                    s = 80;
                if (c->config.read_mode == 4) {
                    double fy = c->shape.rows > 1 ? -2 + 4. * y / (c->shape.rows - 1) : 0;
                    s *= .4 + exp(-fy * fy);
                }
                raw[y * c->shape.cols + x] = (int32_t)llround(s + noise(c));
            }
        c->frame_end = native_now();
        return 1;
    }
    EnterCriticalSection(&c->io);
    code = c->sdk.StartAcquisition();
    LeaveCriticalSection(&c->io);
    if (!sdk_ok(code, "StartAcquisition", e))
        return 0;
    until = native_now() + c->config.timeout_s;
    for (;;) {
        if (cancelled(cancel)) {
            camera_abort(c, ignored);
            return native_error(e, L"相机曝光已停止");
        }
        EnterCriticalSection(&c->io);
        code = c->sdk.GetStatus(&state);
        LeaveCriticalSection(&c->io);
        if (!sdk_ok(code, "GetStatus", e))
            return 0;
        if (state == SDK_IDLE)
            break;
        if (state != SDK_ACQUIRING) {
            camera_abort(c, ignored);
            return native_error(e, L"相机状态异常 %d", state);
        }
        if (native_now() > until) {
            camera_abort(c, ignored);
            return native_error(e, L"相机曝光/读出超时");
        }
        native_wait(cancel, .015);
    }
    EnterCriticalSection(&c->io);
    code = c->sdk.GetAcquiredData((LONG *)raw, (DWORD)c->shape.pixels);
    LeaveCriticalSection(&c->io);
    if (!sdk_ok(code, "GetAcquiredData", e))
        return 0;
    c->frame_end = native_now();
    if (cancelled(cancel))
        return native_error(e, L"采集读取后已停止");
    return 1;
}
