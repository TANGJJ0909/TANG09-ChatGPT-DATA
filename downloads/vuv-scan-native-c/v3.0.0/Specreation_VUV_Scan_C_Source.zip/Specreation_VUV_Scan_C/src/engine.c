#include "engine.h"
#include <math.h>
#include <wchar.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

typedef struct {
    wchar_t path[VUV_PATH];
    FILE *points, *spectra, *events;
    cJSON *manifest;
    int committed, partial_point, partial_frames;
} Store;
typedef struct {
    double position, when;
    int state;
    char utc[40];
} Position;
typedef struct {
    Engine *engine;
    Operation op;
} Job;
static int is_cancelled(Engine *e) {
    return WaitForSingleObject(e->cancel, 0) == WAIT_OBJECT_0;
}
static void notify(Engine *e) {
    if (e->window && !InterlockedExchange(&e->notify_pending, 1))
        PostMessageW(e->window, WM_VUV_UPDATE, 0, 0);
}
static void phase(Engine *e, int p, const wchar_t *message) {
    EnterCriticalSection(&e->state_lock);
    e->ui.phase = p;
    wcsncpy(e->ui.message, message, VUV_ERR - 1);
    e->ui.message[VUV_ERR - 1] = 0;
    LeaveCriticalSection(&e->state_lock);
    notify(e);
}
void engine_log(Engine *e, const wchar_t *message) {
    SYSTEMTIME t;
    wchar_t text[256];
    GetLocalTime(&t);
    swprintf(text, 256, L"%02u:%02u:%02u  %.220ls", t.wHour, t.wMinute, t.wSecond, message);
    EnterCriticalSection(&e->state_lock);
    if (e->log_count == 100) {
        memmove(e->logs, e->logs + 1, 99 * sizeof e->logs[0]);
        e->log_count = 99;
    }
    wcscpy(e->logs[e->log_count++], text);
    LeaveCriticalSection(&e->state_lock);
    notify(e);
}
static void sync_devices(Engine *e) {
    wchar_t motor[256], camera[256];
    native_wide(e->motor.version, motor, 256);
    native_wide(e->camera.model, camera, 256);
    EnterCriticalSection(&e->state_lock);
    e->ui.motor_connected = e->motor.connected;
    e->ui.camera_connected = e->camera.connected;
    e->ui.camera_handle = e->camera.initialized;
    e->ui.motor_simulated = e->motor.simulated;
    e->ui.camera_simulated = e->camera.simulated;
    e->ui.motor_state = e->motor.state;
    e->ui.position = e->motor.connected ? e->motor.position : NAN;
    e->ui.temperature = e->camera.initialized ? e->camera.temperature : NAN;
    e->ui.actual_exposure = e->camera.configured ? e->camera.actual_exposure : NAN;
    e->ui.rows = e->camera.shape.rows;
    e->ui.cols = e->camera.shape.cols;
    e->ui.controller_min = e->motor.lower;
    e->ui.controller_max = e->motor.upper;
    e->ui.ad_count = e->camera.ad_count;
    e->ui.amp_count = e->camera.amp_count;
    e->ui.hs_count = e->camera.hs_count;
    e->ui.vs_count = e->camera.vs_count;
    e->ui.gain_count = e->camera.gain_count;
    swprintf(e->ui.motor_detail, 256, L"%ls · 地址 %d · SL/SR %.4g°～%.4g°", motor,
             e->motor.config.address, e->motor.lower, e->motor.upper);
    swprintf(e->ui.camera_detail, 256, L"%ls · %d×%d · 序列号 %d", camera, e->camera.width,
             e->camera.height, e->camera.serial);
    LeaveCriticalSection(&e->state_lock);
    notify(e);
}
void engine_snapshot(Engine *e, UiState *s) {
    EnterCriticalSection(&e->state_lock);
    *s = e->ui;
    LeaveCriticalSection(&e->state_lock);
}
void engine_invalidate(Engine *e) {
    InterlockedExchange(&e->init_valid, 0);
}
static uint64_t fnv(const void *data, size_t n, uint64_t hash) {
    const unsigned char *p = (const unsigned char *)data;
    while (n--) {
        hash ^= *p++;
        hash *= 1099511628211ULL;
    }
    return hash;
}
static uint64_t op_hash(const Operation *o) {
    uint64_t h = fnv(&o->plan, sizeof o->plan, 1469598103934665603ULL);
    h = fnv(&o->camera, sizeof o->camera, h);
    h = fnv(o->output, wcslen(o->output) * sizeof(wchar_t), h);
    return fnv(o->project, wcslen(o->project) * sizeof(wchar_t), h);
}
void engine_create(Engine *e, HWND window, const wchar_t *dir) {
    memset(e, 0, sizeof *e);
    e->window = window;
    InitializeCriticalSection(&e->state_lock);
    e->gate = CreateMutexW(NULL, FALSE, NULL);
    e->cancel = CreateEventW(NULL, TRUE, FALSE, NULL);
    motor_create(&e->motor);
    camera_create(&e->camera);
    wcsncpy(e->data_dir, dir, VUV_PATH - 1);
    swprintf(e->output_dir, VUV_PATH, L"%ls\\scans", dir);
    native_mkdirs(e->output_dir);
    e->samples = (VuvSample *)calloc(VUV_MAX_POINTS, sizeof *e->samples);
    e->ui.position = e->ui.temperature = e->ui.intensity = e->ui.actual_exposure = NAN;
    e->calibration.reference_pixel = NAN;
    phase(e, PH_IDLE, L"请分别连接电机和相机；默认使用模拟设备");
}
int engine_calibration(Engine *e, const VuvCalibration *c, wchar_t *err) {
    char why[256];
    if (e->busy || e->stopping)
        return native_error(err, L"操作中不能更改标定");
    if (c->enabled && !vuv_cal_validate(c, why, sizeof why))
        return native_core_error(err, why);
    if (c->enabled && c->simulation_only && e->motor.connected && !e->motor.simulated)
        return native_error(err, L"模拟标定不能用于真实电机");
    EnterCriticalSection(&e->state_lock);
    e->calibration = *c;
    LeaveCriticalSection(&e->state_lock);
    engine_invalidate(e);
    engine_log(e, c->enabled ? L"中心波长标定已应用" : L"已清除中心波长标定");
    return 1;
}
static int require_motor(Engine *e, wchar_t *err) {
    return e->motor.connected ? 1 : native_error(err, L"电机未连接");
}
static int require_camera(Engine *e, wchar_t *err) {
    if (!e->camera.connected)
        return native_error(err, L"相机未完整连接");
    if (e->camera_pending)
        return native_error(err, L"相机正在回温断开");
    return 1;
}
static VuvLimits limits(Engine *e) {
    VuvLimits l = e->motor.config.limits;
    l.controller_min = e->motor.lower;
    l.controller_max = e->motor.upper;
    return l;
}
static int resolve(Engine *e, const Operation *o, double query, VuvResolved *r, wchar_t *err) {
    char why[256];
    int lo, hi;
    VuvLimits l = limits(e);
    VuvShape shape;
    if (!vuv_shape(&o->camera, e->camera.width, e->camera.height, &shape, why, sizeof why) ||
        !vuv_signal_range(&o->plan, shape.cols, &lo, &hi, why, sizeof why))
        return native_core_error(err, why);
    if (!vuv_plan_resolve(
            &o->plan, &o->camera, &e->calibration, &l, e->motor.simulated,
            (e->camera.configured && !memcmp(&e->camera.config, &o->camera, sizeof o->camera))
                ? e->camera.actual_cycle
                : o->camera.exposure_ms / 1000 + .02,
            query, shape.pixels * sizeof(int32_t), r, why, sizeof why))
        return native_core_error(err, why);
    return 1;
}
int engine_preview(Engine *e, const Operation *o, VuvResolved *r, wchar_t *err) {
    int ok;
    if (e->busy || e->stopping)
        return native_error(err, L"操作中请稍后检查计划");
    if (!require_motor(e, err) || !require_camera(e, err))
        return 0;
    if (WaitForSingleObject(e->gate, 0) != WAIT_OBJECT_0)
        return native_error(err, L"正在读取设备状态，请稍后重试");
    ok = resolve(e, o, .01, r, err);
    ReleaseMutex(e->gate);
    return ok;
}
static int stationary(Engine *e, double target, wchar_t *err) {
    int i, state;
    double pos;
    for (i = 0; i < 3; i++) {
        if (is_cancelled(e))
            return native_error(err, L"已停止");
        if (!motor_status(&e->motor, &state, err) || !motor_position(&e->motor, &pos, err))
            return 0;
        if (!motor_ready(state) || fabs(pos - target) > e->motor.config.limits.tolerance)
            return native_error(err, L"电机未同时满足 READY 和位置允差");
        if (!native_wait(e->cancel, .015))
            return native_error(err, L"已停止");
    }
    return 1;
}
static int initialize_scan(Engine *e, const Operation *o, wchar_t *err) {
    double query = 0, t;
    int i;
    VuvResolved r;
    if (!require_motor(e, err) || !require_camera(e, err))
        return 0;
    engine_invalidate(e);
    phase(e, PH_INITIALIZING, L"初始化：核验设备、配置相机和扫描范围");
    if (!camera_configure(&e->camera, &o->camera, err))
        return 0;
    for (i = 0; i < 3; i++) {
        double p;
        t = native_now();
        if (!motor_position(&e->motor, &p, err))
            return 0;
        query = fmax(query, native_now() - t);
    }
    if (!resolve(e, o, query, &r, err))
        return 0;
    phase(e, PH_MOVING, L"初始化：正在定位扫描起点");
    if (!motor_move(&e->motor, r.start_angle, e->cancel, err) || !stationary(e, r.start_angle, err))
        return 0;
    phase(e, PH_SETTLING, L"初始化：起点已到位，等待停稳");
    if (!native_wait(e->cancel, o->plan.settle_s) || !stationary(e, r.start_angle, err))
        return native_error(err, L"初始化已停止或位置复核失败");
    EnterCriticalSection(&e->state_lock);
    e->initialized = *o;
    e->resolved = r;
    e->init_hash = op_hash(o);
    e->sample_count = 0;
    e->spectrum_cols = 0;
    e->ui.completed = e->ui.current = 0;
    e->ui.total = o->plan.points;
    e->ui.intensity = NAN;
    LeaveCriticalSection(&e->state_lock);
    InterlockedExchange(&e->init_valid, 1);
    phase(e, PH_INITIALIZED, L"初始化完成，可以开始扫描");
    engine_log(e, L"初始化完成：参数已冻结，起点已定位");
    return 1;
}
static void json_num(cJSON *j, const char *name, double v) {
    if (isfinite(v))
        cJSON_AddNumberToObject(j, name, v);
    else
        cJSON_AddNullToObject(j, name);
}
static int save_manifest(Store *s) {
    wchar_t p[VUV_PATH];
    char *text;
    int ok;
    cJSON_ReplaceItemInObjectCaseSensitive(s->manifest, "completed_points",
                                           cJSON_CreateNumber(s->committed));
    if (s->partial_point) {
        cJSON *j = cJSON_CreateObject();
        cJSON_AddNumberToObject(j, "point", s->partial_point);
        cJSON_AddNumberToObject(j, "saved_frames", s->partial_frames);
        cJSON_ReplaceItemInObjectCaseSensitive(s->manifest, "partial_point", j);
    } else
        cJSON_ReplaceItemInObjectCaseSensitive(s->manifest, "partial_point", cJSON_CreateNull());
    text = cJSON_PrintUnformatted(s->manifest);
    if (!text)
        return 0;
    swprintf(p, VUV_PATH, L"%ls\\manifest.json", s->path);
    ok = native_atomic_utf8(p, text);
    cJSON_free(text);
    return ok;
}
static int event(Store *s, const char *kind, int point, int frame, double pos, double other,
                 double when) {
    char utc[40], *text;
    cJSON *j;
    if (!s->events)
        return 0;
    native_utc(utc);
    j = cJSON_CreateObject();
    cJSON_AddStringToObject(j, "utc", utc);
    cJSON_AddStringToObject(j, "event", kind);
    cJSON_AddNumberToObject(j, "point", point);
    cJSON_AddNumberToObject(j, "frame", frame);
    json_num(j, "position_deg", pos);
    json_num(j, "other_position_deg", other);
    json_num(j, "host_monotonic_s", when);
    text = cJSON_PrintUnformatted(j);
    cJSON_Delete(j);
    if (!text)
        return 0;
    int ok = fprintf(s->events, "%s\n", text) > 0 && native_flush(s->events);
    cJSON_free(text);
    return ok;
}
static cJSON *camera_metadata(const Camera *c) {
    cJSON *j = cJSON_CreateObject();
    cJSON_AddStringToObject(j, "model", c->model);
    cJSON_AddNumberToObject(j, "serial", c->serial);
    cJSON_AddNumberToObject(j, "detector_width", c->width);
    cJSON_AddNumberToObject(j, "detector_height", c->height);
    cJSON_AddNumberToObject(j, "read_mode", c->config.read_mode);
    cJSON_AddNumberToObject(j, "hbin", c->config.hbin);
    cJSON_AddNumberToObject(j, "vbin", c->config.vbin);
    cJSON_AddNumberToObject(j, "roi_x_start", c->shape.x0);
    cJSON_AddNumberToObject(j, "roi_x_end", c->shape.x1);
    cJSON_AddNumberToObject(j, "roi_y_start", c->shape.y0);
    cJSON_AddNumberToObject(j, "roi_y_end", c->shape.y1);
    cJSON_AddNumberToObject(j, "track_center", c->shape.track_center);
    cJSON_AddNumberToObject(j, "track_height", c->config.track_height);
    cJSON_AddNumberToObject(j, "output_rows", c->shape.rows);
    cJSON_AddNumberToObject(j, "output_columns", c->shape.cols);
    json_num(j, "first_pixel_center", c->shape.first_pixel);
    json_num(j, "actual_exposure_s", c->actual_exposure);
    json_num(j, "actual_cycle_s", c->actual_cycle);
    json_num(j, "hs_mhz", c->hs_mhz);
    json_num(j, "vs_us", c->vs_us);
    json_num(j, "preamp_gain", c->gain);
    cJSON_AddNumberToObject(j, "ad_index", c->config.ad);
    cJSON_AddNumberToObject(j, "amplifier_index", c->config.amp);
    cJSON_AddNumberToObject(j, "hs_index", c->config.hs);
    cJSON_AddNumberToObject(j, "vs_requested_index", c->config.vs);
    cJSON_AddNumberToObject(j, "preamp_index", c->config.preamp);
    cJSON_AddNumberToObject(j, "shutter", c->config.shutter);
    cJSON_AddNumberToObject(j, "shutter_ttl", c->config.shutter_ttl);
    cJSON_AddNumberToObject(j, "shutter_open_ms", c->config.shutter_open_ms);
    cJSON_AddNumberToObject(j, "shutter_close_ms", c->config.shutter_close_ms);
    cJSON_AddNumberToObject(j, "frames_per_sample", c->config.frames);
    cJSON_AddBoolToObject(j, "row_mean", c->config.row_mean);
    cJSON_AddBoolToObject(j, "require_stable_temperature", c->config.require_stable);
    json_num(j, "temperature_c", c->temperature);
    return j;
}
static int store_open(Store *s, Engine *e, const Operation *o, int standalone, const VuvResolved *r,
                      wchar_t *err) {
    SYSTEMTIME t;
    wchar_t root[VUV_PATH], project[96], p[VUV_PATH];
    char utc[40], *u;
    int i;
    ULARGE_INTEGER freebytes;
    double estimated;
    size_t len;
    memset(s, 0, sizeof *s);
    wcsncpy(root, o->output[0] ? o->output : e->output_dir, VUV_PATH - 1);
    root[VUV_PATH - 1] = 0;
    if (!native_mkdirs(root))
        return native_error(err, L"无法创建数据目录 (%lu)", GetLastError());
    estimated =
        (standalone ? 1 : o->plan.points) *
        (e->camera.shape.pixels * 4. * o->camera.frames + e->camera.shape.cols * 25. + 4096) * 1.1;
    if (GetDiskFreeSpaceExW(root, &freebytes, NULL, NULL) &&
        estimated > (double)freebytes.QuadPart * .85)
        return native_error(err, L"预计数据量超过目标磁盘剩余空间的85%%");
    wcsncpy(project, o->project[0] ? o->project : L"VUV扫描", 95);
    project[95] = 0;
    for (i = 0; project[i]; i++)
        if (wcschr(L"\\/:*?\"<>|", project[i]) || project[i] < 32)
            project[i] = L'_';
    GetLocalTime(&t);
    if (wcslen(root) + wcslen(project) + 90 >= VUV_PATH)
        return native_error(err, L"数据路径过长");
    swprintf(s->path, VUV_PATH, L"%ls\\%04u%02u%02u_%02u%02u%02u_%03u_%lu_%ls", root, t.wYear,
             t.wMonth, t.wDay, t.wHour, t.wMinute, t.wSecond, t.wMilliseconds,
             GetCurrentProcessId(), project);
    if (!CreateDirectoryW(s->path, NULL))
        return native_error(err, L"无法创建本次采集目录 (%lu)", GetLastError());
    swprintf(p, VUV_PATH, L"%ls\\raw", s->path);
    if (!CreateDirectoryW(p, NULL))
        return native_error(err, L"无法创建原始帧目录");
    s->manifest = cJSON_CreateObject();
    native_utc(utc);
    cJSON_AddStringToObject(s->manifest, "application", "创谱科技-VUV质谱波长扫描软件");
    cJSON_AddStringToObject(s->manifest, "version", VUV_VERSION);
    cJSON_AddStringToObject(s->manifest, "implementation", "C11 / native Win32");
    cJSON_AddStringToObject(s->manifest, "status", "running");
    cJSON_AddStringToObject(s->manifest, "created_utc", utc);
    cJSON_AddNumberToObject(s->manifest, "completed_points", 0);
    cJSON_AddNullToObject(s->manifest, "partial_point");
    cJSON_AddStringToObject(s->manifest, "mode",
                            standalone                       ? "camera"
                            : o->plan.mode == VUV_CONTINUOUS ? "continuous"
                                                             : "point");
    cJSON_AddStringToObject(s->manifest, "motor_source",
                            e->motor.connected ? (e->motor.simulated ? "simulation" : "hardware")
                                               : "disconnected");
    cJSON_AddStringToObject(s->manifest, "camera_source",
                            e->camera.simulated ? "simulation" : "hardware");
    cJSON_AddItemToObject(s->manifest, "camera", camera_metadata(&e->camera));
    cJSON *j = cJSON_CreateObject();
    cJSON_AddNumberToObject(j, "points", standalone ? 1 : o->plan.points);
    cJSON_AddNumberToObject(j, "coordinate", o->plan.coordinate);
    json_num(j, "start", o->plan.start);
    json_num(j, "step", o->plan.step);
    json_num(j, "settle_s", o->plan.settle_s);
    json_num(j, "velocity_deg_s", o->plan.velocity);
    json_num(j, "sampling_period_s", o->plan.period_s);
    json_num(j, "lead_s", o->plan.lead_s);
    cJSON_AddNumberToObject(j, "signal_first_column", o->plan.signal_first);
    cJSON_AddNumberToObject(j, "signal_last_column", o->plan.signal_last);
    if (r) {
        json_num(j, "start_deg", r->start_angle);
        json_num(j, "guard_target_deg", r->guard_angle);
        json_num(j, "minimum_period_s", r->min_period_s);
    }
    cJSON_AddItemToObject(s->manifest, "plan", j);
    j = cJSON_CreateObject();
    cJSON_AddBoolToObject(j, "enabled", e->calibration.enabled);
    cJSON_AddBoolToObject(j, "simulation_only", e->calibration.simulation_only);
    cJSON_AddNumberToObject(j, "degree", e->calibration.degree);
    cJSON *a = cJSON_CreateArray();
    for (i = 0; i < 4; i++)
        cJSON_AddItemToArray(a, cJSON_CreateNumber(e->calibration.a[i]));
    cJSON_AddItemToObject(j, "coefficients", a);
    json_num(j, "angle_min", e->calibration.lo);
    json_num(j, "angle_max", e->calibration.hi);
    json_num(j, "reference_pixel", e->calibration.reference_pixel);
    cJSON_AddItemToObject(s->manifest, "calibration", j);
    j = cJSON_CreateObject();
    json_num(j, "local_min_deg", e->motor.config.limits.local_min);
    json_num(j, "local_max_deg", e->motor.config.limits.local_max);
    json_num(j, "controller_software_min_deg", e->motor.lower);
    json_num(j, "controller_software_max_deg", e->motor.upper);
    json_num(j, "tolerance_deg", e->motor.config.limits.tolerance);
    cJSON_AddStringToObject(j, "version", e->motor.version);
    cJSON_AddStringToObject(j, "positioner_id", e->motor.positioner);
    cJSON_AddNumberToObject(j, "address", e->motor.config.address);
    cJSON_AddNumberToObject(j, "baud", e->motor.config.baud);
    cJSON_AddBoolToObject(j, "xonxoff", e->motor.config.xonxoff);
    cJSON_AddItemToObject(s->manifest, "motor", j);
    cJSON_AddStringToObject(
        s->manifest, "position_model",
        "Continuous/camera position: host exposure-midpoint linear estimate from serial brackets; "
        "not hardware synchronized. Point scans use stationary measured positions.");
    cJSON_AddStringToObject(s->manifest, "signal_model",
                            "Signed SDK counts; row sum/mean and per-sample frame mean, then "
                            "selected output columns summed; no automatic dark subtraction.");
    if (!save_manifest(s))
        return native_error(err, L"无法写入数据清单");
    swprintf(p, VUV_PATH, L"%ls\\scan_points.csv", s->path);
    s->points = _wfopen(p, L"wb");
    swprintf(p, VUV_PATH, L"%ls\\spectra.csv", s->path);
    s->spectra = _wfopen(p, L"wb");
    swprintf(p, VUV_PATH, L"%ls\\events.jsonl", s->path);
    s->events = _wfopen(p, L"wb");
    if (!s->points || !s->spectra || !s->events)
        return native_error(err, L"无法打开数据输出文件");
    fwrite("\xef\xbb\xbf", 1, 3, s->points);
    fputs("point,mode,target_deg,position_deg,position_before_deg,position_after_deg,position_span_"
          "deg,position_model,center_wavelength_nm,integrated_counts,peak_counts,temperature_c,"
          "frames,exposure_s,scheduled_start_s,actual_start_s,schedule_delay_s,acquisition_start_"
          "utc,acquisition_end_utc\r\n",
          s->points);
    fwrite("\xef\xbb\xbf", 1, 3, s->spectra);
    fputs("point,position_deg,center_wavelength_nm", s->spectra);
    for (i = 0; i < e->camera.shape.cols; i++)
        fprintf(s->spectra, ",pixel_%.9g", e->camera.shape.first_pixel + i * o->camera.hbin);
    fputs("\r\n", s->spectra);
    if (!native_flush(s->points) || !native_flush(s->spectra) ||
        !event(s, "run_created", 0, 0, NAN, NAN, native_now()))
        return native_error(err, L"初始化数据文件写入失败");
    EnterCriticalSection(&e->state_lock);
    wcscpy(e->ui.last_run, s->path);
    LeaveCriticalSection(&e->state_lock);
    u = native_utf8(s->path);
    len = u ? strlen(u) : 0;
    (void)len;
    free(u);
    return 1;
}
static int save_raw(Store *s, int point, int frame, const int32_t *raw, int rows, int cols,
                    wchar_t *err) {
    wchar_t path[VUV_PATH], tmp[VUV_PATH];
    FILE *f;
    int ok;
    swprintf(path, VUV_PATH, L"%ls\\raw\\point_%06d_frame_%03d.npy", s->path, point, frame);
    swprintf(tmp, VUV_PATH, L"%ls.tmp", path);
    f = _wfopen(tmp, L"wb");
    if (!f)
        return native_error(err, L"原始帧文件创建失败");
    ok = vuv_npy_frame(f, raw, rows, cols) && native_flush(f);
    if (fclose(f))
        ok = 0;
    if (!ok || !MoveFileExW(tmp, path, MOVEFILE_WRITE_THROUGH)) {
        DeleteFileW(tmp);
        return native_error(err, L"原始帧保存失败，已停止后续采集");
    }
    s->partial_point = point;
    s->partial_frames = frame;
    if (!save_manifest(s) || !event(s, "frame_saved", point, frame, NAN, NAN, native_now()))
        return native_error(err, L"原始帧记录提交失败");
    return 1;
}
static void csv_number(FILE *f, double v) {
    if (isfinite(v))
        fprintf(f, "%.17g", v);
}
static int commit_sample(Store *s, const VuvSample *r, const double *spectrum, int cols,
                         wchar_t *err) {
    int i;
    FILE *f = s->spectra;
    fprintf(f, "%d,", r->point);
    csv_number(f, r->position);
    fputc(',', f);
    csv_number(f, r->wavelength);
    for (i = 0; i < cols; i++)
        fprintf(f, ",%.17g", spectrum[i]);
    fputs("\r\n", f);
    if (!native_flush(f))
        return native_error(err, L"平均光谱写入失败");
    f = s->points;
    fprintf(f, "%d,%s,", r->point,
            r->mode == VUV_CAMERA       ? "camera"
            : r->mode == VUV_CONTINUOUS ? "continuous"
                                        : "point");
    csv_number(f, r->target);
    fputc(',', f);
    csv_number(f, r->position);
    fputc(',', f);
    csv_number(f, r->before);
    fputc(',', f);
    csv_number(f, r->after);
    fputc(',', f);
    csv_number(f, r->span);
    fprintf(f, ",%s,",
            !isfinite(r->position) ? "unavailable"
            : r->mode == VUV_POINT ? "stationary_measured"
                                   : "host_exposure_mid_linear_estimate");
    csv_number(f, r->wavelength);
    fprintf(f, ",%.17g,%.17g,", r->intensity, r->peak);
    csv_number(f, r->temperature);
    fprintf(f, ",%d,%.17g,", r->frames, r->exposure_s);
    csv_number(f, r->scheduled_s);
    fprintf(f, ",%.17g,", r->actual_s);
    csv_number(f, r->delay_s);
    fprintf(f, ",%s,%s\r\n", r->begin_utc, r->end_utc);
    if (!native_flush(f))
        return native_error(err, L"位置—信号数据写入失败");
    s->committed++;
    s->partial_point = s->partial_frames = 0;
    if (!save_manifest(s) ||
        !event(s, "point_committed", r->point, 0, r->position, r->intensity, native_now()))
        return native_error(err, L"采样点提交失败");
    return 1;
}
static void store_finish(Store *s, const char *status, const wchar_t *error) {
    char utc[40], *u;
    if (s->manifest) {
        cJSON_ReplaceItemInObjectCaseSensitive(s->manifest, "status", cJSON_CreateString(status));
        native_utc(utc);
        cJSON_AddStringToObject(s->manifest, "finished_utc", utc);
        if (error && error[0]) {
            u = native_utf8(error);
            if (u) {
                cJSON_AddStringToObject(s->manifest, "error", u);
                free(u);
            }
        }
        save_manifest(s);
        cJSON_Delete(s->manifest);
        s->manifest = NULL;
    }
    if (s->points)
        fclose(s->points);
    if (s->spectra)
        fclose(s->spectra);
    if (s->events)
        fclose(s->events);
    s->points = s->spectra = s->events = NULL;
}
static int sample_position(Engine *e, int mode, double target, Position *p, wchar_t *err) {
    double a, b;
    if (is_cancelled(e))
        return native_error(err, L"采集已停止");
    memset(p, 0, sizeof *p);
    p->position = NAN;
    p->state = -1;
    p->when = native_now();
    native_utc(p->utc);
    if (!e->motor.connected) {
        if (mode == VUV_CAMERA)
            return 1;
        return native_error(err, L"电机连接丢失");
    }
    if (!motor_status(&e->motor, &p->state, err))
        return 0;
    if (mode == VUV_CONTINUOUS && p->state != 0x28)
        return native_error(err, L"连续采样时电机提前停止，当前点不提交");
    if (mode == VUV_POINT && !motor_ready(p->state))
        return native_error(err, L"点扫描曝光前后电机不再 READY");
    a = native_now();
    if (!motor_position(&e->motor, &p->position, err))
        return 0;
    b = native_now();
    p->when = (a + b) / 2;
    native_utc(p->utc);
    if (mode == VUV_POINT && fabs(p->position - target) > e->motor.config.limits.tolerance)
        return native_error(err, L"点扫描位置偏差超过允差");
    return 1;
}
static void update_plot(Engine *e, const VuvSample *r, const double *values, int cols) {
    wchar_t message[256];
    int have_buffer = 1;
    EnterCriticalSection(&e->state_lock);
    if (e->samples && r->point > 0 && r->point <= VUV_MAX_POINTS) {
        e->samples[r->point - 1] = *r;
        e->sample_count = r->point;
    }
    if (e->spectrum_cols != cols) {
        double *p = (double *)realloc(e->spectrum, (size_t)cols * sizeof *p);
        if (p)
            e->spectrum = p;
        else
            have_buffer = 0;
    }
    if (have_buffer && e->spectrum) {
        memcpy(e->spectrum, values, (size_t)cols * sizeof *values);
        e->spectrum_cols = cols;
    }
    e->first_pixel = e->camera.shape.first_pixel;
    e->pixel_bin = e->camera.config.hbin;
    e->ui.completed = r->point;
    e->ui.intensity = r->intensity;
    LeaveCriticalSection(&e->state_lock);
    swprintf(message, 256, L"第 %d 点完成：位置 %ls，积分 %.6g", r->point,
             isfinite(r->position) ? L"已记录" : L"未连接电机", r->intensity);
    engine_log(e, message);
    sync_devices(e);
}
static int bracket_event(Store *s, int point, int frame, const Position *a, const Position *b,
                         const Camera *c) {
    cJSON *j = cJSON_CreateObject();
    char *line;
    int ok;
    cJSON_AddStringToObject(j, "event", "position_bracket");
    cJSON_AddNumberToObject(j, "point", point);
    cJSON_AddNumberToObject(j, "frame", frame);
    json_num(j, "position_before_deg", a->position);
    json_num(j, "position_after_deg", b->position);
    json_num(j, "query_before_host_s", a->when);
    json_num(j, "query_after_host_s", b->when);
    json_num(j, "acquisition_call_host_s", c->frame_start);
    json_num(j, "exposure_mid_estimate_host_s", c->frame_mid);
    json_num(j, "readout_end_host_s", c->frame_end);
    cJSON_AddStringToObject(j, "query_before_utc", a->utc);
    cJSON_AddStringToObject(j, "query_after_utc", b->utc);
    cJSON_AddStringToObject(
        j, "timing_model",
        "Host software estimate; SDK/serial latency and acceleration are not corrected.");
    line = cJSON_PrintUnformatted(j);
    cJSON_Delete(j);
    if (!line)
        return 0;
    ok = fprintf(s->events, "%s\n", line) > 0 && native_flush(s->events);
    cJSON_free(line);
    return ok;
}
static int acquire_sample(Engine *e, Store *s, const Operation *o, int index, int mode,
                          double target, double origin, double scheduled, int32_t *raw,
                          double *work, double *average, wchar_t *err) {
    Position before, after;
    VuvSample r;
    double p_sum = 0, p_min = INFINITY, p_max = -INFINITY, first_start = 0;
    int frame, all_positions = 1, lo, hi, x, post_ok;
    char why[256];
    wchar_t post_error[VUV_ERR], text[160];
    memset(&r, 0, sizeof r);
    r.target = target;
    r.wavelength = NAN;
    r.scheduled_s = scheduled;
    r.point = index;
    r.mode = mode;
    r.frames = o->camera.frames;
    r.exposure_s = e->camera.actual_exposure;
    r.before = r.after = NAN;
    for (frame = 1; frame <= o->camera.frames; frame++) {
        if (!sample_position(e, mode, target, &before, err))
            return 0;
        swprintf(text, 160, L"第 %d / %d 点，第 %d / %d 帧采集中", index, e->ui.total, frame,
                 o->camera.frames);
        phase(e, PH_ACQUIRING, text);
        if (!event(s, "acquisition_started", index, frame, before.position, NAN, native_now()))
            return native_error(err, L"事件记录失败");
        if (frame == 1)
            native_utc(r.begin_utc);
        if (!camera_acquire(&e->camera, &e->motor, e->cancel, raw, err))
            return 0;
        if (frame == 1)
            first_start = e->camera.frame_start;
        post_ok = sample_position(e, mode, target, &after, post_error);
        if (!save_raw(s, index, frame, raw, e->camera.shape.rows, e->camera.shape.cols, err))
            return 0;
        if (!post_ok) {
            wcsncpy(err, post_error, VUV_ERR - 1);
            return 0;
        }
        if (!bracket_event(s, index, frame, &before, &after, &e->camera))
            return native_error(err, L"位置括定记录失败");
        if (frame == 1)
            r.before = before.position;
        r.after = after.position;
        double estimate = vuv_position_estimate(before.position, before.when, after.position,
                                                after.when, e->camera.frame_mid);
        if (!isfinite(estimate))
            all_positions = 0;
        else {
            p_sum += estimate;
            p_min = fmin(p_min, fmin(before.position, after.position));
            p_max = fmax(p_max, fmax(before.position, after.position));
        }
        vuv_reduce_frame(raw, e->camera.shape.rows, e->camera.shape.cols, o->camera.row_mean, work,
                         average, frame);
    }
    if (is_cancelled(e))
        return native_error(err, L"采集已停止，原始帧已保留");
    r.position = all_positions ? p_sum / o->camera.frames : NAN;
    r.span = all_positions ? p_max - p_min : NAN;
    if (e->calibration.enabled && isfinite(r.position) && r.position >= e->calibration.lo &&
        r.position <= e->calibration.hi)
        r.wavelength = vuv_cal_eval(&e->calibration, r.position);
    if (mode != VUV_CAMERA && o->plan.coordinate == VUV_WAVELENGTH && !isfinite(r.wavelength))
        return native_error(err, L"实际位置超出标定区间，当前点不提交");
    if (!vuv_signal_range(&o->plan, e->camera.shape.cols, &lo, &hi, why, sizeof why))
        return native_core_error(err, why);
    r.intensity = vuv_integrate(average, lo, hi);
    r.peak = -INFINITY;
    for (x = 0; x < e->camera.shape.cols; x++)
        r.peak = fmax(r.peak, average[x]);
    if (!camera_temperature(&e->camera, err))
        return 0;
    r.temperature = e->camera.temperature;
    r.actual_s = first_start - origin;
    r.delay_s = isfinite(scheduled) ? r.actual_s - scheduled : NAN;
    native_utc(r.end_utc);
    phase(e, PH_SAVING, L"正在提交采样点、光谱和位置信息");
    if (!commit_sample(s, &r, average, e->camera.shape.cols, err))
        return 0;
    update_plot(e, &r, average, e->camera.shape.cols);
    return 1;
}
static void safe_stop(Engine *e) {
    wchar_t ignored[VUV_ERR]; /* Never wait for a vendor-camera call before stopping motion. */
    motor_stop(&e->motor, ignored);
    camera_abort(&e->camera, ignored);
}
static int run_scan(Engine *e, const Operation *o, int standalone, wchar_t *err) {
    Store store;
    VuvResolved r = e->resolved;
    int32_t *raw = NULL;
    double *work = NULL, *average = NULL, original_velocity = NAN, origin = native_now(), target;
    int i, ok = 0, mode = standalone ? VUV_CAMERA : o->plan.mode;
    char why[256];
    wchar_t text[256], ignored[VUV_ERR];
    memset(&store, 0, sizeof store);
    EnterCriticalSection(&e->state_lock);
    e->sample_count = e->spectrum_cols = 0;
    e->ui.completed = e->ui.current = 0;
    e->ui.total = standalone ? 1 : o->plan.points;
    e->plot_coordinate = standalone ? VUV_ANGLE : o->plan.coordinate;
    LeaveCriticalSection(&e->state_lock);
    notify(e);
    raw = (int32_t *)malloc(e->camera.shape.pixels * sizeof *raw);
    work = (double *)calloc((size_t)e->camera.shape.cols, sizeof *work);
    average = (double *)calloc((size_t)e->camera.shape.cols, sizeof *average);
    if (!raw || !work || !average) {
        native_error(err, L"无法分配相机缓冲区");
        goto finish;
    }
    if (!store_open(&store, e, o, standalone, standalone ? NULL : &r, err))
        goto finish;
    if (mode == VUV_CONTINUOUS) {
        double actual;
        if (!motor_velocity(&e->motor, &original_velocity, err) ||
            !motor_set_velocity(&e->motor, fabs(o->plan.velocity), err) ||
            !motor_velocity(&e->motor, &actual, err))
            goto finish;
        json_num(store.manifest, "original_velocity_deg_s", original_velocity);
        json_num(store.manifest, "applied_velocity_deg_s", actual);
        if (!save_manifest(&store)) {
            native_error(err, L"速度参数记录失败");
            goto finish;
        }
        phase(e, PH_MOVING, L"连续扫描：一次连续运动，采样间不停止电机");
        if (!event(&store, "continuous_move_started", 0, 0, r.guard_angle, actual, native_now()) ||
            !motor_start(&e->motor, r.guard_angle, e->cancel, err))
            goto finish;
        origin = native_now();
        for (i = 0; i < o->plan.points; i++) {
            double scheduled = o->plan.lead_s + i * o->plan.period_s,
                   wait = origin + scheduled - native_now();
            if (wait > 0 && !native_wait(e->cancel, wait)) {
                native_error(err, L"连续扫描已停止");
                goto finish;
            }
            if (native_now() - origin - scheduled > o->plan.period_s) {
                native_error(err, L"处理时间超过一个采样周期，请增大周期");
                goto finish;
            }
            if (!acquire_sample(e, &store, o, i + 1, mode, NAN, origin, scheduled, raw, work,
                                average, err))
                goto finish;
        }
        if (!motor_stop(&e->motor, err) || !motor_wait_ready(&e->motor, 0, 0, NULL, 10, err))
            goto finish;
    } else if (mode == VUV_CAMERA) {
        if (!acquire_sample(e, &store, o, 1, mode, NAN, origin, NAN, raw, work, average, err))
            goto finish;
    } else
        for (i = 0; i < o->plan.points; i++) {
            if (!vuv_point_target(&o->plan, &e->calibration, i, &target, why, sizeof why)) {
                native_core_error(err, why);
                goto finish;
            }
            swprintf(text, 256, L"点扫描 %d / %d：定位 %.6f°", i + 1, o->plan.points, target);
            phase(e, PH_MOVING, text);
            if (!event(&store, "point_move_commanded", i + 1, 0, target, NAN, native_now()) ||
                !motor_move(&e->motor, target, e->cancel, err) || !stationary(e, target, err))
                goto finish;
            phase(e, PH_SETTLING, L"已到位，等待停稳后采集");
            if (!native_wait(e->cancel, o->plan.settle_s) || !stationary(e, target, err)) {
                native_error(err, L"点扫描停稳期间停止或位置失效");
                goto finish;
            }
            if (!event(&store, "point_settled", i + 1, 0, target, NAN, native_now()) ||
                !acquire_sample(e, &store, o, i + 1, mode, target, origin, NAN, raw, work, average,
                                err))
                goto finish;
        }
    if (is_cancelled(e)) {
        native_error(err, L"已停止，已完成点保留");
        goto finish;
    }
    ok = 1;
finish:
    if (!ok) {
        if (mode == VUV_CAMERA)
            camera_abort(&e->camera, ignored);
        else
            safe_stop(e);
    }
    if (mode == VUV_CONTINUOUS && isfinite(original_velocity)) {
        if (motor_wait_ready(&e->motor, 0, 0, NULL, 10, ignored) &&
            motor_set_velocity(&e->motor, original_velocity, ignored)) {
            if (store.manifest)
                cJSON_AddBoolToObject(store.manifest, "original_velocity_restored", 1);
        } else {
            engine_log(e, L"原电机速度未能恢复，请核对控制器");
            if (store.manifest)
                cJSON_AddBoolToObject(store.manifest, "original_velocity_restored", 0);
        }
    }
    store_finish(&store, ok ? "completed" : is_cancelled(e) ? "stopped" : "error", ok ? NULL : err);
    free(raw);
    free(work);
    free(average);
    if (ok) {
        phase(e, PH_COMPLETE, L"采集完成，位置、信号与原始帧已保存");
        engine_log(e, L"采集完成");
    }
    return ok;
}
static int perform(Engine *e, const Operation *o, wchar_t *err) {
    double pos;
    int ok;
    switch (o->kind) {
    case OP_MOTOR_CONNECT:
        engine_invalidate(e);
        phase(e, PH_INITIALIZING, L"正在连接电机（不自动归零或运动）");
        ok = motor_connect(&e->motor, &o->motor, err);
        if (ok && e->calibration.simulation_only && !o->motor.simulated)
            e->calibration.enabled = 0;
        return ok;
    case OP_MOTOR_DISCONNECT:
        engine_invalidate(e);
        motor_close(&e->motor);
        return 1;
    case OP_CAMERA_CONNECT:
        engine_invalidate(e);
        phase(e, PH_INITIALIZING, L"正在连接相机");
        ok = camera_connect(&e->camera, o->camera_simulated, o->dll_path, o->camera_index, err);
        if (!ok && e->camera.initialized)
            InterlockedExchange(&e->camera_pending, 1);
        return ok;
    case OP_CAMERA_DISCONNECT:
        engine_invalidate(e);
        ok = camera_close(&e->camera, err);
        if (!ok && e->camera.initialized) {
            InterlockedExchange(&e->camera_pending, 1);
            phase(e, PH_WARMING, L"相机正在安全回温，电机可继续独立控制");
            return 1;
        }
        return ok;
    case OP_MOTOR_ABSOLUTE:
    case OP_MOTOR_RELATIVE:
    case OP_MOTOR_HOME:
        engine_invalidate(e);
        if (!require_motor(e, err))
            return 0;
        phase(e, PH_MOVING, L"电机独立运动中");
        if (o->kind == OP_MOTOR_HOME)
            return motor_home(&e->motor, e->cancel, err);
        if (!motor_set_velocity(&e->motor, o->manual_velocity, err))
            return 0;
        pos = o->manual_value;
        if (o->kind == OP_MOTOR_RELATIVE) {
            double current;
            if (!motor_position(&e->motor, &current, err))
                return 0;
            pos += current;
        }
        return motor_move(&e->motor, pos, e->cancel, err);
    case OP_MOTOR_SPEED:
        engine_invalidate(e);
        return require_motor(e, err) && motor_set_velocity(&e->motor, o->manual_velocity, err);
    case OP_CAMERA_APPLY:
        engine_invalidate(e);
        return require_camera(e, err) && camera_configure(&e->camera, &o->camera, err);
    case OP_CAMERA_CAPTURE:
        engine_invalidate(e);
        return require_camera(e, err) && camera_configure(&e->camera, &o->camera, err) &&
               run_scan(e, o, 1, err);
    case OP_COOL_ON:
    case OP_COOL_OFF:
        engine_invalidate(e);
        return camera_cooler(&e->camera, o->kind == OP_COOL_ON, o->camera.temperature, err);
    case OP_INITIALIZE:
        return initialize_scan(e, o, err);
    case OP_SCAN:
        if (!require_motor(e, err) || !require_camera(e, err))
            return 0;
        if (!e->init_valid || e->init_hash != op_hash(o))
            return native_error(err, L"参数或设备状态已改变，请重新初始化扫描");
        if (!stationary(e, e->resolved.start_angle, err))
            return 0;
        if (o->camera.require_stable &&
            (!camera_temperature(&e->camera, err) || !e->camera.temp_stable))
            return native_error(err, L"相机温度不再稳定");
        engine_invalidate(e);
        return run_scan(e, o, 0, err);
    default:
        return native_error(err, L"未知操作");
    }
}
static DWORD WINAPI worker_thread(void *p) {
    Job *job = (Job *)p;
    Engine *e = job->engine;
    Operation op = job->op;
    wchar_t err[VUV_ERR] = L"";
    int ok;
    free(job);
    WaitForSingleObject(e->gate, INFINITE);
    ok = perform(e, &op, err);
    if (!ok) {
        if (op.kind == OP_INITIALIZE || op.kind == OP_SCAN || op.kind == OP_MOTOR_ABSOLUTE ||
            op.kind == OP_MOTOR_RELATIVE || op.kind == OP_MOTOR_HOME)
            safe_stop(e);
        engine_invalidate(e);
        phase(e, is_cancelled(e) ? PH_STOPPED : PH_ERROR, err[0] ? err : L"操作失败");
        engine_log(e, err[0] ? err : L"操作失败");
    } else if (op.kind != OP_INITIALIZE && op.kind != OP_SCAN && op.kind != OP_CAMERA_CAPTURE &&
               !(op.kind == OP_CAMERA_DISCONNECT && e->camera_pending)) {
        phase(e, PH_READY, L"操作完成");
        engine_log(e, L"独立设备操作完成");
    }
    sync_devices(e);
    ReleaseMutex(e->gate);
    InterlockedExchange(&e->busy, 0);
    notify(e);
    return 0;
}
int engine_submit(Engine *e, const Operation *o, wchar_t *err) {
    HANDLE t;
    Job *j;
    if (!e->samples || !e->gate || !e->cancel)
        return native_error(err, L"无法分配运行资源，请重新启动软件");
    if (e->exit_requested)
        return native_error(err, L"正在安全退出");
    if (e->stopping || InterlockedCompareExchange(&e->busy, 1, 0))
        return native_error(err, L"已有设备操作正在进行，请等待或停止");
    if (e->camera_pending && !(o->kind <= OP_MOTOR_DISCONNECT ||
                               (o->kind >= OP_MOTOR_ABSOLUTE && o->kind <= OP_MOTOR_SPEED))) {
        InterlockedExchange(&e->busy, 0);
        return native_error(err, L"相机正在安全回温，电机仍可独立控制");
    }
    ResetEvent(e->cancel);
    j = (Job *)malloc(sizeof *j);
    if (!j) {
        InterlockedExchange(&e->busy, 0);
        return native_error(err, L"内存不足");
    }
    j->engine = e;
    j->op = *o;
    t = CreateThread(NULL, 0, worker_thread, j, 0, NULL);
    if (!t) {
        free(j);
        InterlockedExchange(&e->busy, 0);
        return native_error(err, L"无法创建操作线程");
    }
    CloseHandle(t);
    notify(e);
    return 1;
}
static DWORD WINAPI stop_thread(void *p) {
    Engine *e = (Engine *)p;
    safe_stop(e);
    InterlockedExchange(&e->stopping, 0);
    notify(e);
    return 0;
}
void engine_stop(Engine *e) {
    HANDLE t;
    SetEvent(e->cancel);
    engine_invalidate(e);
    if (InterlockedCompareExchange(&e->stopping, 1, 0))
        return;
    t = CreateThread(NULL, 0, stop_thread, e, 0, NULL);
    if (t)
        CloseHandle(t);
    else
        InterlockedExchange(&e->stopping, 0);
    engine_log(e, L"请求停止：先停止电机，再终止相机曝光");
}
static DWORD WINAPI poll_thread(void *p) {
    Engine *e = (Engine *)p;
    wchar_t err[VUV_ERR];
    int state, exit_ready = 0;
    double pos;
    if (WaitForSingleObject(e->gate, 0) == WAIT_OBJECT_0) {
        if (!e->busy && !e->stopping) {
            if (e->motor.connected) {
                if (!motor_status(&e->motor, &state, err) || !motor_position(&e->motor, &pos, err))
                    phase(e, PH_ERROR, err);
            }
            if (e->camera.initialized && !camera_temperature(&e->camera, err))
                phase(e, PH_ERROR, err);
            if (e->camera_pending || e->exit_requested) {
                if (camera_close(&e->camera, err)) {
                    InterlockedExchange(&e->camera_pending, 0);
                    if (e->exit_requested) {
                        motor_close(&e->motor);
                        exit_ready = 1;
                    } else
                        phase(e, PH_READY, L"相机已安全断开");
                } else {
                    InterlockedExchange(&e->camera_pending, 1);
                    phase(e, PH_WARMING, err);
                }
            }
            sync_devices(e);
        }
        ReleaseMutex(e->gate);
    }
    InterlockedExchange(&e->polling, 0);
    if (exit_ready && e->window)
        PostMessageW(e->window, WM_VUV_EXIT, 0, 0);
    return 0;
}
void engine_poll(Engine *e) {
    HANDLE t;
    if (e->busy || e->stopping || InterlockedCompareExchange(&e->polling, 1, 0))
        return;
    t = CreateThread(NULL, 0, poll_thread, e, 0, NULL);
    if (t)
        CloseHandle(t);
    else
        InterlockedExchange(&e->polling, 0);
}
void engine_exit(Engine *e) {
    InterlockedExchange(&e->exit_requested, 1);
    if (e->busy)
        engine_stop(e);
    phase(e, PH_WARMING, L"正在安全退出；低温相机将先回温，请保持供电和连接");
    engine_poll(e);
}
int engine_export(Engine *e, const wchar_t *path, wchar_t *err) {
    double *values, first;
    int cols, bin, i;
    FILE *f;
    EnterCriticalSection(&e->state_lock);
    cols = e->spectrum_cols;
    first = e->first_pixel;
    bin = e->pixel_bin;
    values = cols ? (double *)malloc((size_t)cols * sizeof *values) : NULL;
    if (values)
        memcpy(values, e->spectrum, (size_t)cols * sizeof *values);
    LeaveCriticalSection(&e->state_lock);
    if (!values)
        return native_error(err, L"没有可导出的光谱");
    f = _wfopen(path, L"wb");
    if (!f) {
        free(values);
        return native_error(err, L"无法创建导出文件");
    }
    fwrite("\xef\xbb\xbf", 1, 3, f);
    fputs("pixel,signal_counts\r\n", f);
    for (i = 0; i < cols; i++)
        fprintf(f, "%.17g,%.17g\r\n", first + i * bin, values[i]);
    free(values);
    int ok = native_flush(f);
    if (fclose(f))
        ok = 0;
    return ok ? 1 : native_error(err, L"导出文件写入失败");
}
