#ifndef VUV_ENGINE_H
#define VUV_ENGINE_H
#include "native.h"
#include "cJSON.h"
#define WM_VUV_UPDATE (WM_APP + 20)
#define WM_VUV_EXIT (WM_APP + 21)
enum {
    OP_MOTOR_CONNECT,
    OP_MOTOR_DISCONNECT,
    OP_CAMERA_CONNECT,
    OP_CAMERA_DISCONNECT,
    OP_MOTOR_ABSOLUTE,
    OP_MOTOR_RELATIVE,
    OP_MOTOR_HOME,
    OP_MOTOR_SPEED,
    OP_CAMERA_APPLY,
    OP_CAMERA_CAPTURE,
    OP_COOL_ON,
    OP_COOL_OFF,
    OP_INITIALIZE,
    OP_SCAN
};
enum {
    PH_IDLE,
    PH_READY,
    PH_INITIALIZING,
    PH_MOVING,
    PH_SETTLING,
    PH_INITIALIZED,
    PH_ACQUIRING,
    PH_SAVING,
    PH_COMPLETE,
    PH_STOPPED,
    PH_ERROR,
    PH_WARMING
};
typedef struct {
    int kind;
    MotorConfig motor;
    int camera_simulated, camera_index;
    wchar_t dll_path[VUV_PATH];
    VuvCameraConfig camera;
    VuvPlan plan;
    double manual_value, manual_velocity;
    wchar_t output[VUV_PATH], project[96];
} Operation;
typedef struct {
    int phase, motor_connected, camera_connected, camera_handle, motor_simulated, camera_simulated,
        motor_state;
    int completed, total, current, rows, cols, ad_count, amp_count, hs_count, vs_count, gain_count;
    double position, temperature, intensity, actual_exposure, controller_min, controller_max;
    wchar_t message[VUV_ERR], motor_detail[256], camera_detail[256], last_run[VUV_PATH];
} UiState;
typedef struct {
    HWND window;
    CRITICAL_SECTION state_lock;
    HANDLE gate, cancel;
    volatile LONG busy, stopping, polling, exit_requested, camera_pending, init_valid,
        notify_pending;
    Motor motor;
    Camera camera;
    VuvCalibration calibration;
    UiState ui;
    Operation initialized;
    VuvResolved resolved;
    uint64_t init_hash;
    wchar_t data_dir[VUV_PATH], output_dir[VUV_PATH];
    wchar_t logs[100][256];
    int log_count;
    VuvSample *samples;
    int sample_count, spectrum_cols;
    double *spectrum;
    double first_pixel;
    int pixel_bin, plot_coordinate;
} Engine;
void engine_create(Engine *, HWND, const wchar_t *);
int engine_submit(Engine *, const Operation *, wchar_t *);
void engine_stop(Engine *);
void engine_poll(Engine *);
void engine_exit(Engine *);
void engine_snapshot(Engine *, UiState *);
void engine_invalidate(Engine *);
void engine_log(Engine *, const wchar_t *);
int engine_calibration(Engine *, const VuvCalibration *, wchar_t *);
int engine_export(Engine *, const wchar_t *, wchar_t *);
int engine_preview(Engine *, const Operation *, VuvResolved *, wchar_t *);
#endif
