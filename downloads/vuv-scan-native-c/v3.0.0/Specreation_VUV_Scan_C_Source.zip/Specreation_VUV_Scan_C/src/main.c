#define COBJMACROS
#include "ui.h"
#include <commctrl.h>
#include <commdlg.h>
#include <shellapi.h>
#include <shlobj.h>
#include <wchar.h>
#include <stdlib.h>
#include <math.h>
#include <errno.h>
#include <string.h>

typedef struct {
    HWND hwnd;
    int id, page, x, y, w, h, type;
    const char *key;
} Control;
typedef struct {
    Engine *engine;
    int spectrum;
} Plot;
typedef struct {
    HINSTANCE instance;
    HWND window, tabs, list, plots[2];
    HFONT font, small, bold, title, metric;
    Engine engine;
    Control controls[220];
    int count, page, width, height, dpi, loading, cal_dirty, motor_dirty, last_count, self_test,
        hold, test_result;
    wchar_t data_dir[VUV_PATH], settings[VUV_PATH];
    Plot plot[2];
} App;
static App app;
static LRESULT CALLBACK main_proc(HWND, UINT, WPARAM, LPARAM);
static LRESULT CALLBACK plot_proc(HWND, UINT, WPARAM, LPARAM);
static DWORD WINAPI selftest_thread(void *);
static HWND ctrl(int id) {
    int i;
    for (i = 0; i < app.count; i++)
        if (app.controls[i].id == id)
            return app.controls[i].hwnd;
    return NULL;
}
static int scaled(int x) {
    return MulDiv(x, app.dpi, 96);
}
static void text(int id, const wchar_t *s) {
    HWND h = ctrl(id);
    if (h)
        SetWindowTextW(h, s);
}
static void get_text(int id, wchar_t *s, int n) {
    if (n) {
        s[0] = 0;
        GetWindowTextW(ctrl(id), s, n);
        s[n - 1] = 0;
    }
}
static int selection(int id) {
    return (int)SendMessageW(ctrl(id), CB_GETCURSEL, 0, 0);
}
static int checked(int id) {
    return SendMessageW(ctrl(id), BM_GETCHECK, 0, 0) == BST_CHECKED;
}
static void set_number(int id, double value) {
    wchar_t s[64];
    swprintf(s, 64, L"%.12g", value);
    text(id, s);
}
static int read_double(int id, const wchar_t *label, double lo, double hi, double *out,
                       wchar_t *err) {
    wchar_t s[128], *end;
    double v;
    get_text(id, s, 128);
    errno = 0;
    v = wcstod(s, &end);
    while (*end == L' ' || *end == L'\t')
        end++;
    if (end == s || *end || errno == ERANGE || !isfinite(v) || v < lo || v > hi)
        return native_error(err, L"%ls 必须是 %.9g～%.9g 的有效数字", label, lo, hi);
    *out = v;
    return 1;
}
static int read_int(int id, const wchar_t *label, int lo, int hi, int *out, wchar_t *err) {
    double v;
    if (!read_double(id, label, lo, hi, &v, err))
        return 0;
    if (v != floor(v))
        return native_error(err, L"%ls 必须为整数", label);
    *out = (int)v;
    return 1;
}
static HWND add_control(int id, int page, const wchar_t *class_name, const wchar_t *value,
                        DWORD style, int x, int y, int w, int h, int type, const char *key) {
    Control *c;
    if (app.count >= 220)
        return NULL;
    c = &app.controls[app.count++];
    memset(c, 0, sizeof *c);
    c->id = id;
    c->page = page;
    c->x = x;
    c->y = y;
    c->w = w;
    c->h = h;
    c->type = type;
    c->key = key;
    c->hwnd = CreateWindowExW(type == 1 ? WS_EX_CLIENTEDGE : 0, class_name, value,
                              WS_CHILD | WS_VISIBLE | style, 0, 0, 1, 1, app.window,
                              (HMENU)(INT_PTR)id, app.instance, NULL);
    SendMessageW(c->hwnd, WM_SETFONT, (WPARAM)app.font, TRUE);
    if (type == 1)
        SendMessageW(c->hwnd, EM_SETLIMITTEXT,
                     id == C_DLL || id == P_OUTPUT ? VUV_PATH - 1
                     : id == P_PROJECT             ? 90
                                                   : 80,
                     0);
    return c->hwnd;
}
static void label(int page, const wchar_t *s, int x, int y, int w, int h) {
    add_control(0, page, L"STATIC", s, SS_LEFT, x, y, w, h, 0, NULL);
}
static void group(int page, const wchar_t *s, int x, int w) {
    add_control(0, page, L"BUTTON", s, BS_GROUPBOX, x, 0, w, 302, 0, NULL);
}
static void edit(int id, int page, const wchar_t *value, int x, int y, int w, const char *key) {
    add_control(id, page, L"EDIT", value, WS_TABSTOP | ES_AUTOHSCROLL, x, y, w, 23, 1, key);
}
static void button(int id, int page, const wchar_t *s, int x, int y, int w) {
    add_control(id, page, L"BUTTON", s, WS_TABSTOP | BS_PUSHBUTTON, x, y, w, 27, 2, NULL);
}
static void check(int id, int page, const wchar_t *s, int x, int y, int w, int value,
                  const char *key) {
    HWND h = add_control(id, page, L"BUTTON", s, WS_TABSTOP | BS_AUTOCHECKBOX, x, y, w, 23, 3, key);
    SendMessageW(h, BM_SETCHECK, value ? BST_CHECKED : BST_UNCHECKED, 0);
}
static void combo(int id, int page, const wchar_t *items, int x, int y, int w, int select,
                  const char *key) {
    HWND h = add_control(id, page, L"COMBOBOX", L"", WS_TABSTOP | CBS_DROPDOWNLIST | WS_VSCROLL, x,
                         y, w, 220, 4, key);
    const wchar_t *p = items;
    while (*p) {
        SendMessageW(h, CB_ADDSTRING, 0, (LPARAM)p);
        p += wcslen(p) + 1;
    }
    SendMessageW(h, CB_SETCURSEL, select, 0);
}
static void field(int id, int page, const wchar_t *title, const wchar_t *value, int x, int row,
                  int width, const char *key) {
    int y = 27 + row * 29;
    label(page, title, x, y + 3, 122, 21);
    edit(id, page, value, x + 124, y, width, key);
}
static void fonts(void) {
    HDC dc = GetDC(NULL);
    app.dpi = GetDeviceCaps(dc, LOGPIXELSX);
    ReleaseDC(NULL, dc);
    app.font = CreateFontW(-scaled(14), 0, 0, 0, FW_NORMAL, 0, 0, 0, DEFAULT_CHARSET, 0, 0,
                           CLEARTYPE_QUALITY, 0, L"Microsoft YaHei");
    app.small = CreateFontW(-scaled(12), 0, 0, 0, FW_NORMAL, 0, 0, 0, DEFAULT_CHARSET, 0, 0,
                            CLEARTYPE_QUALITY, 0, L"Microsoft YaHei");
    app.bold = CreateFontW(-scaled(15), 0, 0, 0, FW_SEMIBOLD, 0, 0, 0, DEFAULT_CHARSET, 0, 0,
                           CLEARTYPE_QUALITY, 0, L"Microsoft YaHei");
    app.title = CreateFontW(-scaled(23), 0, 0, 0, FW_SEMIBOLD, 0, 0, 0, DEFAULT_CHARSET, 0, 0,
                            CLEARTYPE_QUALITY, 0, L"Microsoft YaHei");
    app.metric = CreateFontW(-scaled(24), 0, 0, 0, FW_SEMIBOLD, 0, 0, 0, DEFAULT_CHARSET, 0, 0,
                             CLEARTYPE_QUALITY, 0, L"Segoe UI");
}
static void create_controls(void) {
    TCITEMW item;
    LVCOLUMNW col;
    const wchar_t *tabs[] = {L"设备连接与独立控制", L"相机参数与读取", L"扫描初始化与采集",
                             L"数据与日志"};
    int i;
    app.tabs = CreateWindowExW(0, WC_TABCONTROLW, L"", WS_CHILD | WS_VISIBLE | WS_TABSTOP, 0, 0, 0,
                               0, app.window, (HMENU)ID_TABS, app.instance, NULL);
    SendMessageW(app.tabs, WM_SETFONT, (WPARAM)app.font, TRUE);
    for (i = 0; i < 4; i++) {
        memset(&item, 0, sizeof item);
        item.mask = TCIF_TEXT;
        item.pszText = (wchar_t *)tabs[i];
        TabCtrl_InsertItem(app.tabs, i, &item);
    }
    button(ID_STOP, -1, L"■ 全部停止", 1235, -170, 130);
    button(ID_EXIT, -1, L"安全退出", 1375, -170, 105);
    group(0, L" 电机连接 · Newport SMC100 ", 12, 480);
    group(0, L" 电机独立运动（不启动扫描） ", 503, 480);
    group(0, L" 相机连接 · Andor Newton ", 994, 490);
    label(0, L"设备模式", 28, 30, 112, 22);
    combo(M_MODE, 0, L"模拟电机\0真实串口电机\0\0", 152, 26, 145, 0, NULL);
    label(0, L"控制器", 313, 30, 63, 22);
    combo(M_MODEL, 0, L"SMC100CC\0SMC100PP\0\0", 379, 26, 96, 0, "controller");
    field(M_PORT, 0, L"串口 COM", L"COM3", 28, 1, 145, "port");
    label(0, L"地址", 313, 59, 60, 22);
    edit(M_ADDRESS, 0, L"1", 379, 56, 96, "address");
    field(M_BAUD, 0, L"波特率", L"57600", 28, 2, 145, "baud");
    check(M_XON, 0, L"XON / XOFF", 313, 85, 160, 1, "xonxoff");
    field(M_LO, 0, L"本机角度下限/°", L"-5", 28, 3, 145, "software_min");
    label(0, L"上限/°", 313, 117, 65, 22);
    edit(M_HI, 0, L"5", 379, 114, 96, "software_max");
    field(M_TOL, 0, L"到位允差/°", L"0.001", 28, 4, 145, "tolerance");
    label(0, L"超时/s", 313, 146, 65, 22);
    edit(M_TIMEOUT, 0, L"2", 379, 143, 96, "serial_timeout");
    field(M_MOVE_TIMEOUT, 0, L"运动超时/s", L"120", 28, 5, 145, "move_timeout");
    button(M_CONNECT, 0, L"连接电机", 28, 215, 135);
    button(M_DISCONNECT, 0, L"断开电机", 176, 215, 135);
    label(0, L"连接不自动归零。SL/SR 为控制器软件限位。\n本机保护变更后需重新连接。", 28, 252, 444,
          40);
    field(M_ABS, 0, L"绝对目标/°", L"0", 520, 0, 155, "manual_target");
    button(M_GO, 0, L"绝对定位", 815, 26, 150);
    field(M_STEP, 0, L"相对步长/°", L"0.1", 520, 2, 155, "manual_step");
    button(M_MINUS, 0, L"− 相对运动", 815, 84, 150);
    button(M_PLUS, 0, L"＋ 相对运动", 815, 120, 150);
    field(M_VELOCITY, 0, L"运动速度/°/s", L"1", 520, 4, 155, "manual_velocity");
    button(M_SPEED, 0, L"设置速度", 815, 143, 150);
    button(M_HOME, 0, L"归零 / 回参考位", 520, 215, 235);
    label(0,
          L"只连接电机即可运动；相机连接不受影响。\n归零和定位会实际运动，请确认路径及线缆余量。",
          520, 252, 448, 40);
    label(0, L"设备模式", 1012, 30, 110, 22);
    combo(C_MODE, 0, L"模拟相机\0真实相机 / SDK2\0\0", 1136, 26, 190, 0, NULL);
    label(0, L"索引", 1340, 30, 55, 22);
    edit(C_INDEX, 0, L"0", 1390, 26, 75, "camera_index");
    label(0, L"64位 SDK2 DLL 路径", 1012, 70, 350, 22);
    edit(C_DLL, 0, L"", 1012, 96, 360, "sdk_path");
    button(C_DLL_BROWSE, 0, L"选择", 1382, 94, 83);
    button(C_CONNECT, 0, L"连接相机", 1012, 143, 138);
    button(C_DISCONNECT, 0, L"断开相机", 1162, 143, 138);
    button(C_CAPTURE, 0, L"独立采集并读取", 1012, 215, 235);
    label(0, L"相机可单独设置与采集；真实连接需要厂家驱动\n及 Andor SDK2，断开低温相机会先回温。",
          1012, 252, 452, 40);
    group(1, L" 曝光与读取区域 ", 12, 480);
    group(1, L" 读出、增益与快门 ", 503, 480);
    group(1, L" 制冷、应用与数据读取 ", 994, 490);
    field(C_EXP, 1, L"曝光时间/ms", L"100", 28, 0, 115, "exposure_ms");
    label(1, L"平均帧数", 285, 30, 90, 22);
    edit(C_FRAMES, 1, L"1", 380, 26, 94, "frames");
    label(1, L"读取模式", 28, 59, 120, 22);
    combo(C_READ, 1, L"FVB 全垂直合并\0单轨 Single Track\0二维图像 / ROI\0\0", 152, 56, 322, 0,
          "read_mode");
    field(C_HBIN, 1, L"横向 bin", L"1", 28, 2, 115, "hbin");
    label(1, L"纵向 bin", 285, 88, 90, 22);
    edit(C_VBIN, 1, L"1", 380, 85, 94, "vbin");
    field(C_X0, 1, L"ROI X起点(1起)", L"1", 28, 3, 115, "x0");
    label(1, L"X终点(0全幅)", 275, 117, 104, 22);
    edit(C_X1, 1, L"0", 380, 114, 94, "x1");
    field(C_Y0, 1, L"ROI Y起点(1起)", L"1", 28, 4, 115, "y0");
    label(1, L"Y终点(0全幅)", 275, 146, 104, 22);
    edit(C_Y1, 1, L"0", 380, 143, 94, "y1");
    field(C_TRACK_C, 1, L"轨道中心(0自动)", L"0", 28, 5, 115, "track_center");
    label(1, L"轨道高度", 285, 175, 90, 22);
    edit(C_TRACK_H, 1, L"16", 380, 172, 94, "track_height");
    check(C_ROWMEAN, 1, L"图像行取平均（未勾选时求和）", 28, 213, 440, 0, "row_mean");
    label(1, L"原始 int32 帧始终保存；不自动扣暗或截断负值。", 28, 256, 445, 37);
    field(C_ADC, 1, L"ADC通道索引", L"0", 520, 0, 102, "ad");
    label(1, L"放大器索引", 765, 30, 110, 22);
    edit(C_AMP, 1, L"0", 877, 26, 90, "amp");
    field(C_HS, 1, L"水平速度索引", L"0", 520, 1, 102, "hs");
    label(1, L"垂直(-1推荐)", 760, 59, 115, 22);
    edit(C_VS, 1, L"-1", 877, 56, 90, "vs");
    field(C_GAIN, 1, L"前置增益索引", L"0", 520, 2, 102, "preamp");
    label(1, L"采集超时/s", 765, 88, 110, 22);
    edit(C_TIMEOUT, 1, L"120", 877, 85, 90, "acq_timeout");
    label(1, L"快门模式", 520, 117, 120, 22);
    combo(C_SHUTTER, 1, L"保留当前设置\0自动\0常开\0常闭 / 暗场\0\0", 644, 114, 323, 0, "shutter");
    field(C_TTL, 1, L"快门TTL (0/1)", L"1", 520, 4, 102, "shutter_ttl");
    field(C_OPEN, 1, L"开启延时/ms", L"0", 520, 5, 102, "shutter_open_ms");
    label(1, L"关闭延时/ms", 760, 175, 115, 22);
    edit(C_CLOSE, 1, L"0", 877, 172, 90, "shutter_close_ms");
    add_control(C_CAPS, 1, L"STATIC", L"连接相机后显示可用索引范围。", SS_LEFT, 520, 220, 447, 65,
                0, NULL);
    field(C_TEMP, 1, L"目标温度/℃", L"-70", 1012, 0, 145, "temperature");
    button(C_COOL_ON, 1, L"开启制冷", 1012, 75, 135);
    button(C_COOL_OFF, 1, L"关闭制冷", 1160, 75, 135);
    check(C_STABLE, 1, L"采集前要求温度稳定", 1012, 118, 410, 0, "require_stable");
    button(C_APPLY, 1, L"应用相机参数", 1012, 165, 195);
    button(C_READ_NOW, 1, L"采集并读取", 1220, 165, 245);
    button(C_EXPORT, 1, L"导出当前光谱 CSV", 1012, 215, 245);
    add_control(C_ACTUAL, 1, L"STATIC", L"实际曝光与读出信息：等待应用参数", SS_LEFT, 1012, 257,
                450, 40, 0, NULL);
    group(2, L" 扫描计划与输出 ", 12, 600);
    group(2, L" 初始化与执行 ", 623, 360);
    group(2, L" 中心波长标定 λ(θ) ", 994, 490);
    label(2, L"扫描模式", 28, 30, 105, 22);
    combo(P_MODE, 2, L"点扫描（停稳后采集）\0连续扫描（运动中采集）\0\0", 145, 26, 260, 0,
          "scan_mode");
    label(2, L"坐标", 423, 30, 55, 22);
    combo(P_COORD, 2, L"角度/°\0中心波长/nm\0\0", 480, 26, 114, 0, "coordinate");
    field(P_START, 2, L"扫描起点", L"0", 28, 1, 155, "start");
    label(2, L"采样点数", 330, 59, 110, 22);
    edit(P_POINTS, 2, L"21", 455, 56, 139, "points");
    field(P_STEP, 2, L"点扫描步长", L"0.1", 28, 2, 155, "step");
    label(2, L"停稳时间/s", 330, 88, 115, 22);
    edit(P_SETTLE, 2, L"0.2", 455, 85, 139, "settle_s");
    field(P_VELOCITY, 2, L"连续速度/°/s", L"0.1", 28, 3, 155, "scan_velocity");
    label(2, L"采样周期/s", 330, 117, 115, 22);
    edit(P_PERIOD, 2, L"0.5", 455, 114, 139, "period_s");
    field(P_LEAD, 2, L"连续预运行/s", L"0.25", 28, 4, 155, "lead_s");
    label(2, L"积分起/止列", 330, 146, 115, 22);
    edit(P_FIRST, 2, L"0", 455, 143, 64, "signal_first");
    edit(P_LAST, 2, L"-1", 529, 143, 65, "signal_last");
    field(P_PROJECT, 2, L"项目名称", L"VUV波长扫描", 28, 5, 442, "project");
    label(2, L"数据目录", 28, 204, 105, 22);
    edit(P_OUTPUT, 2, app.engine.output_dir, 145, 201, 365, "output");
    button(P_FOLDER, 2, L"选择", 519, 199, 75);
    label(2, L"点数包含首点；积分列从0起，止列-1为末列。\n连续速度带符号，采满设定点数后停止。", 28,
          251, 565, 43);
    label(2, L"初始化会配置相机并移动到扫描起点。\n更改参数或独立运动后，需要重新初始化。", 640, 31,
          325, 52);
    button(P_PREVIEW, 2, L"检查范围与采样周期", 640, 92, 325);
    button(P_INITIALIZE, 2, L"① 扫描初始化", 640, 133, 157);
    button(P_RUN, 2, L"② 开始扫描", 808, 133, 157);
    add_control(P_SUMMARY, 2, L"STATIC", L"连接两台设备后检查计划并初始化。", SS_LEFT, 640, 182,
                325, 105, 0, NULL);
    label(2, L"多项式阶次", 1012, 30, 108, 22);
    combo(K_DEGREE, 2, L"一次\0二次\0三次\0\0", 1136, 26, 125, 2, "cal_degree");
    check(K_SIM, 2, L"仅模拟", 1280, 27, 170, 0, "cal_simulation");
    field(K_A0, 2, L"a0 / nm", L"0", 1012, 1, 145, "cal_a0");
    label(2, L"a1", 1300, 59, 40, 22);
    edit(K_A1, 2, L"1", 1343, 56, 120, "cal_a1");
    field(K_A2, 2, L"a2", L"0", 1012, 2, 145, "cal_a2");
    label(2, L"a3", 1300, 88, 40, 22);
    edit(K_A3, 2, L"0", 1343, 85, 120, "cal_a3");
    field(K_LO, 2, L"角度下限/°", L"-5", 1012, 3, 145, "cal_lo");
    label(2, L"上限/°", 1285, 117, 60, 22);
    edit(K_HI, 2, L"5", 1343, 114, 120, "cal_hi");
    button(K_APPLY, 2, L"应用标定", 1012, 166, 133);
    button(K_CLEAR, 2, L"清除", 1156, 166, 100);
    button(K_IMPORT, 2, L"导入 JSON", 1267, 166, 196);
    add_control(K_STATUS, 2, L"STATIC",
                L"未应用标定：请使用角度模式。\n标定只定义选定参考像素的中心波长。", SS_LEFT, 1012,
                220, 450, 66, 0, NULL);
    label(3, L"数据目录与运行记录", 24, 16, 900, 25);
    button(D_FOLDER, 3, L"打开数据文件夹", 1120, 10, 180);
    button(D_EXPORT, 3, L"导出当前光谱", 1310, 10, 165);
    add_control(D_PATH, 3, L"STATIC", app.engine.output_dir, SS_LEFT, 24, 49, 1440, 28, 0, NULL);
    add_control(D_LOG, 3, L"EDIT", L"", WS_VSCROLL | ES_MULTILINE | ES_READONLY | ES_AUTOVSCROLL,
                24, 85, 1440, 205, 5, NULL);
    for (i = 0; i < 2; i++) {
        app.plot[i].engine = &app.engine;
        app.plot[i].spectrum = i;
        app.plots[i] =
            CreateWindowExW(0, L"VUVNativePlot", L"", WS_CHILD | WS_VISIBLE, 0, 0, 1, 1, app.window,
                            (HMENU)(INT_PTR)(ID_PLOT1 + i), app.instance, &app.plot[i]);
    }
    app.list = CreateWindowExW(WS_EX_CLIENTEDGE, WC_LISTVIEWW, L"",
                               WS_CHILD | WS_VISIBLE | LVS_REPORT | LVS_OWNERDATA | LVS_SINGLESEL,
                               0, 0, 1, 1, app.window, (HMENU)ID_LIST, app.instance, NULL);
    SendMessageW(app.list, WM_SETFONT, (WPARAM)app.font, TRUE);
    ListView_SetExtendedListViewStyle(app.list, LVS_EX_FULLROWSELECT | LVS_EX_DOUBLEBUFFER |
                                                    LVS_EX_GRIDLINES);
    const wchar_t *headers[] = {L"点",          L"模式",           L"位置/°",
                                L"中心波长/nm", L"积分信号/count", L"前后位置跨度/°",
                                L"实际开始/s",  L"采样延迟/s"};
    for (i = 0; i < 8; i++) {
        memset(&col, 0, sizeof col);
        col.mask = LVCF_TEXT | LVCF_WIDTH;
        col.pszText = (wchar_t *)headers[i];
        col.cx = scaled(i == 0 ? 55 : i == 4 ? 190 : 160);
        ListView_InsertColumn(app.list, i, &col);
    }
}
static void layout(void) {
    RECT r;
    int i, page_top = scaled(190), page_h = scaled(314), chart_top = page_top + page_h + scaled(10),
           space, chart_h, table_h;
    GetClientRect(app.window, &r);
    app.width = r.right;
    app.height = r.bottom;
    MoveWindow(app.tabs, scaled(12), scaled(155), r.right - scaled(24), scaled(29), TRUE);
    for (i = 0; i < app.count; i++) {
        Control *c = &app.controls[i];
        int x = MulDiv(c->x, r.right, 1500), w = MulDiv(c->w, r.right, 1500),
            y = c->page == -1 ? scaled(c->y + 190) : page_top + scaled(c->y), h = scaled(c->h);
        MoveWindow(c->hwnd, x, y, w, h, TRUE);
        ShowWindow(c->hwnd, c->page < 0 || c->page == app.page ? SW_SHOW : SW_HIDE);
    }
    space = r.bottom - chart_top - scaled(32);
    chart_h = (int)(space * .60);
    if (chart_h < scaled(130))
        chart_h = scaled(130);
    if (chart_h > scaled(270))
        chart_h = scaled(270);
    table_h = space - chart_h - scaled(12);
    if (table_h < scaled(42))
        table_h = scaled(42);
    MoveWindow(app.plots[0], scaled(12), chart_top, (r.right - scaled(36)) / 2, chart_h, TRUE);
    MoveWindow(app.plots[1], (r.right + scaled(12)) / 2, chart_top, (r.right - scaled(36)) / 2,
               chart_h, TRUE);
    MoveWindow(app.list, scaled(12), chart_top + chart_h + scaled(12), r.right - scaled(24),
               table_h, TRUE);
    int total = r.right - scaled(30), weights[] = {5, 9, 13, 13, 19, 15, 13, 13};
    for (i = 0; i < 8; i++)
        ListView_SetColumnWidth(app.list, i, total * weights[i] / 100);
    InvalidateRect(app.window, NULL, TRUE);
}
static int read_camera(Operation *o, wchar_t *err) {
    VuvCameraConfig *c = &o->camera;
    *c = vuv_camera_defaults();
#define RD(id, label, lo, hi, p)                                                                   \
    if (!read_double(id, label, lo, hi, p, err))                                                   \
    return 0
#define RI(id, label, lo, hi, p)                                                                   \
    if (!read_int(id, label, lo, hi, p, err))                                                      \
    return 0
    RD(C_EXP, L"曝光时间", .01, 3600000, &c->exposure_ms);
    RI(C_FRAMES, L"平均帧数", 1, 100, &c->frames);
    int modes[] = {0, 3, 4};
    c->read_mode = modes[selection(C_READ) < 0 ? 0 : selection(C_READ)];
    RI(C_HBIN, L"横向bin", 1, 32768, &c->hbin);
    RI(C_VBIN, L"纵向bin", 1, 32768, &c->vbin);
    RI(C_X0, L"ROI X起点", 1, 32768, &c->x0);
    RI(C_X1, L"ROI X终点", 0, 32768, &c->x1);
    RI(C_Y0, L"ROI Y起点", 1, 32768, &c->y0);
    RI(C_Y1, L"ROI Y终点", 0, 32768, &c->y1);
    RI(C_TRACK_C, L"单轨中心", 0, 32768, &c->track_center);
    RI(C_TRACK_H, L"单轨高度", 1, 32768, &c->track_height);
    RI(C_ADC, L"ADC索引", 0, 32768, &c->ad);
    RI(C_AMP, L"放大器索引", 0, 32768, &c->amp);
    RI(C_HS, L"水平速度索引", 0, 32768, &c->hs);
    RI(C_VS, L"垂直速度索引", -1, 32768, &c->vs);
    RI(C_GAIN, L"前置增益索引", 0, 32768, &c->preamp);
    c->shutter = selection(C_SHUTTER) - 1;
    RI(C_TTL, L"快门TTL", 0, 1, &c->shutter_ttl);
    RI(C_OPEN, L"开启延时", 0, 32768, &c->shutter_open_ms);
    RI(C_CLOSE, L"关闭延时", 0, 32768, &c->shutter_close_ms);
    RD(C_TIMEOUT, L"相机超时", .1, 7200, &c->timeout_s);
    RI(C_TEMP, L"目标温度", -150, 30, &c->temperature);
    c->require_stable = checked(C_STABLE);
    c->row_mean = checked(C_ROWMEAN);
    return 1;
#undef RD
#undef RI
}
static int read_plan(Operation *o, wchar_t *err) {
    VuvPlan *p = &o->plan;
    *p = vuv_plan_defaults();
    p->mode = selection(P_MODE);
    p->coordinate = selection(P_COORD);
    if (!read_double(P_START, L"扫描起点", -1e9, 1e9, &p->start, err) ||
        !read_int(P_POINTS, L"采样点数", 1, VUV_MAX_POINTS, &p->points, err) ||
        !read_double(P_SETTLE, L"停稳时间", 0, 60, &p->settle_s, err) ||
        !read_int(P_FIRST, L"积分起列", 0, 32768, &p->signal_first, err) ||
        !read_int(P_LAST, L"积分止列", -1, 32768, &p->signal_last, err))
        return 0;
    if (p->mode == VUV_POINT && !read_double(P_STEP, L"扫描步长", -1e9, 1e9, &p->step, err))
        return 0;
    if (p->mode == VUV_CONTINUOUS &&
        (!read_double(P_VELOCITY, L"连续速度", -360, 360, &p->velocity, err) ||
         !read_double(P_PERIOD, L"采样周期", .05, 3600, &p->period_s, err) ||
         !read_double(P_LEAD, L"预运行时间", .1, 30, &p->lead_s, err)))
        return 0;
    get_text(P_OUTPUT, o->output, VUV_PATH);
    get_text(P_PROJECT, o->project, 96);
    return 1;
}
static int read_capture_output(Operation *o, wchar_t *err) {
    if (!read_int(P_FIRST, L"积分起列", 0, 32768, &o->plan.signal_first, err) ||
        !read_int(P_LAST, L"积分止列", -1, 32768, &o->plan.signal_last, err))
        return 0;
    get_text(P_OUTPUT, o->output, VUV_PATH);
    get_text(P_PROJECT, o->project, 96);
    return 1;
}
static int read_motor(Operation *o, wchar_t *err) {
    MotorConfig *m = &o->motor;
    memset(m, 0, sizeof *m);
    m->simulated = selection(M_MODE) == 0;
    m->pp = selection(M_MODEL) == 1;
    m->xonxoff = checked(M_XON);
    get_text(M_PORT, m->port, 64);
    return read_int(M_BAUD, L"波特率", 9600, 115200, &m->baud, err) &&
           read_int(M_ADDRESS, L"控制器地址", 1, 31, &m->address, err) &&
           read_double(M_LO, L"本机角度下限", -1e6, 1e6, &m->limits.local_min, err) &&
           read_double(M_HI, L"本机角度上限", -1e6, 1e6, &m->limits.local_max, err) &&
           read_double(M_TOL, L"到位允差", 1e-7, 1, &m->limits.tolerance, err) &&
           read_double(M_TIMEOUT, L"串口超时", .05, 30, &m->timeout_s, err) &&
           read_double(M_MOVE_TIMEOUT, L"运动超时", .1, 3600, &m->move_timeout_s, err);
}
static void display_error(const wchar_t *s) {
    engine_log(&app.engine, s);
    if (!app.self_test)
        MessageBoxW(app.window, s, L"操作提示", MB_OK | MB_ICONWARNING);
}
static void refresh_ui(void) {
    UiState s;
    int i, busy, pending, point_mode, rm;
    wchar_t textbuf[512], logbuf[28000];
    engine_snapshot(&app.engine, &s);
    busy = app.engine.busy || app.engine.stopping || app.engine.exit_requested;
    pending = app.engine.camera_pending;
    point_mode = selection(P_MODE) == 0;
    rm = selection(C_READ);
    for (i = 0; i < app.count; i++) {
        Control *c = &app.controls[i];
        if (c->type == 1 || c->type == 2 || c->type == 3 || c->type == 4)
            EnableWindow(c->hwnd, !busy);
    }
    EnableWindow(ctrl(ID_STOP), TRUE);
    EnableWindow(ctrl(ID_EXIT), !app.engine.exit_requested);
    int motor_ids[] = {M_GO, M_MINUS, M_PLUS, M_SPEED, M_HOME, M_DISCONNECT};
    for (i = 0; i < 6; i++)
        EnableWindow(ctrl(motor_ids[i]), !busy && s.motor_connected);
    int camera_ids[] = {C_APPLY, C_CAPTURE, C_READ_NOW, C_COOL_ON, C_COOL_OFF};
    for (i = 0; i < 5; i++)
        EnableWindow(ctrl(camera_ids[i]), !busy && s.camera_connected && !pending);
    EnableWindow(ctrl(C_DISCONNECT), !busy && s.camera_handle && !pending);
    EnableWindow(ctrl(C_CONNECT), !busy && !pending);
    EnableWindow(ctrl(P_INITIALIZE), !busy && s.motor_connected && s.camera_connected && !pending);
    EnableWindow(ctrl(P_RUN), !busy && app.engine.init_valid && s.motor_connected &&
                                  s.camera_connected && !pending);
    EnableWindow(ctrl(P_STEP), !busy && point_mode);
    EnableWindow(ctrl(P_VELOCITY), !busy && !point_mode);
    EnableWindow(ctrl(P_PERIOD), !busy && !point_mode);
    EnableWindow(ctrl(P_LEAD), !busy && !point_mode);
    int roi_ids[] = {C_VBIN, C_X0, C_X1, C_Y0, C_Y1};
    for (i = 0; i < 5; i++)
        EnableWindow(ctrl(roi_ids[i]), !busy && rm == 2);
    EnableWindow(ctrl(C_TRACK_C), !busy && rm == 1);
    EnableWindow(ctrl(C_TRACK_H), !busy && rm == 1);
    swprintf(textbuf, 512,
             L"索引范围：ADC 0～%d，放大器 0～%d\nHS 0～%d，VS 0～%d，增益 "
             L"0～%d。\nHS/增益可用性随 ADC 与放大器组合变化。",
             s.ad_count ? s.ad_count - 1 : 0, s.amp_count ? s.amp_count - 1 : 0,
             s.hs_count ? s.hs_count - 1 : 0, s.vs_count ? s.vs_count - 1 : 0,
             s.gain_count ? s.gain_count - 1 : 0);
    text(C_CAPS, textbuf);
    if (isfinite(s.actual_exposure)) {
        swprintf(textbuf, 512, L"实际曝光 %.4f ms · 输出 %d×%d\n参数变更后请重新应用或初始化。",
                 s.actual_exposure * 1000, s.cols, s.rows);
        text(C_ACTUAL, textbuf);
    }
    text(D_PATH, s.last_run[0] ? s.last_run : app.engine.output_dir);
    if (s.completed != app.last_count) {
        ListView_SetItemCountEx(app.list, s.completed, LVSICF_NOINVALIDATEALL);
        if (s.completed)
            ListView_EnsureVisible(app.list, s.completed - 1, FALSE);
        app.last_count = s.completed;
    }
    EnterCriticalSection(&app.engine.state_lock);
    logbuf[0] = 0;
    for (i = 0; i < app.engine.log_count; i++) {
        wcscat(logbuf, app.engine.logs[i]);
        wcscat(logbuf, L"\r\n");
    }
    LeaveCriticalSection(&app.engine.state_lock);
    text(D_LOG, logbuf);
    SendMessageW(ctrl(D_LOG), EM_SETSEL, (WPARAM)-1, (LPARAM)-1);
    SendMessageW(ctrl(D_LOG), EM_SCROLLCARET, 0, 0);
    if (app.engine.init_valid) {
        VuvResolved r = app.engine.resolved;
        swprintf(textbuf, 512,
                 L"初始化完成\n起点 %.6f°，%ls %.6f°\n采样点数 %d，实际曝光 %.4f ms\n%ls",
                 r.start_angle, point_mode ? L"终点" : L"保护终点", r.last_angle, s.total,
                 s.actual_exposure * 1000,
                 point_mode ? L"每点定位停稳后采集。" : L"连续运动；位置为曝光中点软件估计。");
        text(P_SUMMARY, textbuf);
    } else if (s.phase == PH_COMPLETE || s.phase == PH_STOPPED || s.phase == PH_ERROR)
        text(P_SUMMARY, L"本次采集已结束或状态改变。\n再次运行请重新初始化。\n连续扫描保存前后位置"
                        L"界限和实际时间。\n严格同步需要另行设计硬件触发。");
    InvalidateRect(app.window, NULL, FALSE);
    InvalidateRect(app.plots[0], NULL, FALSE);
    InvalidateRect(app.plots[1], NULL, FALSE);
    InvalidateRect(app.list, NULL, FALSE);
}
static void choose_file(int target, const wchar_t *filter, const wchar_t *title) {
    OPENFILENAMEW ofn;
    wchar_t file[VUV_PATH];
    get_text(target, file, VUV_PATH);
    memset(&ofn, 0, sizeof ofn);
    ofn.lStructSize = sizeof ofn;
    ofn.hwndOwner = app.window;
    ofn.lpstrFile = file;
    ofn.nMaxFile = VUV_PATH;
    ofn.lpstrFilter = filter;
    ofn.lpstrTitle = title;
    ofn.Flags = OFN_FILEMUSTEXIST | OFN_PATHMUSTEXIST | OFN_NOCHANGEDIR;
    if (GetOpenFileNameW(&ofn))
        text(target, file);
}
static int CALLBACK browse_callback(HWND h, UINT msg, LPARAM p, LPARAM data) {
    (void)p;
    if (msg == BFFM_INITIALIZED)
        SendMessageW(h, BFFM_SETSELECTIONW, TRUE, data);
    return 0;
}
static void choose_folder(void) {
    BROWSEINFOW b;
    wchar_t current[VUV_PATH], path[MAX_PATH];
    PIDLIST_ABSOLUTE id;
    get_text(P_OUTPUT, current, VUV_PATH);
    memset(&b, 0, sizeof b);
    b.hwndOwner = app.window;
    b.lpszTitle = L"选择本机数据保存目录";
    b.ulFlags = BIF_RETURNONLYFSDIRS | BIF_NEWDIALOGSTYLE;
    b.lpfn = browse_callback;
    b.lParam = (LPARAM)current;
    id = SHBrowseForFolderW(&b);
    if (id) {
        if (SHGetPathFromIDListW(id, path))
            text(P_OUTPUT, path);
        CoTaskMemFree(id);
    }
}
static void export_spectrum(void) {
    OPENFILENAMEW ofn;
    wchar_t file[VUV_PATH] = L"VUV_spectrum.csv", err[VUV_ERR];
    memset(&ofn, 0, sizeof ofn);
    ofn.lStructSize = sizeof ofn;
    ofn.hwndOwner = app.window;
    ofn.lpstrFile = file;
    ofn.nMaxFile = VUV_PATH;
    ofn.lpstrFilter = L"CSV (*.csv)\0*.csv\0\0";
    ofn.lpstrDefExt = L"csv";
    ofn.Flags = OFN_OVERWRITEPROMPT | OFN_PATHMUSTEXIST | OFN_NOCHANGEDIR;
    if (GetSaveFileNameW(&ofn)) {
        if (!engine_export(&app.engine, file, err))
            display_error(err);
        else
            engine_log(&app.engine, L"当前光谱 CSV 已导出");
    }
}
static void open_data_folder(void) {
    UiState s;
    engine_snapshot(&app.engine, &s);
    ShellExecuteW(app.window, L"open", s.last_run[0] ? s.last_run : app.engine.output_dir, NULL,
                  NULL, SW_SHOWNORMAL);
}
static void apply_calibration(int from_json) {
    VuvCalibration c;
    wchar_t err[VUV_ERR];
    char why[256];
    int i;
    memset(&c, 0, sizeof c);
    c.reference_pixel = NAN;
    c.enabled = 1;
    if (from_json) {
        OPENFILENAMEW ofn;
        wchar_t path[VUV_PATH] = L"";
        FILE *f;
        char *textdata;
        long n;
        memset(&ofn, 0, sizeof ofn);
        ofn.lStructSize = sizeof ofn;
        ofn.hwndOwner = app.window;
        ofn.lpstrFile = path;
        ofn.nMaxFile = VUV_PATH;
        ofn.lpstrFilter = L"Calibration JSON\0*.json\0All files\0*.*\0\0";
        ofn.Flags = OFN_FILEMUSTEXIST | OFN_NOCHANGEDIR;
        if (!GetOpenFileNameW(&ofn))
            return;
        f = _wfopen(path, L"rb");
        if (!f) {
            display_error(L"无法打开标定文件");
            return;
        }
        fseek(f, 0, SEEK_END);
        n = ftell(f);
        rewind(f);
        if (n <= 0 || n > 65536) {
            fclose(f);
            display_error(L"标定文件为空或大于64KB");
            return;
        }
        textdata = (char *)malloc((size_t)n + 1);
        if (!textdata) {
            fclose(f);
            return;
        }
        size_t got = fread(textdata, 1, (size_t)n, f);
        textdata[got] = 0;
        fclose(f);
        int ok = vuv_cal_json(textdata, &c, why, sizeof why);
        free(textdata);
        if (!ok) {
            native_core_error(err, why);
            display_error(err);
            return;
        }
    } else {
        c.degree = selection(K_DEGREE) + 1;
        c.simulation_only = checked(K_SIM);
        for (i = 0; i < 4; i++)
            if (!read_double(K_A0 + i, L"标定系数", -1e12, 1e12, &c.a[i], err)) {
                display_error(err);
                return;
            }
        if (!read_double(K_LO, L"标定角度下限", -1e6, 1e6, &c.lo, err) ||
            !read_double(K_HI, L"标定角度上限", -1e6, 1e6, &c.hi, err)) {
            display_error(err);
            return;
        }
    }
    if (!engine_calibration(&app.engine, &c, err)) {
        display_error(err);
        return;
    }
    app.loading = 1;
    SendMessageW(ctrl(K_DEGREE), CB_SETCURSEL, c.degree - 1, 0);
    SendMessageW(ctrl(K_SIM), BM_SETCHECK, c.simulation_only ? BST_CHECKED : BST_UNCHECKED, 0);
    for (i = 0; i < 4; i++)
        set_number(K_A0 + i, c.a[i]);
    set_number(K_LO, c.lo);
    set_number(K_HI, c.hi);
    app.loading = 0;
    app.cal_dirty = 0;
    swprintf(err, VUV_ERR, L"已应用 %d 次标定，范围 %.5g°～%.5g°。\n%ls", c.degree, c.lo, c.hi,
             c.simulation_only ? L"仅模拟电机可用。" : L"请确保系数已完成实测验证。");
    text(K_STATUS, err);
    refresh_ui();
}
static void command(int id) {
    Operation o;
    wchar_t err[VUV_ERR] = L"";
    memset(&o, 0, sizeof o);
    o.camera = vuv_camera_defaults();
    o.plan = vuv_plan_defaults();
    if (id == ID_STOP) {
        engine_stop(&app.engine);
        refresh_ui();
        return;
    }
    if (id == ID_EXIT) {
        SendMessageW(app.window, WM_CLOSE, 0, 0);
        return;
    }
    if (id == C_DLL_BROWSE) {
        choose_file(C_DLL, L"Andor SDK2 DLL\0*.dll\0All files\0*.*\0\0",
                    L"选择 Andor SDK2 64位 DLL");
        return;
    }
    if (id == P_FOLDER) {
        choose_folder();
        return;
    }
    if (id == C_EXPORT || id == D_EXPORT || id == ID_EXPORT_MENU) {
        export_spectrum();
        return;
    }
    if (id == D_FOLDER || id == ID_FOLDER_MENU) {
        open_data_folder();
        return;
    }
    if (id == ID_ABOUT_MENU) {
        MessageBoxW(
            app.window,
            L"创谱科技-VUV质谱波长扫描软件\n3.0.0 · C11 / 原生 Win32 / "
            L"64位\n\n原生窗口与GDI绘图，不含浏览器、WebView或Python。\n真实设备需厂家驱动及 Andor "
            L"SDK2。\n连续位置为软件曝光中点估计，并非硬件同步。\n\n安徽创谱科技股份有限公司\ntangj"
            L"j@specreation.com",
            L"关于软件", MB_OK | MB_ICONINFORMATION);
        return;
    }
    if (id == K_APPLY || id == K_IMPORT) {
        apply_calibration(id == K_IMPORT);
        return;
    }
    if (id == K_CLEAR) {
        VuvCalibration cal;
        memset(&cal, 0, sizeof cal);
        if (!engine_calibration(&app.engine, &cal, err))
            display_error(err);
        else {
            app.cal_dirty = 0;
            text(K_STATUS, L"未应用标定：请使用角度模式。");
        }
        refresh_ui();
        return;
    }
    switch (id) {
    case M_CONNECT:
        o.kind = OP_MOTOR_CONNECT;
        if (!read_motor(&o, err))
            goto fail;
        app.motor_dirty = 0;
        break;
    case M_DISCONNECT:
        o.kind = OP_MOTOR_DISCONNECT;
        break;
    case C_CONNECT:
        o.kind = OP_CAMERA_CONNECT;
        o.camera_simulated = selection(C_MODE) == 0;
        get_text(C_DLL, o.dll_path, VUV_PATH);
        if (!read_int(C_INDEX, L"相机索引", 0, 31, &o.camera_index, err))
            goto fail;
        break;
    case C_DISCONNECT:
        o.kind = OP_CAMERA_DISCONNECT;
        break;
    case M_GO:
    case M_PLUS:
    case M_MINUS:
    case M_SPEED:
    case M_HOME:
        o.kind = id == M_GO      ? OP_MOTOR_ABSOLUTE
                 : id == M_HOME  ? OP_MOTOR_HOME
                 : id == M_SPEED ? OP_MOTOR_SPEED
                                 : OP_MOTOR_RELATIVE;
        if (!read_double(M_VELOCITY, L"运动速度", 1e-6, 360, &o.manual_velocity, err))
            goto fail;
        if (id == M_GO) {
            if (!read_double(M_ABS, L"绝对目标", -1e6, 1e6, &o.manual_value, err))
                goto fail;
        } else if (id == M_PLUS || id == M_MINUS) {
            if (!read_double(M_STEP, L"相对步长", 1e-7, 1e6, &o.manual_value, err))
                goto fail;
            if (id == M_MINUS)
                o.manual_value = -o.manual_value;
        }
        break;
    case C_APPLY:
    case C_CAPTURE:
    case C_READ_NOW:
    case C_COOL_ON:
    case C_COOL_OFF:
        o.kind = id == C_APPLY      ? OP_CAMERA_APPLY
                 : id == C_COOL_ON  ? OP_COOL_ON
                 : id == C_COOL_OFF ? OP_COOL_OFF
                                    : OP_CAMERA_CAPTURE;
        if (id == C_COOL_ON || id == C_COOL_OFF) {
            if (!read_int(C_TEMP, L"目标温度", -150, 30, &o.camera.temperature, err))
                goto fail;
        } else {
            if (!read_camera(&o, err))
                goto fail;
            if (o.kind == OP_CAMERA_CAPTURE && !read_capture_output(&o, err))
                goto fail;
        }
        break;
    case P_PREVIEW:
    case P_INITIALIZE:
    case P_RUN:
        if (!read_camera(&o, err) || !read_plan(&o, err))
            goto fail;
        if (app.motor_dirty) {
            native_error(err, L"电机连接或角度保护已修改，请重新连接电机");
            goto fail;
        }
        if (o.plan.coordinate == VUV_WAVELENGTH && app.cal_dirty) {
            native_error(err, L"标定参数已修改，请先应用标定");
            goto fail;
        }
        if (id == P_PREVIEW) {
            VuvResolved r;
            if (!engine_preview(&app.engine, &o, &r, err))
                goto fail;
            swprintf(err, VUV_ERR,
                     L"起点 %.6f°，%ls %.6f°\n点数 %d，最低周期 %.4fs\n连续单帧运动量约 %.6f°",
                     r.start_angle, o.plan.mode ? L"保护终点" : L"终点", r.last_angle,
                     o.plan.points, r.min_period_s, r.frame_motion_deg);
            text(P_SUMMARY, err);
            return;
        }
        o.kind = id == P_INITIALIZE ? OP_INITIALIZE : OP_SCAN;
        break;
    default:
        return;
    }
    if (!engine_submit(&app.engine, &o, err))
        goto fail;
    refresh_ui();
    return;
fail:
    display_error(err);
}
static void draw_text(HDC dc, const wchar_t *s, RECT r, HFONT font, COLORREF color, UINT format) {
    SelectObject(dc, font);
    SetTextColor(dc, color);
    SetBkMode(dc, TRANSPARENT);
    DrawTextW(dc, s, -1, &r, format);
}
static void paint_main(HWND h) {
    PAINTSTRUCT ps;
    HDC dc = BeginPaint(h, &ps);
    RECT r;
    UiState s;
    int i, w;
    wchar_t value[128];
    GetClientRect(h, &r);
    HBRUSH bg = CreateSolidBrush(RGB(242, 246, 250)), navy = CreateSolidBrush(RGB(18, 55, 87)),
           white = CreateSolidBrush(RGB(255, 255, 255));
    FillRect(dc, &r, bg);
    RECT head = {0, 0, r.right, scaled(70)};
    FillRect(dc, &head, navy);
    DrawIconEx(dc, scaled(20), scaled(10), LoadIconW(app.instance, MAKEINTRESOURCEW(101)),
               scaled(46), scaled(46), 0, NULL, DI_NORMAL);
    RECT title = {scaled(80), scaled(10), r.right - scaled(300), scaled(41)};
    draw_text(dc, VUV_NAME, title, app.title, RGB(245, 250, 255),
              DT_LEFT | DT_SINGLELINE | DT_VCENTER);
    title.top = scaled(43);
    title.bottom = scaled(65);
    draw_text(dc, L"SPECREATION   /   NATIVE C · VUV WAVELENGTH SCAN", title, app.small,
              RGB(161, 193, 217), DT_LEFT | DT_SINGLELINE);
    engine_snapshot(&app.engine, &s);
    w = (r.right - scaled(42)) / 4;
    const wchar_t *names[] = {L"转台位置 / °", L"CCD 温度 / ℃", L"相机积分信号 / count",
                              L"已保存点 / 目标点"};
    for (i = 0; i < 4; i++) {
        RECT box = {scaled(12) + i * (w + scaled(6)), scaled(80),
                    scaled(12) + i * (w + scaled(6)) + w, scaled(146)};
        FillRect(dc, &box, white);
        RECT t = box;
        t.left += scaled(12);
        t.top += scaled(6);
        t.bottom = t.top + scaled(20);
        draw_text(dc, names[i], t, app.small, RGB(112, 137, 157), DT_LEFT | DT_SINGLELINE);
        t.top += scaled(19);
        t.bottom = box.bottom;
        if (i == 0) {
            if (isfinite(s.position))
                swprintf(value, 128, L"%.6f", s.position);
            else
                wcscpy(value, L"—");
        } else if (i == 1) {
            if (isfinite(s.temperature))
                swprintf(value, 128, L"%.1f", s.temperature);
            else
                wcscpy(value, L"—");
        } else if (i == 2) {
            if (isfinite(s.intensity))
                swprintf(value, 128, L"%.6g", s.intensity);
            else
                wcscpy(value, L"—");
        } else
            swprintf(value, 128, L"%d / %d", s.completed, s.total);
        draw_text(dc, value, t, app.metric, RGB(25, 70, 98), DT_LEFT | DT_SINGLELINE | DT_VCENTER);
    }
    RECT status = {scaled(12), r.bottom - scaled(25), r.right - scaled(12), r.bottom};
    FillRect(dc, &status, white);
    draw_text(dc, s.message, status, app.small,
              s.phase == PH_ERROR ? RGB(183, 48, 63) : RGB(55, 110, 127),
              DT_SINGLELINE | DT_LEFT | DT_VCENTER);
    DeleteObject(bg);
    DeleteObject(navy);
    DeleteObject(white);
    EndPaint(h, &ps);
}
static void number_label(wchar_t *s, size_t n, double v) {
    double a = fabs(v);
    if (a >= 1e6)
        swprintf(s, n, L"%.2gM", v / 1e6);
    else if (a >= 10000)
        swprintf(s, n, L"%.3gk", v / 1000);
    else
        swprintf(s, n, L"%.5g", v);
}
static LRESULT CALLBACK plot_proc(HWND h, UINT msg, WPARAM wp, LPARAM lp) {
    Plot *p = (Plot *)GetWindowLongPtrW(h, GWLP_USERDATA);
    if (msg == WM_NCCREATE) {
        SetWindowLongPtrW(h, GWLP_USERDATA, (LONG_PTR)((CREATESTRUCTW *)lp)->lpCreateParams);
        return TRUE;
    }
    if (msg == WM_ERASEBKGND)
        return 1;
    if (msg == WM_PAINT && p) {
        PAINTSTRUCT ps;
        HDC dc = BeginPaint(h, &ps);
        RECT r;
        double x[2400], y[2400], xmin = INFINITY, xmax = -INFINITY, ymin = INFINITY,
                                 ymax = -INFINITY;
        int count = 0, i, has_position = 1, wave;
        wchar_t s[128];
        GetClientRect(h, &r);
        HBRUSH white = CreateSolidBrush(RGB(255, 255, 255));
        FillRect(dc, &r, white);
        DeleteObject(white);
        RECT title = {scaled(15), scaled(8), r.right - scaled(12), scaled(33)};
        draw_text(dc, p->spectrum ? L"当前相机光谱" : L"扫描位置—信号曲线", title, app.bold,
                  RGB(28, 63, 88), DT_LEFT | DT_SINGLELINE);
        Engine *e = p->engine;
        EnterCriticalSection(&e->state_lock);
        wave = e->plot_coordinate == VUV_WAVELENGTH;
        if (p->spectrum) {
            int total = e->spectrum_cols, stride = total > 2200 ? (total + 2199) / 2200 : 1;
            for (i = 0; i < total && count < 2399; i += stride) {
                x[count] = e->first_pixel + i * e->pixel_bin;
                y[count++] = e->spectrum[i];
            }
        } else {
            int total = e->sample_count, stride = total > 2200 ? (total + 2199) / 2200 : 1;
            for (i = 0; i < total; i++)
                if (!isfinite(e->samples[i].position))
                    has_position = 0;
            for (i = 0; i < total && count < 2399; i += stride) {
                VuvSample *a = &e->samples[i];
                x[count] = wave && isfinite(a->wavelength) ? a->wavelength
                           : has_position                  ? a->position
                                                           : a->point;
                y[count++] = a->intensity;
            }
        }
        LeaveCriticalSection(&e->state_lock);
        for (i = 0; i < count; i++) {
            xmin = fmin(xmin, x[i]);
            xmax = fmax(xmax, x[i]);
            ymin = fmin(ymin, y[i]);
            ymax = fmax(ymax, y[i]);
        }
        if (!count) {
            xmin = ymin = 0;
            xmax = ymax = 1;
        }
        if (xmax == xmin) {
            xmin -= .1;
            xmax += .1;
        }
        double pad = fmax(1, (ymax - ymin) * .12);
        ymin -= pad;
        ymax += pad;
        int left = scaled(65), top = scaled(43), right = r.right - scaled(22),
            bottom = r.bottom - scaled(39);
        HPEN grid = CreatePen(PS_SOLID, 1, RGB(229, 237, 244)),
             curve =
                 CreatePen(PS_SOLID, scaled(2), p->spectrum ? RGB(37, 120, 183) : RGB(0, 133, 137));
        HPEN old = (HPEN)SelectObject(dc, grid);
        for (i = 0; i <= 4; i++) {
            int yy = top + (bottom - top) * i / 4, xx = left + (right - left) * i / 4;
            MoveToEx(dc, left, yy, NULL);
            LineTo(dc, right, yy);
            number_label(s, 128, ymax - (ymax - ymin) * i / 4);
            RECT t = {0, yy - scaled(8), left - scaled(9), yy + scaled(10)};
            draw_text(dc, s, t, app.small, RGB(131, 153, 171), DT_RIGHT | DT_SINGLELINE);
            number_label(s, 128, xmin + (xmax - xmin) * i / 4);
            t = (RECT){xx - scaled(36), bottom + scaled(3), xx + scaled(36), bottom + scaled(23)};
            draw_text(dc, s, t, app.small, RGB(131, 153, 171), DT_CENTER | DT_SINGLELINE);
        }
        if (count) {
            int saved = SaveDC(dc);
            IntersectClipRect(dc, left, top, right + 1, bottom + 1);
            SelectObject(dc, curve);
            for (i = 0; i < count; i++) {
                int xx = left + (int)((x[i] - xmin) / (xmax - xmin) * (right - left)),
                    yy = bottom - (int)((y[i] - ymin) / (ymax - ymin) * (bottom - top));
                if (i)
                    LineTo(dc, xx, yy);
                else
                    MoveToEx(dc, xx, yy, NULL);
            }
            if (count == 1) {
                int xx = left + (right - left) / 2, yy = top + (bottom - top) / 2;
                Ellipse(dc, xx - 3, yy - 3, xx + 3, yy + 3);
            }
            RestoreDC(dc, saved);
        } else {
            RECT t = {left, top, right, bottom};
            draw_text(dc, L"读取数据后显示", t, app.font, RGB(160, 177, 190),
                      DT_CENTER | DT_VCENTER | DT_SINGLELINE);
        }
        RECT foot = {left, r.bottom - scaled(18), right, r.bottom};
        draw_text(dc,
                  p->spectrum    ? L"原始探测器列中心 / pixel  ·  信号 / count"
                  : wave         ? L"中心波长 / nm  ·  积分信号 / count"
                  : has_position ? L"测量/软件估计角度 / °  ·  积分信号 / count"
                                 : L"采样点  ·  积分信号 / count",
                  foot, app.small, RGB(126, 148, 166), DT_LEFT | DT_SINGLELINE);
        SelectObject(dc, old);
        DeleteObject(grid);
        DeleteObject(curve);
        EndPaint(h, &ps);
        return 0;
    }
    return DefWindowProcW(h, msg, wp, lp);
}
static void list_text(NMLVDISPINFOW *d) {
    VuvSample s;
    wchar_t value[128] = L"";
    int row = d->item.iItem;
    EnterCriticalSection(&app.engine.state_lock);
    if (row >= 0 && row < app.engine.sample_count)
        s = app.engine.samples[row];
    else {
        LeaveCriticalSection(&app.engine.state_lock);
        return;
    }
    LeaveCriticalSection(&app.engine.state_lock);
    switch (d->item.iSubItem) {
    case 0:
        swprintf(value, 128, L"%d", s.point);
        break;
    case 1:
        wcscpy(value, s.mode == VUV_CAMERA       ? L"独立相机"
                      : s.mode == VUV_CONTINUOUS ? L"连续扫描"
                                                 : L"点扫描");
        break;
    case 2:
        if (isfinite(s.position))
            swprintf(value, 128, L"%.7f", s.position);
        else
            wcscpy(value, L"—");
        break;
    case 3:
        if (isfinite(s.wavelength))
            swprintf(value, 128, L"%.7f", s.wavelength);
        else
            wcscpy(value, L"—");
        break;
    case 4:
        swprintf(value, 128, L"%.8g", s.intensity);
        break;
    case 5:
        if (isfinite(s.span))
            swprintf(value, 128, L"%.7f", s.span);
        else
            wcscpy(value, L"—");
        break;
    case 6:
        swprintf(value, 128, L"%.4f", s.actual_s);
        break;
    case 7:
        if (isfinite(s.delay_s))
            swprintf(value, 128, L"%+.4f", s.delay_s);
        else
            wcscpy(value, L"—");
        break;
    }
    if (d->item.pszText && d->item.cchTextMax) {
        wcsncpy(d->item.pszText, value, (size_t)d->item.cchTextMax - 1);
        d->item.pszText[d->item.cchTextMax - 1] = 0;
    }
}
static void save_settings(void) {
    cJSON *j = cJSON_CreateObject(), *fields = cJSON_CreateObject();
    int i;
    wchar_t value[VUV_PATH];
    for (i = 0; i < app.count; i++) {
        Control *c = &app.controls[i];
        if (!c->key)
            continue;
        if (c->type == 1) {
            GetWindowTextW(c->hwnd, value, VUV_PATH);
            char *u = native_utf8(value);
            if (u) {
                cJSON_AddStringToObject(fields, c->key, u);
                free(u);
            }
        } else if (c->type == 3)
            cJSON_AddBoolToObject(fields, c->key,
                                  SendMessageW(c->hwnd, BM_GETCHECK, 0, 0) == BST_CHECKED);
        else if (c->type == 4)
            cJSON_AddNumberToObject(fields, c->key, (int)SendMessageW(c->hwnd, CB_GETCURSEL, 0, 0));
    }
    cJSON_AddItemToObject(j, "fields", fields);
    cJSON_AddBoolToObject(j, "calibration_enabled", app.engine.calibration.enabled);
    char *u = cJSON_PrintUnformatted(j);
    if (u) {
        native_atomic_utf8(app.settings, u);
        cJSON_free(u);
    }
    cJSON_Delete(j);
}
static void load_settings(void) {
    FILE *f = _wfopen(app.settings, L"rb");
    char *buf;
    long n;
    cJSON *j, *fields, *v;
    wchar_t value[VUV_PATH];
    int i;
    if (!f)
        return;
    fseek(f, 0, SEEK_END);
    n = ftell(f);
    rewind(f);
    if (n <= 0 || n > 65536) {
        fclose(f);
        return;
    }
    buf = (char *)malloc((size_t)n + 1);
    if (!buf) {
        fclose(f);
        return;
    }
    size_t got = fread(buf, 1, (size_t)n, f);
    buf[got] = 0;
    fclose(f);
    j = cJSON_Parse(buf);
    free(buf);
    if (!j)
        return;
    fields = cJSON_GetObjectItemCaseSensitive(j, "fields");
    app.loading = 1;
    for (i = 0; i < app.count; i++) {
        Control *c = &app.controls[i];
        if (!c->key)
            continue;
        v = cJSON_GetObjectItemCaseSensitive(fields, c->key);
        if (c->type == 1 && cJSON_IsString(v)) {
            native_wide(v->valuestring, value, VUV_PATH);
            SetWindowTextW(c->hwnd, value);
        } else if (c->type == 3 && cJSON_IsBool(v))
            SendMessageW(c->hwnd, BM_SETCHECK, cJSON_IsTrue(v) ? BST_CHECKED : BST_UNCHECKED, 0);
        else if (c->type == 4 && cJSON_IsNumber(v) && v->valueint >= 0 &&
                 v->valueint < SendMessageW(c->hwnd, CB_GETCOUNT, 0, 0))
            SendMessageW(c->hwnd, CB_SETCURSEL, v->valueint, 0);
    }
    app.loading = 0; /* Real connections never restore. Calibration must be applied explicitly. */
    cJSON_Delete(j);
    app.cal_dirty = 0;
}
static int screenshot(HWND h, const wchar_t *path) {
    RECT r;
    GetWindowRect(h, &r);
    int w = r.right - r.left, hh = r.bottom - r.top;
    HDC screen = GetWindowDC(h), mem = CreateCompatibleDC(screen);
    HBITMAP bmp = CreateCompatibleBitmap(screen, w, hh), old = (HBITMAP)SelectObject(mem, bmp);
    RedrawWindow(h, NULL, NULL, RDW_UPDATENOW | RDW_ALLCHILDREN | RDW_INVALIDATE);
    BitBlt(mem, 0, 0, w, hh, screen, 0, 0, SRCCOPY);
    BITMAPINFO bi;
    BITMAPFILEHEADER bf;
    memset(&bi, 0, sizeof bi);
    bi.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
    bi.bmiHeader.biWidth = w;
    bi.bmiHeader.biHeight = hh;
    bi.bmiHeader.biPlanes = 1;
    bi.bmiHeader.biBitCount = 32;
    bi.bmiHeader.biCompression = BI_RGB;
    size_t bytes = (size_t)w * hh * 4;
    void *pixels = malloc(bytes);
    int ok = 0;
    SelectObject(mem, old);
    if (pixels && GetDIBits(screen, bmp, 0, (UINT)hh, pixels, &bi, DIB_RGB_COLORS)) {
        memset(&bf, 0, sizeof bf);
        bf.bfType = 0x4d42;
        bf.bfOffBits = sizeof bf + sizeof bi.bmiHeader;
        bf.bfSize = bf.bfOffBits + (DWORD)bytes;
        FILE *f = _wfopen(path, L"wb");
        if (f) {
            ok = fwrite(&bf, 1, sizeof bf, f) == sizeof bf &&
                 fwrite(&bi.bmiHeader, 1, sizeof bi.bmiHeader, f) == sizeof bi.bmiHeader &&
                 fwrite(pixels, 1, bytes, f) == bytes;
            fclose(f);
        }
    }
    free(pixels);
    SelectObject(mem, old);
    DeleteObject(bmp);
    DeleteDC(mem);
    ReleaseDC(h, screen);
    return ok;
}
static LRESULT CALLBACK main_proc(HWND h, UINT msg, WPARAM wp, LPARAM lp) {
    switch (msg) {
    case WM_CREATE:
        app.window = h;
        fonts();
        engine_create(&app.engine, h, app.data_dir);
        app.loading = 1;
        create_controls();
        app.loading = 0;
        if (!app.self_test)
            load_settings();
        SetTimer(h, 1, 600, NULL);
        SetTimer(h, 2, 180, NULL);
        refresh_ui();
        return 0;
    case WM_SIZE:
        layout();
        return 0;
    case WM_GETMINMAXINFO:
        ((MINMAXINFO *)lp)->ptMinTrackSize = (POINT){scaled(1180), scaled(800)};
        return 0;
    case WM_COMMAND: {
        int id = LOWORD(wp), code = HIWORD(wp);
        if (code == EN_CHANGE || code == CBN_SELCHANGE ||
            (code == BN_CLICKED &&
             (id == M_XON || id == C_STABLE || id == C_ROWMEAN || id == K_SIM))) {
            if (!app.loading) {
                engine_invalidate(&app.engine);
                if (id >= K_DEGREE && id <= K_SIM)
                    app.cal_dirty = 1;
                if ((id >= M_MODE && id <= M_MOVE_TIMEOUT) && app.engine.motor.connected)
                    app.motor_dirty = 1;
                if (id == P_MODE || id == C_READ)
                    refresh_ui();
            }
            return 0;
        }
        if (code == BN_CLICKED || code == 0)
            command(id);
        return 0;
    }
    case WM_NOTIFY: {
        NMHDR *n = (NMHDR *)lp;
        if (n->idFrom == ID_TABS && n->code == TCN_SELCHANGE) {
            app.page = TabCtrl_GetCurSel(app.tabs);
            layout();
            return 0;
        }
        if (n->idFrom == ID_LIST && n->code == LVN_GETDISPINFOW) {
            list_text((NMLVDISPINFOW *)lp);
            return 0;
        }
        return 0;
    }
    case WM_TIMER:
        if (wp == 1)
            engine_poll(&app.engine);
        else
            refresh_ui();
        return 0;
    case WM_VUV_UPDATE:
        InterlockedExchange(&app.engine.notify_pending, 0);
        refresh_ui();
        return 0;
    case WM_NATIVE_SCREENSHOT:
        return screenshot(h, (const wchar_t *)lp);
    case WM_NATIVE_TEST_DONE:
        app.test_result = (int)wp;
        if (!app.hold)
            SendMessageW(h, WM_CLOSE, 0, 0);
        return 0;
    case WM_CLOSE:
        if (!app.engine.exit_requested) {
            engine_exit(&app.engine);
            refresh_ui();
        }
        return 0;
    case WM_VUV_EXIT:
        save_settings();
        DestroyWindow(h);
        return 0;
    case WM_CTLCOLORSTATIC: {
        HDC dc = (HDC)wp;
        SetDCBrushColor(dc, RGB(242, 246, 250));
        SetBkColor(dc, RGB(242, 246, 250));
        SetTextColor(dc, RGB(55, 81, 103));
        return (LRESULT)GetStockObject(DC_BRUSH);
    }
    case WM_PAINT:
        paint_main(h);
        return 0;
    case WM_DESTROY:
        KillTimer(h, 1);
        KillTimer(h, 2);
        PostQuitMessage(app.test_result);
        return 0;
    }
    return DefWindowProcW(h, msg, wp, lp);
}
static HMENU menu_bar(void) {
    HMENU m = CreateMenu(), file = CreatePopupMenu(), help = CreatePopupMenu();
    AppendMenuW(file, MF_STRING, ID_EXPORT_MENU, L"导出当前光谱...");
    AppendMenuW(file, MF_STRING, ID_FOLDER_MENU, L"打开数据文件夹");
    AppendMenuW(file, MF_SEPARATOR, 0, NULL);
    AppendMenuW(file, MF_STRING, ID_EXIT, L"安全退出");
    AppendMenuW(help, MF_STRING, ID_ABOUT_MENU, L"关于原生 C 语言版");
    AppendMenuW(m, MF_POPUP, (UINT_PTR)file, L"文件");
    AppendMenuW(m, MF_POPUP, (UINT_PTR)help, L"帮助");
    return m;
}
#include "selftest.inc"
int WINAPI wWinMain(HINSTANCE instance, HINSTANCE previous, PWSTR commandline, int show) {
    (void)previous;
    (void)commandline;
    WNDCLASSEXW wc;
    MSG msg;
    INITCOMMONCONTROLSEX ic;
    HANDLE mutex;
    int argc, i;
    wchar_t **argv;
    memset(&app, 0, sizeof app);
    app.instance = instance;
    app.dpi = 96;
    SetProcessDPIAware();
    OleInitialize(NULL);
    ic.dwSize = sizeof ic;
    ic.dwICC = ICC_TAB_CLASSES | ICC_LISTVIEW_CLASSES | ICC_STANDARD_CLASSES;
    InitCommonControlsEx(&ic);
    if (!GetEnvironmentVariableW(L"LOCALAPPDATA", app.data_dir, VUV_PATH - 64))
        SHGetFolderPathW(NULL, CSIDL_LOCAL_APPDATA, NULL, SHGFP_TYPE_CURRENT, app.data_dir);
    wcscat(app.data_dir, L"\\Specreation\\VUVScanC");
    argv = CommandLineToArgvW(GetCommandLineW(), &argc);
    for (i = 1; i < argc; i++) {
        if (!wcscmp(argv[i], L"--self-test"))
            app.self_test = 1;
        else if (!wcscmp(argv[i], L"--hold"))
            app.hold = 1;
        else if (!wcscmp(argv[i], L"--data-dir") && i + 1 < argc) {
            wcsncpy(app.data_dir, argv[++i], VUV_PATH - 1);
            app.data_dir[VUV_PATH - 1] = 0;
        }
    }
    LocalFree(argv);
    native_mkdirs(app.data_dir);
    swprintf(app.settings, VUV_PATH, L"%ls\\settings.json", app.data_dir);
    mutex = CreateMutexW(NULL, FALSE,
                         app.self_test ? L"Local\\Specreation.VUVScanC.Test"
                                       : L"Local\\Specreation.VUVScanC");
    if (GetLastError() == ERROR_ALREADY_EXISTS && !app.self_test) {
        HWND existing = FindWindowW(L"VUVScanNative", NULL);
        if (existing) {
            ShowWindow(existing, SW_RESTORE);
            SetForegroundWindow(existing);
        }
        CloseHandle(mutex);
        return 0;
    }
    memset(&wc, 0, sizeof wc);
    wc.cbSize = sizeof wc;
    wc.hInstance = instance;
    wc.lpfnWndProc = plot_proc;
    wc.lpszClassName = L"VUVNativePlot";
    wc.hCursor = LoadCursorW(NULL, IDC_ARROW);
    RegisterClassExW(&wc);
    wc.lpfnWndProc = main_proc;
    wc.lpszClassName = L"VUVScanNative";
    wc.hIcon = LoadIconW(instance, MAKEINTRESOURCEW(101));
    wc.hIconSm =
        (HICON)LoadImageW(instance, MAKEINTRESOURCEW(101), IMAGE_ICON, 32, 32, LR_DEFAULTCOLOR);
    wc.hbrBackground = (HBRUSH)(COLOR_WINDOW + 1);
    RegisterClassExW(&wc);
    HWND window = CreateWindowExW(0, L"VUVScanNative", VUV_NAME L"  ·  C原生版 3.0.0",
                                  WS_OVERLAPPEDWINDOW, CW_USEDEFAULT, CW_USEDEFAULT, scaled(1560),
                                  scaled(1040), NULL, menu_bar(), instance, NULL);
    if (!window) {
        MessageBoxW(NULL, L"无法创建原生窗口", VUV_NAME, MB_ICONERROR);
        return 2;
    }
    ShowWindow(window, show);
    UpdateWindow(window);
    if (app.self_test) {
        HANDLE t = CreateThread(NULL, 0, selftest_thread, NULL, 0, NULL);
        if (t)
            CloseHandle(t);
    }
    while (GetMessageW(&msg, NULL, 0, 0) > 0) {
        if (!IsDialogMessageW(window, &msg)) {
            TranslateMessage(&msg);
            DispatchMessageW(&msg);
        }
    }
    CloseHandle(mutex);
    OleUninitialize();
    return (int)msg.wParam;
}
