#ifndef VUV_NATIVE_H
#define VUV_NATIVE_H
#ifndef UNICODE
#define UNICODE
#endif
#ifndef _UNICODE
#define _UNICODE
#endif
#define WIN32_LEAN_AND_MEAN
#define _WIN32_WINNT 0x0602
#include <windows.h>
#include <stdint.h>
#include <stdio.h>
#include "core.h"
#define VUV_NAME L"创谱科技-VUV质谱波长扫描软件"
#define VUV_PATH 1024
#define VUV_ERR 512
double native_now(void);
int native_wait(HANDLE cancel, double seconds);
void native_utc(char out[40]);
char *native_utf8(const wchar_t *s);
void native_wide(const char *s, wchar_t *out, size_t count);
int native_error(wchar_t *out, const wchar_t *fmt, ...);
int native_core_error(wchar_t *out, const char *s);
int native_mkdirs(const wchar_t *path);
int native_flush(FILE *f);
int native_atomic_utf8(const wchar_t *path, const char *text);
typedef struct {
    int simulated, baud, address, pp, xonxoff;
    wchar_t port[64];
    VuvLimits limits;
    double timeout_s, move_timeout_s;
} MotorConfig;
typedef struct {
    CRITICAL_SECTION io;
    HANDLE port;
    int connected, simulated, state, suffix;
    MotorConfig config;
    double position, velocity, lower, upper, origin, target, started;
    int moving, stops, commands;
    char version[128], positioner[128];
} Motor;
void motor_create(Motor *m);
int motor_connect(Motor *, const MotorConfig *, wchar_t *);
void motor_close(Motor *);
int motor_status(Motor *, int *, wchar_t *);
int motor_position(Motor *, double *, wchar_t *);
int motor_velocity(Motor *, double *, wchar_t *);
int motor_set_velocity(Motor *, double, wchar_t *);
int motor_start(Motor *, double, HANDLE, wchar_t *);
int motor_move(Motor *, double, HANDLE, wchar_t *);
int motor_home(Motor *, HANDLE, wchar_t *);
int motor_stop(Motor *, wchar_t *);
int motor_wait_ready(Motor *, double, int, HANDLE, double, wchar_t *);
int motor_ready(int state);
typedef unsigned int(WINAPI *SDK0)(void);
typedef unsigned int(WINAPI *SDKI)(int);
typedef unsigned int(WINAPI *SDKII)(int, int);
typedef unsigned int(WINAPI *SDKIP)(int *);
typedef unsigned int(WINAPI *SDKL)(LONG);
typedef struct {
    unsigned int(WINAPI *GetAvailableCameras)(LONG *);
    unsigned int(WINAPI *GetCameraHandle)(LONG, LONG *);
    SDKL SetCurrentCamera;
    unsigned int(WINAPI *Initialize)(char *);
    SDK0 ShutDown;
    unsigned int(WINAPI *GetDetector)(int *, int *);
    unsigned int(WINAPI *GetHeadModel)(char *);
    SDKIP GetCameraSerialNumber;
    unsigned int(WINAPI *GetTemperatureRange)(int *, int *);
    unsigned int(WINAPI *GetTemperatureF)(float *);
    SDKIP IsCoolerOn;
    SDKI SetTemperature;
    SDK0 CoolerON, CoolerOFF;
    SDKIP GetStatus;
    SDKI SetAcquisitionMode, SetTriggerMode, SetReadMode;
    unsigned int(WINAPI *SetExposureTime)(float);
    unsigned int(WINAPI *GetAcquisitionTimings)(float *, float *, float *);
    unsigned int(WINAPI *SetImage)(int, int, int, int, int, int);
    SDKI SetFVBHBin;
    SDKII SetSingleTrack;
    SDKI SetSingleTrackHBin;
    SDKIP GetNumberADChannels, GetNumberAmp;
    SDKI SetADChannel, SetOutputAmplifier;
    unsigned int(WINAPI *GetNumberHSSpeeds)(int, int, int *);
    unsigned int(WINAPI *GetHSSpeed)(int, int, int, float *);
    SDKII SetHSSpeed;
    SDKIP GetNumberPreAmpGains;
    unsigned int(WINAPI *GetPreAmpGain)(int, float *);
    unsigned int(WINAPI *IsPreAmpGainAvailable)(int, int, int, int, int *);
    SDKI SetPreAmpGain;
    SDKIP GetNumberVSSpeeds;
    unsigned int(WINAPI *GetVSSpeed)(int, float *);
    SDKI SetVSSpeed;
    unsigned int(WINAPI *GetFastestRecommendedVSSpeed)(int *, float *);
    unsigned int(WINAPI *SetShutter)(int, int, int, int);
    SDK0 PrepareAcquisition, StartAcquisition, AbortAcquisition;
    unsigned int(WINAPI *GetAcquiredData)(LONG *, DWORD);
} AndorSDK;
typedef struct {
    CRITICAL_SECTION io;
    HMODULE dll;
    AndorSDK sdk;
    int connected, initialized, simulated, cooler_on, temp_stable;
    int width, height, serial, temp_min, temp_max, ad_count, amp_count, hs_count, vs_count,
        gain_count;
    double temperature, target, temperature_at, actual_exposure, actual_cycle, hs_mhz, vs_us, gain;
    char model[128];
    VuvCameraConfig config;
    VuvShape shape;
    int configured;
    double frame_start, frame_mid, frame_end;
    uint32_t rng;
    wchar_t dll_path[VUV_PATH];
} Camera;
void camera_create(Camera *);
int camera_connect(Camera *, int, const wchar_t *, int, wchar_t *);
int camera_temperature(Camera *, wchar_t *);
int camera_cooler(Camera *, int, int, wchar_t *);
int camera_close(Camera *, wchar_t *); /* Returns 0 while below safe temperature. */
int camera_configure(Camera *, const VuvCameraConfig *, wchar_t *);
int camera_acquire(Camera *, Motor *, HANDLE, int32_t *, wchar_t *);
int camera_abort(Camera *, wchar_t *);
#endif
