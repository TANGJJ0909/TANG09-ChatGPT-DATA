#include "native.h"
#include <wchar.h>
#include <stdarg.h>
#include <stdlib.h>
#include <string.h>
#include <io.h>
#include <math.h>
double native_now(void) {
    LARGE_INTEGER f, t;
    QueryPerformanceFrequency(&f);
    QueryPerformanceCounter(&t);
    return (double)t.QuadPart / f.QuadPart;
}
int native_wait(HANDLE cancel, double seconds) {
    double until = native_now() + seconds;
    for (;;) {
        double left = until - native_now();
        DWORD ms;
        if (cancel && WaitForSingleObject(cancel, 0) == WAIT_OBJECT_0)
            return 0;
        if (left <= 0)
            return 1;
        ms = (DWORD)fmax(1, fmin(50, ceil(left * 1000)));
        if (cancel) {
            if (WaitForSingleObject(cancel, ms) == WAIT_OBJECT_0)
                return 0;
        } else
            Sleep(ms);
    }
}
void native_utc(char out[40]) {
    SYSTEMTIME s;
    GetSystemTime(&s);
    snprintf(out, 40, "%04u-%02u-%02uT%02u:%02u:%02u.%03uZ", s.wYear, s.wMonth, s.wDay, s.wHour,
             s.wMinute, s.wSecond, s.wMilliseconds);
}
char *native_utf8(const wchar_t *s) {
    int n = WideCharToMultiByte(CP_UTF8, 0, s, -1, NULL, 0, NULL, NULL);
    char *out;
    if (n <= 0)
        return NULL;
    out = (char *)malloc((size_t)n);
    if (out)
        WideCharToMultiByte(CP_UTF8, 0, s, -1, out, n, NULL, NULL);
    return out;
}
void native_wide(const char *s, wchar_t *out, size_t count) {
    if (!count)
        return;
    out[0] = 0;
    if (s)
        MultiByteToWideChar(CP_UTF8, 0, s, -1, out, (int)count);
    out[count - 1] = 0;
}
int native_error(wchar_t *out, const wchar_t *fmt, ...) {
    va_list a;
    va_start(a, fmt);
    if (out) {
        _vsnwprintf(out, VUV_ERR - 1, fmt, a);
        out[VUV_ERR - 1] = 0;
    }
    va_end(a);
    return 0;
}
int native_core_error(wchar_t *out, const char *s) {
    native_wide(s, out, VUV_ERR);
    return 0;
}
int native_mkdirs(const wchar_t *path) {
    wchar_t copy[VUV_PATH];
    size_t i, len = wcslen(path);
    if (len >= VUV_PATH)
        return 0;
    wcscpy(copy, path);
    for (i = 3; i < len; i++)
        if (copy[i] == L'\\' || copy[i] == L'/') {
            wchar_t ch = copy[i];
            copy[i] = 0;
            if (!CreateDirectoryW(copy, NULL) && GetLastError() != ERROR_ALREADY_EXISTS)
                return 0;
            copy[i] = ch;
        }
    return CreateDirectoryW(copy, NULL) || GetLastError() == ERROR_ALREADY_EXISTS;
}
int native_flush(FILE *f) {
    return f && fflush(f) == 0 && _commit(_fileno(f)) == 0;
}
int native_atomic_utf8(const wchar_t *path, const char *text) {
    wchar_t tmp[VUV_PATH];
    FILE *f;
    size_t len = strlen(text);
    int ok;
    if (wcslen(path) + 5 >= VUV_PATH)
        return 0;
    swprintf(tmp, VUV_PATH, L"%ls.tmp", path);
    f = _wfopen(tmp, L"wb");
    if (!f)
        return 0;
    ok = fwrite(text, 1, len, f) == len && native_flush(f);
    if (fclose(f))
        ok = 0;
    if (!ok) {
        DeleteFileW(tmp);
        return 0;
    }
    return MoveFileExW(tmp, path, MOVEFILE_REPLACE_EXISTING | MOVEFILE_WRITE_THROUGH) != 0;
}
