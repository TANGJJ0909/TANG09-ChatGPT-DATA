/* Native-control integration tests. Only runs with --self-test. No hardware is used. */
static cJSON *test_cases;
static int test_failed;
static void test_check(const char *name, int passed) {
    cJSON *j = cJSON_CreateObject();
    cJSON_AddStringToObject(j, "case", name);
    cJSON_AddBoolToObject(j, "passed", passed);
    cJSON_AddItemToArray(test_cases, j);
    if (!passed)
        test_failed++;
}
static int test_idle(DWORD timeout) {
    double until = native_now() + timeout / 1000.;
    do {
        if (!app.engine.busy && !app.engine.stopping)
            return 1;
        Sleep(20);
    } while (native_now() < until);
    return 0;
}
static UiState test_state(void) {
    UiState s;
    engine_snapshot(&app.engine, &s);
    return s;
}
static int test_click(int id) {
    SendMessageW(app.window, WM_COMMAND, MAKEWPARAM(id, BN_CLICKED), (LPARAM)ctrl(id));
    Sleep(30);
    return test_idle(30000);
}
static void test_select(int id, int index) {
    SendMessageW(ctrl(id), CB_SETCURSEL, index, 0);
    SendMessageW(app.window, WM_COMMAND, MAKEWPARAM(id, CBN_SELCHANGE), (LPARAM)ctrl(id));
}
static int test_run(int points) {
    if (!test_click(P_INITIALIZE) || test_state().phase != PH_INITIALIZED)
        return 0;
    return test_click(P_RUN) && test_state().phase == PH_COMPLETE &&
           test_state().completed == points;
}
static int test_file(const wchar_t *directory, const wchar_t *name) {
    wchar_t p[VUV_PATH];
    swprintf(p, VUV_PATH, L"%ls\\%ls", directory, name);
    return GetFileAttributesW(p) != INVALID_FILE_ATTRIBUTES;
}
static DWORD WINAPI selftest_thread(void *unused) {
    wchar_t p[VUV_PATH], err[VUV_ERR];
    UiState s;
    int i, commands, stops;
    double speed;
    char *report;
    (void)unused;
    test_cases = cJSON_CreateArray();
    Sleep(300);
    test_check("native controls and embedded icon",
               ctrl(M_CONNECT) && ctrl(C_CONNECT) && app.plots[0] &&
                   LoadIconW(app.instance, MAKEINTRESOURCEW(101)));
    text(M_VELOCITY, L"2");
    text(M_ABS, L"0.2");
    test_check("motor connects without camera", test_click(M_CONNECT) &&
                                                    test_state().motor_connected &&
                                                    !test_state().camera_connected);
    test_check("independent absolute motion",
               test_click(M_GO) && fabs(test_state().position - .2) < .001);
    test_check("independent relative motion",
               test_click(M_PLUS) && fabs(test_state().position - .3) < .001);
    test_check("motor disconnect", test_click(M_DISCONNECT) && !test_state().motor_connected);
    test_check("camera connects without motor", test_click(C_CONNECT) &&
                                                    test_state().camera_connected &&
                                                    !test_state().motor_connected);
    text(C_EXP, L"1");
    text(C_FRAMES, L"2");
    test_select(C_READ, 2);
    text(C_X1, L"64");
    text(C_Y1, L"32");
    text(C_HBIN, L"2");
    text(C_VBIN, L"2");
    test_check("camera parameter apply and binned image",
               test_click(C_APPLY) && test_state().rows == 16 && test_state().cols == 32);
    text(P_START, L""); /* Unrelated invalid scan fields must not block standalone capture. */
    test_check("standalone camera read", test_click(C_READ_NOW) &&
                                             test_state().phase == PH_COMPLETE &&
                                             test_state().completed == 1);
    s = test_state();
    test_check("standalone raw frames and CSV",
               test_file(s.last_run, L"raw\\point_000001_frame_002.npy") &&
                   test_file(s.last_run, L"scan_points.csv"));
    EnterCriticalSection(&app.engine.state_lock);
    int unavailable = app.engine.sample_count == 1 && !isfinite(app.engine.samples[0].position);
    LeaveCriticalSection(&app.engine.state_lock);
    test_check("camera without motor has no fabricated position", unavailable);
    swprintf(p, VUV_PATH, L"%ls\\export_test.csv", app.data_dir);
    test_check("native CSV export", engine_export(&app.engine, p, err));
    test_check("connect motor while camera connected", test_click(M_CONNECT) &&
                                                           test_state().motor_connected &&
                                                           test_state().camera_connected);
    test_check("camera disconnect preserves motor", test_click(C_DISCONNECT) &&
                                                        test_state().motor_connected &&
                                                        !test_state().camera_connected);
    test_check("camera reconnect", test_click(C_CONNECT) && test_state().camera_connected);
    test_select(C_READ, 0);
    text(C_HBIN, L"1");
    text(C_FRAMES, L"1");
    text(P_SETTLE, L"0");
    text(P_START, L"-0.1");
    text(P_STEP, L"0.1");
    text(P_POINTS, L"3");
    text(P_PROJECT, L"原生点扫描测试");
    test_check("point scan initialize and acquisition", test_run(3));
    EnterCriticalSection(&app.engine.state_lock);
    int point_ok = app.engine.sample_count == 3;
    for (i = 0; point_ok && i < 3; i++)
        point_ok = fabs(app.engine.samples[i].position - (-.1 + i * .1)) < .001;
    LeaveCriticalSection(&app.engine.state_lock);
    test_check("point scan measures stationary positions", point_ok);
    s = test_state();
    test_check("point scan full raw output",
               test_file(s.last_run, L"raw\\point_000003_frame_001.npy") &&
                   test_file(s.last_run, L"spectra.csv") &&
                   test_file(s.last_run, L"manifest.json"));
    test_select(P_MODE, 1);
    text(P_START, L"0");
    text(P_POINTS, L"5");
    text(P_VELOCITY, L"0.1");
    text(P_PERIOD, L"0.25");
    text(P_LEAD, L"0.15");
    text(P_PROJECT, L"原生连续扫描测试");
    int initialized = test_click(P_INITIALIZE) && test_state().phase == PH_INITIALIZED;
    commands = app.engine.motor.commands;
    stops = app.engine.motor.stops;
    speed = app.engine.motor.velocity;
    test_check("continuous scan", initialized && test_click(P_RUN) &&
                                      test_state().phase == PH_COMPLETE &&
                                      test_state().completed == 5);
    test_check("continuous single movement and final stop",
               app.engine.motor.commands == commands + 1 && app.engine.motor.stops == stops + 1);
    test_check("continuous restores original velocity",
               fabs(app.engine.motor.velocity - speed) < 1e-10);
    EnterCriticalSection(&app.engine.state_lock);
    int monotonic = app.engine.sample_count == 5;
    for (i = 1; monotonic && i < 5; i++)
        monotonic = app.engine.samples[i].position > app.engine.samples[i - 1].position;
    LeaveCriticalSection(&app.engine.state_lock);
    test_check("continuous position estimates progress", monotonic);
    text(C_EXP, L"500");
    text(P_PERIOD, L"0.9");
    text(P_POINTS, L"10");
    text(P_START, L"0");
    initialized = test_click(P_INITIALIZE) && test_state().phase == PH_INITIALIZED;
    if (initialized) {
        SendMessageW(app.window, WM_COMMAND, MAKEWPARAM(P_RUN, BN_CLICKED), (LPARAM)ctrl(P_RUN));
        Sleep(350);
        SendMessageW(app.window, WM_COMMAND, MAKEWPARAM(ID_STOP, BN_CLICKED),
                     (LPARAM)ctrl(ID_STOP));
    }
    test_check("stop interrupts continuous exposure",
               initialized && test_idle(12000) && test_state().phase == PH_STOPPED &&
                   test_state().completed < 10 && motor_ready(app.engine.motor.state));
    text(C_EXP, L"20");
    text(P_START, L"-0.9");
    text(P_VELOCITY, L"0.35");
    text(P_PERIOD, L"0.18");
    text(P_POINTS, L"31");
    text(P_PROJECT, L"原生桌面演示");
    test_check("final native preview run", test_run(31));
    TabCtrl_SetCurSel(app.tabs, 2);
    NMHDR note = {app.tabs, ID_TABS, TCN_SELCHANGE};
    SendMessageW(app.window, WM_NOTIFY, ID_TABS, (LPARAM)&note);
    Sleep(200);
    swprintf(p, VUV_PATH, L"%ls\\native-ui.bmp", app.data_dir);
    test_check("native GDI screenshot",
               (int)SendMessageW(app.window, WM_NATIVE_SCREENSHOT, 0, (LPARAM)p));
    cJSON *j = cJSON_CreateObject();
    cJSON_AddStringToObject(j, "implementation", "C11 / native Win32 GUI");
    cJSON_AddStringToObject(j, "execution_environment", "Wine on Linux, simulated devices");
    cJSON_AddBoolToObject(j, "physical_hardware_tested", 0);
    cJSON_AddBoolToObject(j, "browser_runtime", 0);
    cJSON_AddNumberToObject(j, "failed", test_failed);
    cJSON_AddItemToObject(j, "cases", test_cases);
    EnterCriticalSection(&app.engine.state_lock);
    cJSON *logs = cJSON_CreateArray();
    for (i = 0; i < app.engine.log_count; i++) {
        char *u = native_utf8(app.engine.logs[i]);
        cJSON_AddItemToArray(logs, cJSON_CreateString(u ? u : ""));
        free(u);
    }
    LeaveCriticalSection(&app.engine.state_lock);
    cJSON_AddItemToObject(j, "log", logs);
    report = cJSON_Print(j);
    swprintf(p, VUV_PATH, L"%ls\\selftest_report.json", app.data_dir);
    if (report) {
        native_atomic_utf8(p, report);
        cJSON_free(report);
    }
    cJSON_Delete(j);
    PostMessageW(app.window, WM_NATIVE_TEST_DONE, test_failed ? 1 : 0, 0);
    return 0;
}
