# 开发验证

这些测试程序、Python 脚本与测试 DLL 都不参与成品运行。`mock_sdk2.c` 是本工程的接口桩，不是厂家 SDK，也不应放到真实设备的 SDK 路径中。

## 便携 C 计算

在工程根目录先创建 build，再运行：

```sh
gcc -std=c11 -g -O1 -Wall -Wextra -Werror -fsanitize=address,undefined \
  -Isrc -Ithird_party/cjson tests/test_core.c src/core.c third_party/cjson/cJSON.c \
  -lm -o build/test_core
./build/test_core
```

## 原生窗口和保存数据

在 Windows 桌面，或已配置字体和 X server 的 Wine 中运行：

```text
Specreation_VUV_Scan_C.exe --self-test --data-dir C:\VUVNativeTest
```

仅显式 `--self-test` 启用模拟自动操作；不连接真实设备。产物包括 `selftest_report.json`、`native-ui.bmp` 和 scans 数据目录。返回值 0 表示全部界面检查通过。`--hold` 可在测试结束后保留窗口。开发电脑安装 NumPy 后，可使用 `python tests/check_saved_data.py <测试数据目录>` 核对帧与 CSV。

## SDK2 ABI 与串口

以 x64 C 编译器把 `mock_sdk2.c` 编为 DLL，把 `test_sdk2.c` 与 `devices.c`、`platform.c`、`core.c`、`cJSON.c` 编为控制台程序（Unicode wmain 入口需 `-municode`）。调用 `test_sdk2.exe <测试DLL完整路径>`。DLL 放到兼容当前 ANSI 编码的目录，例如 `C:\VUVTest\mock_sdk2.dll`。

`test_motor_serial.c` 编译方式相同，使用普通 main 入口。它只用于 PTY 协议桩中的 COM9。Linux/Wine 验证使用 `run_serial_fixture.py <wine路径> <测试EXE路径>`，需设置 WINEPREFIX、DISPLAY 等变量。脚本仅映射临时 PTY，测试后清除 COM9 链接；不要对真实设备运行该测试程序。

接口桩验证 ABI、协议和主机侧处理，不证明真实 SDK 版本、驱动、物理时序或机械性能。
