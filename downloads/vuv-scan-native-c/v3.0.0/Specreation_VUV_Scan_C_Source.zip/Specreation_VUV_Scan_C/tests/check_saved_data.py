"""Build-time verification only. Python is not a software runtime dependency."""
import csv
import json
import sys
from pathlib import Path
import numpy as np

root = Path(sys.argv[1])
report = json.loads((root / "selftest_report.json").read_text())
assert report["failed"] == 0, [x for x in report["cases"] if not x["passed"]]
manifests = list((root / "scans").glob("*/manifest.json"))
assert len(manifests) >= 5
counts = dict(points=0, raw_frames=0, runs=len(manifests))
stopped = False
for path in manifests:
    meta = json.loads(path.read_text())
    assert meta["implementation"] == "C11 / native Win32"
    assert meta["camera_source"] == "simulation"
    with (path.parent / "scan_points.csv").open(encoding="utf-8-sig", newline="") as f:
        points = list(csv.DictReader(f))
    with (path.parent / "spectra.csv").open(encoding="utf-8-sig", newline="") as f:
        spectra = list(csv.reader(f))
    assert len(points) == meta["completed_points"] == len(spectra) - 1
    for record, spectrum in zip(points, spectra[1:]):
        n = int(record["point"])
        frames = [np.load(path.parent / "raw" / f"point_{n:06d}_frame_{i:03d}.npy") for i in range(1, int(record["frames"]) + 1)]
        assert all(x.dtype == np.dtype("<i4") and x.ndim == 2 for x in frames)
        reduced = [x.mean(axis=0) if meta["camera"]["row_mean"] else x.sum(axis=0) for x in frames]
        average = np.mean(reduced, axis=0)
        np.testing.assert_allclose(np.asarray(spectrum[3:], float), average, rtol=1e-13, atol=1e-10)
        lo = meta["plan"]["signal_first_column"]
        hi = meta["plan"]["signal_last_column"]
        hi = len(average) - 1 if hi == -1 else hi
        np.testing.assert_allclose(float(record["integrated_counts"]), average[lo:hi+1].sum(), rtol=1e-13)
        assert not record["center_wavelength_nm"]  # no fabricated wavelength without calibration
        if meta["mode"] == "point":
            assert abs(float(record["position_deg"]) - float(record["target_deg"])) <= .001
        if meta["mode"] == "camera":
            assert not record["position_deg"]
        counts["points"] += 1
        counts["raw_frames"] += len(frames)
    if meta["mode"] == "continuous" and meta["status"] == "completed":
        assert meta["original_velocity_restored"]
        assert all(float(a["position_deg"]) < float(b["position_deg"]) for a, b in zip(points, points[1:]))
    if meta["status"] == "stopped":
        stopped = True
        assert len(points) < meta["plan"]["points"]
    events = [json.loads(x) for x in (path.parent / "events.jsonl").read_text().splitlines()]
    brackets = [x for x in events if x["event"] == "position_bracket"]
    for event in brackets:
        assert event["query_before_host_s"] <= event["exposure_mid_estimate_host_s"] <= event["query_after_host_s"]
assert stopped
print("Saved-data consistency:", counts)
