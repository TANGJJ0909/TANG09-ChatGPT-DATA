/* Test fixture: not a vendor SDK, not shipped with the application. */
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <string.h>
#define API __declspec(dllexport) unsigned int WINAPI
#define OK 20002u
static int mode, hb = 1, vb = 1, xs = 1, xe = 64, ys = 1, ye = 32, acquiring, cooler, shut;
static float exposure = .001f, temperature = 20;
API GetAvailableCameras(LONG *n) {
    *n = 1;
    return OK;
}
API GetCameraHandle(LONG n, LONG *h) {
    if (n)
        return 20066;
    *h = 940;
    return OK;
}
API SetCurrentCamera(LONG h) {
    return h == 940 ? OK : 20066;
}
API Initialize(char *dir) {
    (void)dir;
    shut = 0;
    return OK;
}
API ShutDown(void) {
    shut++;
    return OK;
}
API GetDetector(int *w, int *h) {
    *w = 64;
    *h = 32;
    return OK;
}
API GetHeadModel(char *s) {
    strcpy(s, "SDK2 ABI TEST FIXTURE");
    return OK;
}
API GetCameraSerialNumber(int *s) {
    *s = 123456;
    return OK;
}
API GetTemperatureRange(int *lo, int *hi) {
    *lo = -100;
    *hi = 20;
    return OK;
}
API GetTemperatureF(float *t) {
    *t = temperature;
    return cooler ? 20036 : 20034;
}
API IsCoolerOn(int *on) {
    *on = cooler;
    return OK;
}
API SetTemperature(int t) {
    temperature = (float)t;
    return OK;
}
API CoolerON(void) {
    cooler = 1;
    return OK;
}
API CoolerOFF(void) {
    cooler = 0;
    return OK;
}
API GetStatus(int *s) {
    *s = acquiring ? 20072 : 20073;
    acquiring = 0;
    return OK;
}
API SetAcquisitionMode(int x) {
    return x == 1 ? OK : 20066;
}
API SetTriggerMode(int x) {
    return x == 0 ? OK : 20066;
}
API SetReadMode(int x) {
    mode = x;
    return OK;
}
API SetExposureTime(float x) {
    exposure = x;
    return OK;
}
API GetAcquisitionTimings(float *a, float *b, float *c) {
    *a = exposure;
    *b = exposure;
    *c = exposure + .02f;
    return OK;
}
API SetImage(int h, int v, int a, int b, int c, int d) {
    hb = h;
    vb = v;
    xs = a;
    xe = b;
    ys = c;
    ye = d;
    return OK;
}
API SetFVBHBin(int h) {
    hb = h;
    return OK;
}
API SetSingleTrack(int c, int h) {
    (void)c;
    (void)h;
    return OK;
}
API SetSingleTrackHBin(int h) {
    hb = h;
    return OK;
}
API GetNumberADChannels(int *n) {
    *n = 2;
    return OK;
}
API GetNumberAmp(int *n) {
    *n = 2;
    return OK;
}
API SetADChannel(int n) {
    return n < 2 ? OK : 20066;
}
API SetOutputAmplifier(int n) {
    return n < 2 ? OK : 20066;
}
API GetNumberHSSpeeds(int a, int b, int *n) {
    (void)a;
    (void)b;
    *n = 2;
    return OK;
}
API GetHSSpeed(int a, int b, int i, float *v) {
    (void)a;
    (void)b;
    *v = (float)(i + 1);
    return OK;
}
API SetHSSpeed(int a, int b) {
    (void)a;
    (void)b;
    return OK;
}
API GetNumberPreAmpGains(int *n) {
    *n = 2;
    return OK;
}
API GetPreAmpGain(int i, float *g) {
    *g = (float)(i + 1);
    return OK;
}
API IsPreAmpGainAvailable(int a, int b, int c, int d, int *yes) {
    (void)a;
    (void)b;
    (void)c;
    *yes = d < 2;
    return OK;
}
API SetPreAmpGain(int n) {
    return n < 2 ? OK : 20066;
}
API GetNumberVSSpeeds(int *n) {
    *n = 2;
    return OK;
}
API GetVSSpeed(int i, float *v) {
    *v = (float)(i + 2);
    return OK;
}
API SetVSSpeed(int i) {
    return i < 2 ? OK : 20066;
}
API GetFastestRecommendedVSSpeed(int *i, float *v) {
    *i = 1;
    *v = 3;
    return OK;
}
API SetShutter(int t, int m, int c, int o) {
    (void)t;
    (void)m;
    (void)c;
    (void)o;
    return OK;
}
API PrepareAcquisition(void) {
    return OK;
}
API StartAcquisition(void) {
    acquiring = 1;
    return OK;
}
API AbortAcquisition(void) {
    acquiring = 0;
    return OK;
}
API GetAcquiredData(LONG *p, DWORD n) {
    DWORD expected = (DWORD)(mode == 4 ? ((xe - xs + 1) / hb) * ((ye - ys + 1) / vb) : 64 / hb), i;
    if (n != expected)
        return 20066;
    for (i = 0; i < n; i++)
        p[i] = (LONG)i - 100;
    return OK;
}
API TestSetTemperature(int t) {
    temperature = (float)t;
    return OK;
}
API TestShutdownCount(void) {
    return (unsigned)shut;
}
