"""Exercise Win32 serial APIs through Wine and a Unix PTY, not physical hardware."""
import json, os, pty, select, subprocess, sys, termios, threading, time
from pathlib import Path

prefix = Path(os.environ["WINEPREFIX"])
master, slave = pty.openpty()
attrs = termios.tcgetattr(slave)
attrs[3] &= ~(termios.ECHO | termios.ICANON)
termios.tcsetattr(slave, termios.TCSANOW, attrs)
com = prefix / "dosdevices/com9"
if com.is_symlink():
    com.unlink()
com.symlink_to(os.ttyname(slave))
commands=[]
pos=target=0.0
speed=.5
last=time.monotonic()
moving=False
stop=threading.Event()

def fixture():
    global pos,target,speed,last,moving
    buf=b""
    while not stop.is_set():
        if not select.select([master],[],[],.05)[0]:
            continue
        buf += os.read(master,1024)
        while b"\n" in buf:
            data,buf=buf.split(b"\n",1)
            cmd=data.decode("ascii",errors="ignore").strip()
            if not cmd: continue
            commands.append(cmd)
            now=time.monotonic()
            if moving:
                travel=speed*(now-last)
                delta=target-pos
                if abs(delta)<=travel: pos=target;moving=False
                else: pos += travel if delta>0 else -travel
            last=now
            name,arg=cmd[1:3],cmd[3:]
            if name in {"TS","TP","VE","TE"} and arg=="?":
                continue  # old-firmware bare read syntax, forces read-only fallback
            reply=None
            if name=="TS": reply="000028" if moving else "000033"
            elif name=="TP": reply=f"{pos:.9f}"
            elif name=="VE": reply="SMC100CC fixture"
            elif name=="TE": reply="@"
            elif name=="ID": reply="URS configured fixture"
            elif name=="SL": reply="-2"
            elif name=="SR": reply="2"
            elif name=="VA":
                if arg=="?": reply=f"{speed:.9f}"
                else: speed=float(arg)
            elif name=="PA": target=float(arg);moving=True
            elif name=="ST": moving=False
            if reply is not None:
                # Include command echo and an unrelated axis before the expected reply.
                os.write(master,(cmd+"\r\n2"+name+"999\r\n1"+name+reply+"\r\n").encode())

t=threading.Thread(target=fixture,daemon=True)
t.start()
try:
    result=subprocess.run([sys.argv[1],sys.argv[2]],timeout=40,capture_output=True)
    print(result.stdout.decode(errors="replace"),end="")
    print(result.stderr.decode(errors="replace"),end="",file=sys.stderr)
    Path("build/serial-commands.json").write_text(json.dumps(commands,indent=2))
    assert result.returncode==0, result.returncode
    assert len([x for x in commands if x.startswith("1PA")])==2
    assert not any(x.startswith(("1RS","1PW","1OR")) for x in commands)
finally:
    stop.set();t.join(timeout=1)
    com.unlink(missing_ok=True)
    os.close(master);os.close(slave)
