#include "core.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
static int checks, failures;
#define CHECK(expr)                                                                                \
    do {                                                                                           \
        checks++;                                                                                  \
        if (!(expr)) {                                                                             \
            failures++;                                                                            \
            fprintf(stderr, "FAIL line %d: %s\n", __LINE__, #expr);                                \
        }                                                                                          \
    } while (0)
int main(void) {
    char error[512];
    VuvCameraConfig camera = vuv_camera_defaults();
    VuvPlan plan = vuv_plan_defaults();
    VuvCalibration calibration = {0};
    VuvLimits limits = {-5, 5, -180, 180, .001};
    VuvShape shape;
    VuvResolved resolved;
    double angle, work[3], average[3], negative[] = {-10, -5, 2};
    int lo, hi, i;
    int32_t raw1[] = {-2, 4, 6, 0, 8, 10}, raw2[] = {2, 8, 10, 4, 12, 14};
    CHECK(vuv_shape(&camera, 2048, 512, &shape, error, sizeof error));
    CHECK(shape.cols == 2048 && shape.rows == 1 && shape.pixels == 2048);
    camera.read_mode = 4;
    camera.x1 = 64;
    camera.y1 = 32;
    camera.hbin = 2;
    camera.vbin = 2;
    CHECK(vuv_shape(&camera, 2048, 512, &shape, error, sizeof error));
    CHECK(shape.cols == 32 && shape.rows == 16 && shape.first_pixel == .5);
    camera.x0 = 2;
    CHECK(!vuv_shape(&camera, 2048, 512, &shape, error, sizeof error));
    camera.x0 = 1;
    camera.y1 = 513;
    CHECK(!vuv_shape(&camera, 2048, 512, &shape, error, sizeof error));
    camera.y1 = 32;
    camera.read_mode = 3;
    camera.track_center = 1;
    CHECK(!vuv_shape(&camera, 2048, 512, &shape, error, sizeof error));
    camera.track_center = 256;
    CHECK(vuv_shape(&camera, 2048, 512, &shape, error, sizeof error));
    camera = vuv_camera_defaults();
    camera.frames = 0;
    CHECK(!vuv_shape(&camera, 2048, 512, &shape, error, sizeof error));
    camera = vuv_camera_defaults();
    CHECK(!vuv_cal_inverse(&calibration, 100, &angle, error, sizeof error));
    CHECK(
        vuv_cal_json("{\"coefficients\":[150,4,0.02,0.0001],\"angle_min\":-5,\"angle_max\":5,"
                     "\"angle_unit\":\"deg\",\"wavelength_unit\":\"nm\",\"simulation_only\":true}",
                     &calibration, error, sizeof error));
    for (i = 0; i < 1001; i++) {
        double x = -5 + i * .01;
        CHECK(vuv_cal_inverse(&calibration, vuv_cal_eval(&calibration, x), &angle, error,
                              sizeof error) &&
              fabs(angle - x) < 1e-10);
    }
    CHECK(!vuv_cal_inverse(&calibration, 10, &angle, error, sizeof error));
    calibration.a[1] = -4;
    CHECK(vuv_cal_validate(&calibration, error, sizeof error));
    CHECK(vuv_cal_inverse(&calibration, vuv_cal_eval(&calibration, 2.3), &angle, error,
                          sizeof error) &&
          fabs(angle - 2.3) < 1e-10);
    calibration.a[1] = -1;
    calibration.a[2] = 0;
    calibration.a[3] = 1;
    CHECK(!vuv_cal_validate(&calibration, error, sizeof error)); /* interior derivative reversal */
    calibration.a[1] = 0;
    calibration.a[3] = 1;
    CHECK(!vuv_cal_validate(&calibration, error, sizeof error)); /* interior zero derivative */
    CHECK(!vuv_cal_json(
        "{\"coefficients\":[150,4],\"angle_min\":-5,\"angle_max\":5,\"wavelength_unit\":\"m\"}",
        &calibration, error, sizeof error));
    CHECK(!vuv_cal_json("{\"coefficients\":[150,\"4\"],\"angle_min\":-5,\"angle_max\":5}",
                        &calibration, error, sizeof error));
    memset(&calibration, 0, sizeof calibration);
    CHECK(vuv_plan_resolve(&plan, &camera, &calibration, &limits, 1, .11, .01, 8192, &resolved,
                           error, sizeof error));
    CHECK(resolved.start_angle == 0 && fabs(resolved.last_angle - 2) < 1e-12);
    plan.start = 4;
    CHECK(!vuv_plan_resolve(&plan, &camera, &calibration, &limits, 1, .11, .01, 8192, &resolved,
                            error, sizeof error));
    plan = vuv_plan_defaults();
    plan.step = -.1;
    CHECK(vuv_plan_resolve(&plan, &camera, &calibration, &limits, 1, .11, .01, 8192, &resolved,
                           error, sizeof error));
    CHECK(fabs(resolved.last_angle + 2) < 1e-12);
    plan.step = 0;
    CHECK(!vuv_plan_resolve(&plan, &camera, &calibration, &limits, 1, .11, .01, 8192, &resolved,
                            error, sizeof error));
    plan.points = 1;
    CHECK(vuv_plan_resolve(&plan, &camera, &calibration, &limits, 1, .11, .01, 8192, &resolved,
                           error, sizeof error));
    plan = vuv_plan_defaults();
    plan.mode = VUV_CONTINUOUS;
    CHECK(vuv_plan_resolve(&plan, &camera, &calibration, &limits, 1, .11, .01, 8192, &resolved,
                           error, sizeof error));
    CHECK(resolved.guard_angle > 1 && resolved.min_period_s > .18);
    plan.period_s = .05;
    CHECK(!vuv_plan_resolve(&plan, &camera, &calibration, &limits, 1, .11, .01, 8192, &resolved,
                            error, sizeof error));
    plan.period_s = .5;
    plan.velocity = 2;
    CHECK(!vuv_plan_resolve(&plan, &camera, &calibration, &limits, 1, .11, .01, 8192, &resolved,
                            error, sizeof error));
    plan.velocity = -.1;
    CHECK(vuv_plan_resolve(&plan, &camera, &calibration, &limits, 1, .11, .01, 8192, &resolved,
                           error, sizeof error));
    CHECK(resolved.guard_angle < 0);
    plan.points = 50001;
    CHECK(!vuv_plan_resolve(&plan, &camera, &calibration, &limits, 1, .11, .01, 8192, &resolved,
                            error, sizeof error));
    CHECK(vuv_target_allowed(5, &limits, error, sizeof error));
    CHECK(!vuv_target_allowed(5.001, &limits, error, sizeof error));
    CHECK(!vuv_target_allowed(NAN, &limits, error, sizeof error));
    limits.controller_max = 2;
    CHECK(!vuv_target_allowed(3, &limits, error, sizeof error));
    plan = vuv_plan_defaults();
    CHECK(vuv_signal_range(&plan, 2048, &lo, &hi, error, sizeof error) && lo == 0 && hi == 2047);
    plan.signal_last = 2048;
    CHECK(!vuv_signal_range(&plan, 2048, &lo, &hi, error, sizeof error));
    plan.signal_last = -2;
    CHECK(!vuv_signal_range(&plan, 2048, &lo, &hi, error, sizeof error));
    vuv_reduce_frame(raw1, 2, 3, 0, work, average, 1);
    CHECK(average[0] == -2 && average[1] == 12 && average[2] == 16);
    vuv_reduce_frame(raw2, 2, 3, 0, work, average, 2);
    CHECK(average[0] == 2 && average[1] == 16 && average[2] == 20);
    CHECK(vuv_integrate(average, 0, 2) == 38);
    vuv_reduce_frame(raw1, 2, 3, 1, work, average, 1);
    CHECK(average[0] == -1 && average[1] == 6 && average[2] == 8);
    CHECK(vuv_integrate(negative, 0, 2) == -13);
    CHECK(fabs(vuv_position_estimate(1, 10, 3, 12, 10.5) - 1.5) < 1e-12);
    CHECK(isnan(vuv_position_estimate(1, 10, 3, 10, 10)));
    CHECK(isnan(vuv_position_estimate(NAN, 10, 3, 12, 11)));
    FILE *f = fopen("build/test_frame.npy", "wb");
    CHECK(f != NULL);
    if (f) {
        CHECK(vuv_npy_frame(f, raw1, 2, 3));
        fclose(f);
    }
    printf("Core: %d checks, %d failures\n", checks, failures);
    return failures ? 1 : 0;
}
