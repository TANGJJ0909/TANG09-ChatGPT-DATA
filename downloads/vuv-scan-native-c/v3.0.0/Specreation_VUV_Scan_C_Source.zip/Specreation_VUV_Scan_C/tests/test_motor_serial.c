#include "native.h"
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include <wchar.h>
static int checks, failures;
#define CHECK(x)                                                                                   \
    do {                                                                                           \
        checks++;                                                                                  \
        if (!(x)) {                                                                                \
            failures++;                                                                            \
            char *u = native_utf8(error);                                                          \
            fprintf(stderr, "FAIL line %d: %s\n", __LINE__, u ? u : "");                           \
            free(u);                                                                               \
        }                                                                                          \
    } while (0)
int main(void) {
    Motor m;
    MotorConfig c;
    wchar_t error[VUV_ERR] = L"";
    double value;
    HANDLE cancel = CreateEventW(NULL, TRUE, FALSE, NULL);
    memset(&c, 0, sizeof c);
    wcscpy(c.port, L"COM9");
    c.baud = 57600;
    c.address = 1;
    c.xonxoff = 1;
    c.timeout_s = .2;
    c.move_timeout_s = 5;
    c.limits.local_min = -5;
    c.limits.local_max = 5;
    c.limits.tolerance = .001;
    motor_create(&m);
    CHECK(motor_connect(&m, &c, error));
    CHECK(m.connected && m.suffix == 0);
    CHECK(motor_position(&m, &value, error) && fabs(value) < 1e-8);
    CHECK(motor_set_velocity(&m, .5, error));
    CHECK(motor_velocity(&m, &value, error) && fabs(value - .5) < 1e-8);
    CHECK(motor_move(&m, .05, cancel, error));
    CHECK(motor_position(&m, &value, error) && fabs(value - .05) < .001);
    CHECK(!motor_start(&m, 10, cancel, error));
    SetEvent(cancel);
    CHECK(!motor_start(&m, .1, cancel, error));
    ResetEvent(cancel);
    CHECK(motor_start(&m, 1, cancel, error));
    Sleep(100);
    CHECK(motor_stop(&m, error));
    CHECK(motor_wait_ready(&m, 0, 0, cancel, 3, error));
    CHECK(motor_position(&m, &value, error) && value > .05 && value < 1);
    motor_close(&m);
    CHECK(!m.connected);
    CloseHandle(cancel);
    printf("SMC100 Win32 serial: %d checks, %d failures\n", checks, failures);
    return failures ? 1 : 0;
}
