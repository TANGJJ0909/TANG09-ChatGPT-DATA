#include "native.h"
#include <math.h>
#include <stdlib.h>
#include <wchar.h>
static int failures, checks;
#define CHECK(x)                                                                                   \
    do {                                                                                           \
        checks++;                                                                                  \
        if (!(x)) {                                                                                \
            failures++;                                                                            \
            char *u = native_utf8(error);                                                          \
            fprintf(stderr, "FAIL line %d: %s\n", __LINE__, u ? u : "");                           \
            free(u);                                                                               \
        }                                                                                          \
    } while (0)
int wmain(int argc, wchar_t **argv) {
    Camera camera;
    wchar_t error[VUV_ERR] = L"", dll[VUV_PATH];
    VuvCameraConfig config = vuv_camera_defaults();
    int32_t raw[2048];
    HANDLE cancel = CreateEventW(NULL, TRUE, FALSE, NULL);
    if (argc != 2)
        return 2;
    GetFullPathNameW(argv[1], VUV_PATH, dll, NULL);
    camera_create(&camera);
    CHECK(camera_connect(&camera, 0, dll, 0, error));
    CHECK(camera.connected && camera.initialized && camera.width == 64 && camera.height == 32);
    config.exposure_ms = 1;
    config.hbin = 2;
    config.read_mode = 4;
    config.x1 = 64;
    config.y1 = 32;
    config.vbin = 2;
    CHECK(camera_configure(&camera, &config, error));
    CHECK(camera.shape.rows == 16 && camera.shape.cols == 32);
    CHECK(fabs(camera.actual_exposure - .001) < 1e-8 && fabs(camera.vs_us - 3) < 1e-8);
    CHECK(camera_acquire(&camera, NULL, cancel, raw, error));
    CHECK(raw[0] == -100 && raw[511] == 411);
    config.ad = 10;
    CHECK(!camera_configure(&camera, &config, error));
    config.ad = 0;
    config.read_mode = 3;
    config.track_height = 8;
    CHECK(camera_configure(&camera, &config, error));
    CHECK(camera_acquire(&camera, NULL, cancel, raw, error));
    CHECK(camera.shape.rows == 1 && raw[31] == -69);
    SetEvent(cancel);
    CHECK(!camera_acquire(&camera, NULL, cancel, raw, error));
    ResetEvent(cancel);
    CHECK(camera_cooler(&camera, 1, -70, error));
    CHECK(camera.temp_stable);
    CHECK(!camera_close(&camera, error));
    CHECK(camera.initialized && camera.dll && !camera.cooler_on);
    SDKI set_temp = NULL;
    FARPROC address = GetProcAddress(camera.dll, "TestSetTemperature");
    memcpy(&set_temp, &address, sizeof address);
    CHECK(set_temp && set_temp(20) == 20002);
    CHECK(camera_close(&camera, error));
    CHECK(!camera.initialized && !camera.connected && !camera.dll);
    CloseHandle(cancel);
    printf("SDK2 DLL ABI: %d checks, %d failures\n", checks, failures);
    return failures ? 1 : 0;
}
